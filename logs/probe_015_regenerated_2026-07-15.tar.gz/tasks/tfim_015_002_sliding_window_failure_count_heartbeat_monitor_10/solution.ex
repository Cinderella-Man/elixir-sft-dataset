  test "automatic interval probing drives a service down", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      WindowMonitor.watch(server, "auto", script([{:error, :boom}]),
        threshold: 1,
        interval: 20,
        on_change: on_change
      )

    assert_receive {:change, "auto", :down}, 2_000
    assert {:ok, :down} = WindowMonitor.health(server, "auto")
    refute_receive {:change, _, _}, 200
  end