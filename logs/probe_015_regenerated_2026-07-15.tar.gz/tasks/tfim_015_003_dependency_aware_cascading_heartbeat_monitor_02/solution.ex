  test "unknown nodes return {:error, :not_found}", %{server: server} do
    assert {:error, :not_found} = DepMonitor.direct_status(server, "x")
    assert {:error, :not_found} = DepMonitor.effective_status(server, "x")
    assert {:error, :not_found} = DepMonitor.check(server, "x")
  end