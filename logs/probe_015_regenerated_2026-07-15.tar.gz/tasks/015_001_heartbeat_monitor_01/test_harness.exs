defmodule MonitorTest do
  use ExUnit.Case, async: false

  # --- Deterministic scripted check functions ---
  #
  # `script([...])` returns a zero-arity function that yields the given results in
  # order on successive calls; once the list is down to a single element, that
  # element is returned on every subsequent call. This makes "always fails" /
  # "fails then recovers" check functions fully deterministic.

  defp script(list) do
    {:ok, pid} = Agent.start_link(fn -> list end)
    fn -> next(pid) end
  end

  defp next(pid) do
    Agent.get_and_update(pid, fn
      [x] -> {x, [x]}
      [x | rest] -> {x, rest}
      [] -> {:ok, []}
    end)
  end

  setup do
    {:ok, server} = Monitor.start_link([])
    %{server: server}
  end

  # -------------------------------------------------------
  # Registration basics
  # -------------------------------------------------------

  test "register returns :ok and a new service starts :up", %{server: server} do
    assert :ok =
             Monitor.register(server, "svc", script([:ok]), :infinity)

    assert {:ok, :up} = Monitor.status(server, "svc")
  end

  test "statuses lists all registered services and is empty at first", %{server: server} do
    assert Monitor.statuses(server) == %{}

    :ok = Monitor.register(server, "a", script([:ok]), :infinity)
    :ok = Monitor.register(server, "b", script([:ok]), :infinity)

    assert Monitor.statuses(server) == %{"a" => :up, "b" => :up}
  end

  test "status of an unknown service is {:error, :not_found}", %{server: server} do
    assert {:error, :not_found} = Monitor.status(server, "nope")
  end

  # -------------------------------------------------------
  # Staying up
  # -------------------------------------------------------

  test "a healthy service stays up and never notifies", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok = Monitor.register(server, "svc", script([:ok]), :infinity, notify: notify)

    for _ <- 1..5, do: send(server, {:check, "svc"})

    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 100
  end

  # -------------------------------------------------------
  # Transition :up -> :down at the threshold, exactly once
  # -------------------------------------------------------

  test "service goes down after N consecutive failures, notifying once", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok =
      Monitor.register(server, "svc", script([{:error, :boom}]), :infinity,
        threshold: 3,
        notify: notify
      )

    # Two failures: still up, no notification.
    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 50

    # Third consecutive failure: down, notify once.
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}

    # Further failures while already down: stays down, no further notification.
    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 100
  end

  test "threshold defaults to 3", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok = Monitor.register(server, "svc", script([{:error, :boom}]), :infinity, notify: notify)

    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")

    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}
  end

  # -------------------------------------------------------
  # Consecutive-only counting
  # -------------------------------------------------------

  test "a healthy check resets the consecutive-failure count", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    # error, error, ok, error, error  -> never 3 in a row -> stays up
    seq = [
      {:error, :boom},
      {:error, :boom},
      :ok,
      {:error, :boom},
      {:error, :boom},
      {:error, :boom}
    ]

    :ok = Monitor.register(server, "svc", script(seq), :infinity, threshold: 3, notify: notify)

    for _ <- 1..5, do: send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 50

    # Sixth check is the third failure of an unbroken run -> down.
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}
  end

  # -------------------------------------------------------
  # Recovery :down -> :up
  # -------------------------------------------------------

  test "service recovers to up and notifies on the way back", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    seq = [{:error, :boom}, {:error, :boom}, {:error, :boom}, :ok]

    :ok = Monitor.register(server, "svc", script(seq), :infinity, threshold: 3, notify: notify)

    for _ <- 1..3, do: send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}

    # Next check succeeds -> back up, notify once.
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :up}
    refute_receive {:transition, _, _}, 100
  end

  # -------------------------------------------------------
  # Independence between services
  # -------------------------------------------------------

  test "services are independent", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok =
      Monitor.register(server, "a", script([{:error, :boom}]), :infinity,
        threshold: 1,
        notify: notify
      )

    :ok = Monitor.register(server, "b", script([:ok]), :infinity, notify: notify)

    send(server, {:check, "a"})
    assert {:ok, :down} = Monitor.status(server, "a")
    assert_receive {:transition, "a", :down}

    # b is untouched.
    assert {:ok, :up} = Monitor.status(server, "b")
    assert Monitor.statuses(server) == %{"a" => :down, "b" => :up}
    refute_receive {:transition, "b", _}, 50
  end

  # -------------------------------------------------------
  # Automatic periodic checks
  # -------------------------------------------------------

  test "automatic interval checks drive the service down", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok =
      Monitor.register(server, "auto", script([{:error, :boom}]), 20,
        threshold: 1,
        notify: notify
      )

    assert_receive {:transition, "auto", :down}, 2_000
    assert {:ok, :down} = Monitor.status(server, "auto")

    # Once down, repeated automatic failures do not notify again.
    refute_receive {:transition, _, _}, 200
  end

  # -------------------------------------------------------
  # Robustness
  # -------------------------------------------------------

  test "unexpected messages are ignored and do not disturb state", %{server: server} do
    :ok = Monitor.register(server, "svc", script([:ok]), :infinity)

    send(server, :hello)
    send(server, {:weird, 1, 2})
    send(server, {:check, "unregistered-service"})

    assert {:ok, :up} = Monitor.status(server, "svc")
    assert Process.alive?(server)
  end

  test "a service with no :notify option can transition without crashing", %{server: server} do
    :ok =
      Monitor.register(server, "svc", script([{:error, :boom}]), :infinity, threshold: 1)

    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert Process.alive?(server)
  end
end
