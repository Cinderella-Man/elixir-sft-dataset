# Heartbeat Monitor

Write me an Elixir `GenServer` module called `Monitor` that supervises a set of
registered services by periodically running a health-check function for each one
and tracking whether the service is currently `:up` or `:down`.

Use only the OTP standard library — no external dependencies. Give me the complete
module in a single file.

## Public API

- `Monitor.start_link(opts \\ [])` — starts the process. It links the new process
  to the caller and returns the usual `GenServer.on_start()` result. `opts` is a
  keyword list defaulting to `[]`. When a `:name` option is present it is used for
  process registration (so the other functions may be called with either the pid
  or the registered name); when absent the process starts unregistered. Starting
  the server does no monitoring work — a freshly started server tracks zero
  services.

- `Monitor.register(server, service_name, check_func, interval_ms, opts \\ [])` —
  registers a service to be monitored, and returns `:ok`.
  - `service_name` is any term and identifies the service (compared by value).
  - `check_func` is a **zero-arity** function that, when invoked, returns either
    `:ok` (the service is healthy) or `{:error, reason}` (unhealthy). `reason` may
    be any term. Guard the public function with `is_function(check_func, 0)`.
  - `interval_ms` is either a **positive integer** (the number of milliseconds
    between automatic checks) or the atom `:infinity`. When it is a positive
    integer the server schedules the service's checks to run automatically on that
    interval, using `Process.send_after/3`; the first automatic check happens one
    interval after registration (not immediately), and the checks repeat
    indefinitely. When it is `:infinity` no automatic checks are ever scheduled for
    that service — the service is only ever checked when a check is triggered
    manually (see below). Any other value is outside the contract and may raise.
  - `opts` may contain:
    - `:threshold` — a positive integer, the number of **consecutive** failed
      checks required before the service is marked `:down`. Defaults to `3`.
    - `:notify` — an arity-2 function called as `notify.(service_name, new_status)`
      whenever the service's status changes (see "Status transitions"). Defaults to
      a no-op function.
  - A newly registered service starts with status `:up` and a consecutive-failure
    count of `0`. Registering a `service_name` that already exists replaces its
    configuration and resets it to this initial state.

- `Monitor.status(server, service_name)` — returns `{:ok, :up}` or `{:ok, :down}`
  for a registered service reflecting its current status, or `{:error, :not_found}`
  for a service that has never been registered.

- `Monitor.statuses(server)` — returns a map `%{service_name => :up | :down}`
  containing every currently registered service and its current status. For a
  server with no registered services this is the empty map `%{}`.

## Running a check

A single check for a service consists of invoking that service's `check_func` and
updating the service's state from the result. Checks run **synchronously inside the
server process** (the server invokes `check_func` itself). Both the automatic
interval timer and the manual trigger below perform exactly this same work.

Let the service currently have status `st`, consecutive-failure count `c`, and
threshold `t`.

- If `check_func` returns `:ok`:
  - The consecutive-failure count is reset to `0`.
  - If `st` was `:down`, the status becomes `:up` — this is a transition (see
    below). If `st` was already `:up`, the status stays `:up` and nothing else
    changes.
- If `check_func` returns `{:error, reason}`:
  - The consecutive-failure count becomes `c + 1`.
  - If the new count is `>= t` **and** `st` was `:up`, the status becomes `:down` —
    this is a transition. Otherwise the status is left unchanged: a service that is
    still `:up` but has accumulated fewer than `t` consecutive failures stays `:up`,
    and a service that is already `:down` stays `:down`.

Because failures must be **consecutive**, any single `:ok` result resets the count
to `0`: e.g. with `threshold: 3`, the sequence error, error, ok, error, error
leaves the service `:up`, and only a third error *in an unbroken run* (error,
error, error) marks it `:down`.

## Status transitions and notifications

A "transition" is any change of the status field — from `:up` to `:down`, or from
`:down` back to `:up`. On each transition, and **only** on an actual change, the
service's `:notify` function is called exactly once as
`notify.(service_name, new_status)` where `new_status` is the status just entered
(`:down` or `:up`). Repeated failed checks while a service is already `:down` do not
call `notify` again, and repeated healthy checks while a service is already `:up` do
not call it either. Thus `notify` fires exactly once per transition.

## Manually triggering a check

Sending the server the message `{:check, service_name}` performs one check for that
service immediately — the same work an automatic tick performs — and does not touch
the automatic timer. Because a `GenServer` processes its mailbox in order, sending
`{:check, service_name}` and then calling `Monitor.status/2` (or `statuses/1`)
observes the state produced by that completed check. If `service_name` is not
registered, the message is ignored. This message exists so that checks can be driven
deterministically with scripted check functions.

## Independence and robustness

- Services are fully independent: a failing/`:down` service never affects the status
  or counters of any other service.
- The server must tolerate arbitrary unexpected messages: any message it does not
  understand is ignored and must neither crash the process nor alter any service's
  state.