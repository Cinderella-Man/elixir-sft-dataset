defmodule Monitor do
  @moduledoc """
  A `GenServer` that supervises a set of registered services by periodically
  running a health-check function for each one and tracking whether the service
  is currently `:up` or `:down`.

  Each service is registered with a zero-arity check function returning `:ok`
  (healthy) or `{:error, reason}` (unhealthy). A service becomes `:down` after a
  configurable number of *consecutive* failed checks, and returns to `:up` on the
  first subsequent healthy check. A `:notify` callback is invoked exactly once on
  every actual status transition.

  Checks are run synchronously inside the server process. Automatic checks are
  scheduled with `Process.send_after/3` on a per-service interval; the first
  automatic check fires one interval after registration. A check can also be
  triggered manually by sending the server `{:check, service_name}`.

  Uses only the OTP standard library.
  """

  use GenServer

  @default_threshold 3

  @typedoc "Current health status of a service."
  @type status :: :up | :down

  @typedoc "A zero-arity health-check function."
  @type check_func :: (-> :ok | {:error, term()})

  # Internal per-service record.
  # %{
  #   check: check_func,
  #   interval: pos_integer() | :infinity,
  #   threshold: pos_integer(),
  #   notify: (term(), status -> any()),
  #   status: status(),
  #   failures: non_neg_integer()
  # }

  ## Public API

  @doc """
  Starts the monitor process, linked to the caller.

  When `opts` contains a `:name`, it is used for process registration; otherwise
  the process starts unregistered. A freshly started server tracks zero services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    case Keyword.fetch(opts, :name) do
      {:ok, name} -> GenServer.start_link(__MODULE__, :ok, name: name)
      :error -> GenServer.start_link(__MODULE__, :ok)
    end
  end

  @doc """
  Registers a service to be monitored and returns `:ok`.

  `check_func` is a zero-arity function returning `:ok` or `{:error, reason}`.
  `interval_ms` is a positive integer number of milliseconds between automatic
  checks, or `:infinity` to disable automatic checks. `opts` may contain a
  positive-integer `:threshold` (default `3`) and an arity-2 `:notify` callback.

  Registering an existing `service_name` replaces its configuration and resets it
  to the initial state (`:up`, zero consecutive failures).
  """
  @spec register(
          GenServer.server(),
          term(),
          check_func(),
          pos_integer() | :infinity,
          keyword()
        ) :: :ok
  def register(server, service_name, check_func, interval_ms, opts \\ [])
      when is_function(check_func, 0) do
    GenServer.call(server, {:register, service_name, check_func, interval_ms, opts})
  end

  @doc """
  Returns `{:ok, :up}` or `{:ok, :down}` for a registered service, or
  `{:error, :not_found}` if the service has never been registered.
  """
  @spec status(GenServer.server(), term()) :: {:ok, status()} | {:error, :not_found}
  def status(server, service_name) do
    GenServer.call(server, {:status, service_name})
  end

  @doc """
  Returns a map of every currently registered service to its current status.

  For a server with no registered services this is the empty map `%{}`.
  """
  @spec statuses(GenServer.server()) :: %{optional(term()) => status()}
  def statuses(server) do
    GenServer.call(server, :statuses)
  end

  ## GenServer callbacks

  @impl true
  @spec init(:ok) :: {:ok, %{optional(term()) => map()}}
  def init(:ok) do
    {:ok, %{}}
  end

  @impl true
  def handle_call({:register, service_name, check_func, interval_ms, opts}, _from, services) do
    threshold = Keyword.get(opts, :threshold, @default_threshold)
    notify = Keyword.get(opts, :notify, fn _name, _status -> :ok end)

    service = %{
      check: check_func,
      interval: interval_ms,
      threshold: threshold,
      notify: notify,
      status: :up,
      failures: 0
    }

    schedule(service_name, interval_ms)
    {:reply, :ok, Map.put(services, service_name, service)}
  end

  def handle_call({:status, service_name}, _from, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} -> {:reply, {:ok, service.status}, services}
      :error -> {:reply, {:error, :not_found}, services}
    end
  end

  def handle_call(:statuses, _from, services) do
    result = Map.new(services, fn {name, service} -> {name, service.status} end)
    {:reply, result, services}
  end

  @impl true
  def handle_info({:tick, service_name}, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} ->
        schedule(service_name, service.interval)
        {:noreply, run_check(service_name, service, services)}

      :error ->
        {:noreply, services}
    end
  end

  def handle_info({:check, service_name}, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} -> {:noreply, run_check(service_name, service, services)}
      :error -> {:noreply, services}
    end
  end

  def handle_info(_msg, services) do
    {:noreply, services}
  end

  ## Internal helpers

  # Schedules the next automatic tick for a service, unless disabled.
  @spec schedule(term(), pos_integer() | :infinity) :: reference() | :infinity
  defp schedule(_service_name, :infinity), do: :infinity

  defp schedule(service_name, interval_ms) when is_integer(interval_ms) and interval_ms > 0 do
    Process.send_after(self(), {:tick, service_name}, interval_ms)
  end

  # Runs one check for a service, updating state and firing notifications.
  @spec run_check(term(), map(), map()) :: map()
  defp run_check(service_name, service, services) do
    updated = apply_result(service, service.check.())

    if updated.status != service.status do
      service.notify.(service_name, updated.status)
    end

    Map.put(services, service_name, updated)
  end

  # Computes the new service record from a check result.
  @spec apply_result(map(), :ok | {:error, term()}) :: map()
  defp apply_result(service, :ok) do
    %{service | failures: 0, status: :up}
  end

  defp apply_result(service, {:error, _reason}) do
    failures = service.failures + 1

    if failures >= service.threshold and service.status == :up do
      %{service | failures: failures, status: :down}
    else
      %{service | failures: failures}
    end
  end
end
