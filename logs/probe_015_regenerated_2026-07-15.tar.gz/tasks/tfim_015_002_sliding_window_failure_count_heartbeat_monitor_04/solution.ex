  test "health and probe_now on an unknown service return {:error, :not_found}", %{
    server: server
  } do
    assert {:error, :not_found} = WindowMonitor.health(server, "nope")
    assert {:error, :not_found} = WindowMonitor.probe_now(server, "nope")
  end