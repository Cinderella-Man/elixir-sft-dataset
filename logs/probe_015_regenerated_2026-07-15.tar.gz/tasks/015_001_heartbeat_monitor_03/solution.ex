  # Runs one check for a service, updating state and firing notifications.
  @spec run_check(term(), map(), map()) :: map()
  defp run_check(service_name, service, services) do
    updated = apply_result(service, service.check.())

    if updated.status != service.status do
      service.notify.(service_name, updated.status)
    end

    Map.put(services, service_name, updated)
  end