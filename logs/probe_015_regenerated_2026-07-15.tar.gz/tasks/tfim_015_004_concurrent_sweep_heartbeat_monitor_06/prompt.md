# Fill in the middle: implement the blanked test

Below is a module and its ExUnit test harness with the body of ONE `test` removed
(marked `# TODO`). The test's name states what it must verify. Implement just that one
test so the harness passes for a correct implementation of the module.

## Module under test

```elixir
defmodule AsyncMonitor do
  @moduledoc """
  A `GenServer` that watches enrolled services and probes them concurrently.

  Each enrolled service has a zero-arity probe function returning `:ok` or
  `{:error, reason}`. Calling `sweep/1` runs one probe for every enrolled
  service, dispatching each probe to its **own separate process** so that a
  slow or blocking probe cannot delay the others. A sweep blocks until every
  probe has finished and its result has been applied to the owning service.

  A service becomes `:down` only after `:threshold` *consecutive* failed
  probes while it was `:up`; any successful probe resets the failure count and
  brings a `:down` service back `:up`. On each actual status transition the
  service's `:on_change` callback is invoked exactly once as
  `on_change.(name, new_status)`.

  Services are fully independent: one service's result never affects another's.
  Unknown messages are ignored and never crash the server.
  """

  use GenServer

  @default_threshold 3

  @typedoc "Status of an enrolled service."
  @type status :: :up | :down

  @typedoc "A zero-arity probe function."
  @type probe :: (-> :ok | {:error, term()})

  # ── Public API ────────────────────────────────────────────────────────────

  @doc """
  Starts the monitor linked to the caller.

  `opts` may contain a `:name` used for process registration; when absent the
  process is left unregistered. A freshly started server has zero enrolled
  services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    {name, rest} = Keyword.pop(opts, :name)
    gen_opts = if name, do: [name: name], else: []
    GenServer.start_link(__MODULE__, rest, gen_opts)
  end

  @doc """
  Enrolls (or replaces) a service identified by `name`.

  `probe` must be a zero-arity function. `opts` accepts `:threshold` (a
  positive integer, default `#{@default_threshold}`) and `:on_change` (an
  arity-2 callback, default a no-op). The service starts `:up` with `0`
  consecutive failures; re-enrolling an existing `name` resets it to that
  initial state.
  """
  @spec enroll(GenServer.server(), term(), probe(), keyword()) :: :ok
  def enroll(server, name, probe, opts \\ []) when is_function(probe, 0) do
    GenServer.call(server, {:enroll, name, probe, opts})
  end

  @doc """
  Runs one probe for every currently enrolled service.

  Every service's probe runs in its own process and all probes of the sweep
  are launched before any of them must finish. Blocks and returns `:ok` only
  after every probe has finished and been applied. Returns `:ok` immediately
  when nothing is enrolled.
  """
  @spec sweep(GenServer.server()) :: :ok
  def sweep(server) do
    GenServer.call(server, :sweep, :infinity)
  end

  @doc """
  Returns `{:ok, status}` for an enrolled service, or `{:error, :not_found}`.
  """
  @spec status(GenServer.server(), term()) :: {:ok, status()} | {:error, :not_found}
  def status(server, name) do
    GenServer.call(server, {:status, name})
  end

  @doc """
  Returns a map of `%{name => status}` for every enrolled service.
  """
  @spec overview(GenServer.server()) :: %{optional(term()) => status()}
  def overview(server) do
    GenServer.call(server, :overview)
  end

  # ── GenServer callbacks ─────────────────────────────────────────────────────

  @impl true
  @spec init(keyword()) :: {:ok, %{services: map()}}
  def init(_opts) do
    {:ok, %{services: %{}}}
  end

  @impl true
  def handle_call({:enroll, name, probe, opts}, _from, state) do
    threshold = Keyword.get(opts, :threshold, @default_threshold)
    on_change = Keyword.get(opts, :on_change, &default_on_change/2)

    svc = %{
      probe: probe,
      threshold: threshold,
      on_change: on_change,
      status: :up,
      count: 0
    }

    {:reply, :ok, %{state | services: Map.put(state.services, name, svc)}}
  end

  def handle_call(:sweep, _from, %{services: services} = state) do
    if map_size(services) == 0 do
      {:reply, :ok, state}
    else
      results = run_sweep(services)
      {:reply, :ok, apply_all(state, results)}
    end
  end

  def handle_call({:status, name}, _from, %{services: services} = state) do
    reply =
      case Map.fetch(services, name) do
        {:ok, svc} -> {:ok, svc.status}
        :error -> {:error, :not_found}
      end

    {:reply, reply, state}
  end

  def handle_call(:overview, _from, %{services: services} = state) do
    overview = Map.new(services, fn {name, svc} -> {name, svc.status} end)
    {:reply, overview, state}
  end

  def handle_call(_other, _from, state) do
    {:reply, {:error, :unknown_request}, state}
  end

  @impl true
  def handle_cast(_msg, state), do: {:noreply, state}

  @impl true
  def handle_info(_msg, state), do: {:noreply, state}

  # ── Internals ───────────────────────────────────────────────────────────────

  # Spawn one probe process per service (all before waiting), then gather.
  @spec run_sweep(map()) :: %{optional(term()) => :ok | :error}
  defp run_sweep(services) do
    server = self()

    refs =
      Enum.map(services, fn {name, svc} ->
        ref = make_ref()
        probe = svc.probe
        spawn(fn -> send(server, {:probe_result, ref, run_probe(probe)}) end)
        {ref, name}
      end)

    gather(refs, %{})
  end

  @spec gather([{reference(), term()}], map()) :: map()
  defp gather([], acc), do: acc

  defp gather([{ref, name} | rest], acc) do
    receive do
      {:probe_result, ^ref, result} -> gather(rest, Map.put(acc, name, result))
    end
  end

  # Run a probe, normalising the outcome and shielding against raises/throws.
  @spec run_probe(probe()) :: :ok | :error
  defp run_probe(probe) do
    case probe.() do
      :ok -> :ok
      _other -> :error
    end
  rescue
    _error -> :error
  catch
    _kind, _value -> :error
  end

  # Apply every gathered result, then fire callbacks for actual transitions.
  @spec apply_all(map(), map()) :: map()
  defp apply_all(state, results) do
    {new_services, callbacks} =
      Enum.reduce(state.services, {%{}, []}, fn {name, svc}, {acc, cbs} ->
        result = Map.fetch!(results, name)
        {new_svc, transition?, new_status} = apply_result(svc, result)
        cbs = if transition?, do: [{svc.on_change, name, new_status} | cbs], else: cbs
        {Map.put(acc, name, new_svc), cbs}
      end)

    Enum.each(callbacks, fn {cb, name, status} -> cb.(name, status) end)
    %{state | services: new_services}
  end

  # Compute the new service state, plus whether the status changed.
  @spec apply_result(map(), :ok | :error) :: {map(), boolean(), status()}
  defp apply_result(%{status: st} = svc, :ok) do
    {%{svc | status: :up, count: 0}, st == :down, :up}
  end

  defp apply_result(%{status: st, count: c, threshold: t} = svc, :error) do
    new_count = c + 1

    if new_count >= t and st == :up do
      {%{svc | status: :down, count: new_count}, true, :down}
    else
      {%{svc | count: new_count}, false, st}
    end
  end

  @spec default_on_change(term(), status()) :: :ok
  defp default_on_change(_name, _status), do: :ok
end
```

## Test harness — implement the `# TODO` test

```elixir
defmodule AsyncMonitorTest do
  use ExUnit.Case, async: false

  defp script(list) do
    {:ok, pid} = Agent.start_link(fn -> list end)
    fn -> next(pid) end
  end

  defp next(pid) do
    Agent.get_and_update(pid, fn
      [x] -> {x, [x]}
      [x | rest] -> {x, rest}
      [] -> {:ok, []}
    end)
  end

  setup do
    {:ok, server} = AsyncMonitor.start_link([])
    %{server: server}
  end

  test "enroll returns :ok, a new service is up, overview starts empty", %{server: server} do
    assert AsyncMonitor.overview(server) == %{}
    assert :ok = AsyncMonitor.enroll(server, "svc", script([:ok]))
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert AsyncMonitor.overview(server) == %{"svc" => :up}
  end

  test "status of an unknown service is {:error, :not_found}", %{server: server} do
    assert {:error, :not_found} = AsyncMonitor.status(server, "nope")
  end

  test "sweep with no services returns :ok", %{server: server} do
    assert :ok = AsyncMonitor.sweep(server)
  end

  test "a sweep runs one probe per service and applies results", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      AsyncMonitor.enroll(server, "svc", script([{:error, :boom}]),
        threshold: 3,
        on_change: on_change
      )

    assert :ok = AsyncMonitor.sweep(server)
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    refute_receive {:change, _, _}, 50

    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    assert_receive {:change, "svc", :down}

    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    refute_receive {:change, _, _}, 100
  end

  test "threshold defaults to 3", %{server: server} do
    # TODO
  end

  test "a healthy probe resets the consecutive-failure count", %{server: server} do
    seq = [{:error, :boom}, {:error, :boom}, :ok, {:error, :boom}, {:error, :boom}]
    :ok = AsyncMonitor.enroll(server, "svc", script(seq), threshold: 3)
    for _ <- 1..5, do: assert(:ok = AsyncMonitor.sweep(server))
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
  end

  test "a service recovers to up and notifies", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    seq = [{:error, :boom}, {:error, :boom}, {:error, :boom}, :ok]
    :ok = AsyncMonitor.enroll(server, "svc", script(seq), threshold: 3, on_change: on_change)

    for _ <- 1..3, do: assert(:ok = AsyncMonitor.sweep(server))
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    assert_receive {:change, "svc", :down}

    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert_receive {:change, "svc", :up}
  end

  test "services are independent within a sweep", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      AsyncMonitor.enroll(server, "a", script([{:error, :boom}]),
        threshold: 1,
        on_change: on_change
      )

    :ok = AsyncMonitor.enroll(server, "b", script([:ok]), on_change: on_change)

    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "a")
    assert {:ok, :up} = AsyncMonitor.status(server, "b")
    assert AsyncMonitor.overview(server) == %{"a" => :down, "b" => :up}
    assert_receive {:change, "a", :down}
    refute_receive {:change, "b", _}, 50
  end

  test "probes within a sweep run concurrently in separate processes", %{server: server} do
    me = self()

    # Each probe announces its own process pid, then blocks until told to continue.
    # Both announcements can only arrive if both probes were dispatched before the
    # sweep waited for either to finish.
    rendezvous = fn tag ->
      fn ->
        send(me, {:started, tag, self()})

        receive do
          :go -> :ok
        end
      end
    end

    :ok = AsyncMonitor.enroll(server, "a", rendezvous.(:a))
    :ok = AsyncMonitor.enroll(server, "b", rendezvous.(:b))

    sweeper = Task.async(fn -> AsyncMonitor.sweep(server) end)

    assert_receive {:started, :a, pid_a}, 1_000
    assert_receive {:started, :b, pid_b}, 1_000

    send(pid_a, :go)
    send(pid_b, :go)

    assert :ok = Task.await(sweeper, 1_000)
    assert {:ok, :up} = AsyncMonitor.status(server, "a")
    assert {:ok, :up} = AsyncMonitor.status(server, "b")
  end

  test "a probe that raises counts as a failure and does not crash the server", %{server: server} do
    :ok = AsyncMonitor.enroll(server, "svc", fn -> raise "boom" end, threshold: 1)
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    assert Process.alive?(server)
  end

  test "re-enrolling a name resets its state", %{server: server} do
    :ok = AsyncMonitor.enroll(server, "svc", script([{:error, :boom}]), threshold: 1)
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")

    :ok = AsyncMonitor.enroll(server, "svc", script([:ok]))
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
  end

  test "a service with no :on_change can transition without crashing", %{server: server} do
    :ok = AsyncMonitor.enroll(server, "svc", script([{:error, :boom}]), threshold: 1)
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    assert Process.alive?(server)
  end

  test "unexpected messages are ignored and do not disturb state", %{server: server} do
    :ok = AsyncMonitor.enroll(server, "svc", script([:ok]))
    send(server, :hello)
    send(server, {:weird, 1, 2})
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert :ok = AsyncMonitor.sweep(server)
    assert Process.alive?(server)
  end

  test "unexpected casts are ignored and do not crash the server", %{server: server} do
    # start_link links the server to this test process; trap exits so a crash in
    # the server (e.g. a gutted handle_cast) surfaces as an assertion failure here
    # rather than silently killing the test process.
    Process.flag(:trap_exit, true)

    :ok = AsyncMonitor.enroll(server, "svc", script([{:error, :boom}]), threshold: 1)

    assert :ok = GenServer.cast(server, :hello)
    assert :ok = GenServer.cast(server, {:weird, 1, 2})

    # A subsequent synchronous call is processed only after the earlier casts, so
    # if handle_cast/2 crashed the server this call (and thus the test) fails.
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert Process.alive?(server)

    # State is untouched by the casts: the service still needs one failing sweep
    # (threshold 1) to go down, proving the casts neither advanced nor reset it.
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    assert Process.alive?(server)

    refute_received {:EXIT, ^server, _reason}
  end
end
```
