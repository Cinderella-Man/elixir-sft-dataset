  test "threshold defaults to 3", %{server: server} do
    :ok = AsyncMonitor.enroll(server, "svc", script([{:error, :boom}]))
    assert :ok = AsyncMonitor.sweep(server)
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
  end