  test "a healthy check resets the consecutive-failure count", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    # error, error, ok, error, error  -> never 3 in a row -> stays up
    seq = [
      {:error, :boom},
      {:error, :boom},
      :ok,
      {:error, :boom},
      {:error, :boom},
      {:error, :boom}
    ]

    :ok = Monitor.register(server, "svc", script(seq), :infinity, threshold: 3, notify: notify)

    for _ <- 1..5, do: send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 50

    # Sixth check is the third failure of an unbroken run -> down.
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}
  end