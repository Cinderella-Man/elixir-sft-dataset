  test "sweep with no services returns :ok", %{server: server} do
    assert :ok = AsyncMonitor.sweep(server)
  end