  test "a healthy service stays up and never notifies", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok = Monitor.register(server, "svc", script([:ok]), :infinity, notify: notify)

    for _ <- 1..5, do: send(server, {:check, "svc"})

    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 100
  end