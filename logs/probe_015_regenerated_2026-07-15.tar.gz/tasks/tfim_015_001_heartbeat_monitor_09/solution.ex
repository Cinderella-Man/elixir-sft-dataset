  test "service recovers to up and notifies on the way back", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    seq = [{:error, :boom}, {:error, :boom}, {:error, :boom}, :ok]

    :ok = Monitor.register(server, "svc", script(seq), :infinity, threshold: 3, notify: notify)

    for _ <- 1..3, do: send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}

    # Next check succeeds -> back up, notify once.
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :up}
    refute_receive {:transition, _, _}, 100
  end