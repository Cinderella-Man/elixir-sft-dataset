  test "unrelated nodes are independent", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:eff, n, s}) end

    :ok =
      DepMonitor.add_node(server, "B", script([{:error, :boom}]),
        threshold: 1,
        on_change: on_change
      )

    :ok = DepMonitor.add_node(server, "A", script([:ok]), depends_on: ["B"], on_change: on_change)
    :ok = DepMonitor.add_node(server, "C", script([:ok]), on_change: on_change)

    assert {:ok, :down} = DepMonitor.check(server, "B")
    assert {:ok, :up} = DepMonitor.effective_status(server, "C")
    refute_receive {:eff, "C", _}, 50
    assert DepMonitor.snapshot(server) == %{"A" => :down, "B" => :down, "C" => :up}
  end