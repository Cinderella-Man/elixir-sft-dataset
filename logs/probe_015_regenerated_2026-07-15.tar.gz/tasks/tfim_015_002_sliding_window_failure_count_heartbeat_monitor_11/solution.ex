  test "re-watching a name resets its state", %{server: server} do
    :ok = WindowMonitor.watch(server, "svc", script([{:error, :boom}]), threshold: 1)
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")

    :ok = WindowMonitor.watch(server, "svc", script([:ok]))
    assert {:ok, :up} = WindowMonitor.health(server, "svc")
    assert WindowMonitor.report(server) == %{"svc" => :up}
  end