  test "register returns :ok and a new service starts :up", %{server: server} do
    assert :ok =
             Monitor.register(server, "svc", script([:ok]), :infinity)

    assert {:ok, :up} = Monitor.status(server, "svc")
  end