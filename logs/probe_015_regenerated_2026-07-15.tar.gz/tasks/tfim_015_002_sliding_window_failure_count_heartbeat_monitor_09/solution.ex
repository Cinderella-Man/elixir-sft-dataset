  test "services are independent", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      WindowMonitor.watch(server, "a", script([{:error, :boom}]),
        threshold: 1,
        on_change: on_change
      )

    :ok = WindowMonitor.watch(server, "b", script([:ok]), on_change: on_change)

    assert {:ok, :down} = WindowMonitor.probe_now(server, "a")
    assert_receive {:change, "a", :down}
    assert {:ok, :up} = WindowMonitor.health(server, "b")
    assert WindowMonitor.report(server) == %{"a" => :down, "b" => :up}
    refute_receive {:change, "b", _}, 50
  end