# Fix the bug

The module below was written for the task that follows, but ONE behavior bug
slipped in. The test suite (not shown) fails with the report at the bottom.
Find the bug and fix it — change as little as possible; do not restructure
working code. Reply with the complete corrected module.

## The task the module implements

# Heartbeat Monitor

Write me an Elixir `GenServer` module called `Monitor` that supervises a set of
registered services by periodically running a health-check function for each one
and tracking whether the service is currently `:up` or `:down`.

Use only the OTP standard library — no external dependencies. Give me the complete
module in a single file.

## Public API

- `Monitor.start_link(opts \\ [])` — starts the process. It links the new process
  to the caller and returns the usual `GenServer.on_start()` result. `opts` is a
  keyword list defaulting to `[]`. When a `:name` option is present it is used for
  process registration (so the other functions may be called with either the pid
  or the registered name); when absent the process starts unregistered. Starting
  the server does no monitoring work — a freshly started server tracks zero
  services.

- `Monitor.register(server, service_name, check_func, interval_ms, opts \\ [])` —
  registers a service to be monitored, and returns `:ok`.
  - `service_name` is any term and identifies the service (compared by value).
  - `check_func` is a **zero-arity** function that, when invoked, returns either
    `:ok` (the service is healthy) or `{:error, reason}` (unhealthy). `reason` may
    be any term. Guard the public function with `is_function(check_func, 0)`.
  - `interval_ms` is either a **positive integer** (the number of milliseconds
    between automatic checks) or the atom `:infinity`. When it is a positive
    integer the server schedules the service's checks to run automatically on that
    interval, using `Process.send_after/3`; the first automatic check happens one
    interval after registration (not immediately), and the checks repeat
    indefinitely. When it is `:infinity` no automatic checks are ever scheduled for
    that service — the service is only ever checked when a check is triggered
    manually (see below). Any other value is outside the contract and may raise.
  - `opts` may contain:
    - `:threshold` — a positive integer, the number of **consecutive** failed
      checks required before the service is marked `:down`. Defaults to `3`.
    - `:notify` — an arity-2 function called as `notify.(service_name, new_status)`
      whenever the service's status changes (see "Status transitions"). Defaults to
      a no-op function.
  - A newly registered service starts with status `:up` and a consecutive-failure
    count of `0`. Registering a `service_name` that already exists replaces its
    configuration and resets it to this initial state.

- `Monitor.status(server, service_name)` — returns `{:ok, :up}` or `{:ok, :down}`
  for a registered service reflecting its current status, or `{:error, :not_found}`
  for a service that has never been registered.

- `Monitor.statuses(server)` — returns a map `%{service_name => :up | :down}`
  containing every currently registered service and its current status. For a
  server with no registered services this is the empty map `%{}`.

## Running a check

A single check for a service consists of invoking that service's `check_func` and
updating the service's state from the result. Checks run **synchronously inside the
server process** (the server invokes `check_func` itself). Both the automatic
interval timer and the manual trigger below perform exactly this same work.

Let the service currently have status `st`, consecutive-failure count `c`, and
threshold `t`.

- If `check_func` returns `:ok`:
  - The consecutive-failure count is reset to `0`.
  - If `st` was `:down`, the status becomes `:up` — this is a transition (see
    below). If `st` was already `:up`, the status stays `:up` and nothing else
    changes.
- If `check_func` returns `{:error, reason}`:
  - The consecutive-failure count becomes `c + 1`.
  - If the new count is `>= t` **and** `st` was `:up`, the status becomes `:down` —
    this is a transition. Otherwise the status is left unchanged: a service that is
    still `:up` but has accumulated fewer than `t` consecutive failures stays `:up`,
    and a service that is already `:down` stays `:down`.

Because failures must be **consecutive**, any single `:ok` result resets the count
to `0`: e.g. with `threshold: 3`, the sequence error, error, ok, error, error
leaves the service `:up`, and only a third error *in an unbroken run* (error,
error, error) marks it `:down`.

## Status transitions and notifications

A "transition" is any change of the status field — from `:up` to `:down`, or from
`:down` back to `:up`. On each transition, and **only** on an actual change, the
service's `:notify` function is called exactly once as
`notify.(service_name, new_status)` where `new_status` is the status just entered
(`:down` or `:up`). Repeated failed checks while a service is already `:down` do not
call `notify` again, and repeated healthy checks while a service is already `:up` do
not call it either. Thus `notify` fires exactly once per transition.

## Manually triggering a check

Sending the server the message `{:check, service_name}` performs one check for that
service immediately — the same work an automatic tick performs — and does not touch
the automatic timer. Because a `GenServer` processes its mailbox in order, sending
`{:check, service_name}` and then calling `Monitor.status/2` (or `statuses/1`)
observes the state produced by that completed check. If `service_name` is not
registered, the message is ignored. This message exists so that checks can be driven
deterministically with scripted check functions.

## Independence and robustness

- Services are fully independent: a failing/`:down` service never affects the status
  or counters of any other service.
- The server must tolerate arbitrary unexpected messages: any message it does not
  understand is ignored and must neither crash the process nor alter any service's
  state.

## The buggy module

```elixir
defmodule Monitor do
  @moduledoc """
  A `GenServer` that supervises a set of registered services by periodically
  running a health-check function for each one and tracking whether the service
  is currently `:up` or `:down`.

  Each service is registered with a zero-arity check function returning `:ok`
  (healthy) or `{:error, reason}` (unhealthy). A service becomes `:down` after a
  configurable number of *consecutive* failed checks, and returns to `:up` on the
  first subsequent healthy check. A `:notify` callback is invoked exactly once on
  every actual status transition.

  Checks are run synchronously inside the server process. Automatic checks are
  scheduled with `Process.send_after/3` on a per-service interval; the first
  automatic check fires one interval after registration. A check can also be
  triggered manually by sending the server `{:check, service_name}`.

  Uses only the OTP standard library.
  """

  use GenServer

  @default_threshold 4

  @typedoc "Current health status of a service."
  @type status :: :up | :down

  @typedoc "A zero-arity health-check function."
  @type check_func :: (-> :ok | {:error, term()})

  # Internal per-service record.
  # %{
  #   check: check_func,
  #   interval: pos_integer() | :infinity,
  #   threshold: pos_integer(),
  #   notify: (term(), status -> any()),
  #   status: status(),
  #   failures: non_neg_integer()
  # }

  ## Public API

  @doc """
  Starts the monitor process, linked to the caller.

  When `opts` contains a `:name`, it is used for process registration; otherwise
  the process starts unregistered. A freshly started server tracks zero services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    case Keyword.fetch(opts, :name) do
      {:ok, name} -> GenServer.start_link(__MODULE__, :ok, name: name)
      :error -> GenServer.start_link(__MODULE__, :ok)
    end
  end

  @doc """
  Registers a service to be monitored and returns `:ok`.

  `check_func` is a zero-arity function returning `:ok` or `{:error, reason}`.
  `interval_ms` is a positive integer number of milliseconds between automatic
  checks, or `:infinity` to disable automatic checks. `opts` may contain a
  positive-integer `:threshold` (default `3`) and an arity-2 `:notify` callback.

  Registering an existing `service_name` replaces its configuration and resets it
  to the initial state (`:up`, zero consecutive failures).
  """
  @spec register(
          GenServer.server(),
          term(),
          check_func(),
          pos_integer() | :infinity,
          keyword()
        ) :: :ok
  def register(server, service_name, check_func, interval_ms, opts \\ [])
      when is_function(check_func, 0) do
    GenServer.call(server, {:register, service_name, check_func, interval_ms, opts})
  end

  @doc """
  Returns `{:ok, :up}` or `{:ok, :down}` for a registered service, or
  `{:error, :not_found}` if the service has never been registered.
  """
  @spec status(GenServer.server(), term()) :: {:ok, status()} | {:error, :not_found}
  def status(server, service_name) do
    GenServer.call(server, {:status, service_name})
  end

  @doc """
  Returns a map of every currently registered service to its current status.

  For a server with no registered services this is the empty map `%{}`.
  """
  @spec statuses(GenServer.server()) :: %{optional(term()) => status()}
  def statuses(server) do
    GenServer.call(server, :statuses)
  end

  ## GenServer callbacks

  @impl true
  @spec init(:ok) :: {:ok, %{optional(term()) => map()}}
  def init(:ok) do
    {:ok, %{}}
  end

  @impl true
  def handle_call({:register, service_name, check_func, interval_ms, opts}, _from, services) do
    threshold = Keyword.get(opts, :threshold, @default_threshold)
    notify = Keyword.get(opts, :notify, fn _name, _status -> :ok end)

    service = %{
      check: check_func,
      interval: interval_ms,
      threshold: threshold,
      notify: notify,
      status: :up,
      failures: 0
    }

    schedule(service_name, interval_ms)
    {:reply, :ok, Map.put(services, service_name, service)}
  end

  def handle_call({:status, service_name}, _from, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} -> {:reply, {:ok, service.status}, services}
      :error -> {:reply, {:error, :not_found}, services}
    end
  end

  def handle_call(:statuses, _from, services) do
    result = Map.new(services, fn {name, service} -> {name, service.status} end)
    {:reply, result, services}
  end

  @impl true
  def handle_info({:tick, service_name}, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} ->
        schedule(service_name, service.interval)
        {:noreply, run_check(service_name, service, services)}

      :error ->
        {:noreply, services}
    end
  end

  def handle_info({:check, service_name}, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} -> {:noreply, run_check(service_name, service, services)}
      :error -> {:noreply, services}
    end
  end

  def handle_info(_msg, services) do
    {:noreply, services}
  end

  ## Internal helpers

  # Schedules the next automatic tick for a service, unless disabled.
  @spec schedule(term(), pos_integer() | :infinity) :: reference() | :infinity
  defp schedule(_service_name, :infinity), do: :infinity

  defp schedule(service_name, interval_ms) when is_integer(interval_ms) and interval_ms > 0 do
    Process.send_after(self(), {:tick, service_name}, interval_ms)
  end

  # Runs one check for a service, updating state and firing notifications.
  @spec run_check(term(), map(), map()) :: map()
  defp run_check(service_name, service, services) do
    updated = apply_result(service, service.check.())

    if updated.status != service.status do
      service.notify.(service_name, updated.status)
    end

    Map.put(services, service_name, updated)
  end

  # Computes the new service record from a check result.
  @spec apply_result(map(), :ok | {:error, term()}) :: map()
  defp apply_result(service, :ok) do
    %{service | failures: 0, status: :up}
  end

  defp apply_result(service, {:error, _reason}) do
    failures = service.failures + 1

    if failures >= service.threshold and service.status == :up do
      %{service | failures: failures, status: :down}
    else
      %{service | failures: failures}
    end
  end
end
```

## Failing test report

```
1 of 12 test(s) failed:

  * test threshold defaults to 3
      
      
      match (=) failed
      code:  assert {:ok, :down} = Monitor.status(server, "svc")
      left:  {:ok, :down}
      right: {:ok, :up}
```
