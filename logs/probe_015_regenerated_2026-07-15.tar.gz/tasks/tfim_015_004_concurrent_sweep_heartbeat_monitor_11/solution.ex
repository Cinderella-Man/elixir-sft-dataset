  test "re-enrolling a name resets its state", %{server: server} do
    :ok = AsyncMonitor.enroll(server, "svc", script([{:error, :boom}]), threshold: 1)
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")

    :ok = AsyncMonitor.enroll(server, "svc", script([:ok]))
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
  end