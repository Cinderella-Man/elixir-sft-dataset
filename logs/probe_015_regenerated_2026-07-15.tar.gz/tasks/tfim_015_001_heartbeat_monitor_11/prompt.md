# Fill in the middle: implement the blanked test

Below is a module and its ExUnit test harness with the body of ONE `test` removed
(marked `# TODO`). The test's name states what it must verify. Implement just that one
test so the harness passes for a correct implementation of the module.

## Module under test

```elixir
defmodule Monitor do
  @moduledoc """
  A `GenServer` that supervises a set of registered services by periodically
  running a health-check function for each one and tracking whether the service
  is currently `:up` or `:down`.

  Each service is registered with a zero-arity check function returning `:ok`
  (healthy) or `{:error, reason}` (unhealthy). A service becomes `:down` after a
  configurable number of *consecutive* failed checks, and returns to `:up` on the
  first subsequent healthy check. A `:notify` callback is invoked exactly once on
  every actual status transition.

  Checks are run synchronously inside the server process. Automatic checks are
  scheduled with `Process.send_after/3` on a per-service interval; the first
  automatic check fires one interval after registration. A check can also be
  triggered manually by sending the server `{:check, service_name}`.

  Uses only the OTP standard library.
  """

  use GenServer

  @default_threshold 3

  @typedoc "Current health status of a service."
  @type status :: :up | :down

  @typedoc "A zero-arity health-check function."
  @type check_func :: (-> :ok | {:error, term()})

  # Internal per-service record.
  # %{
  #   check: check_func,
  #   interval: pos_integer() | :infinity,
  #   threshold: pos_integer(),
  #   notify: (term(), status -> any()),
  #   status: status(),
  #   failures: non_neg_integer()
  # }

  ## Public API

  @doc """
  Starts the monitor process, linked to the caller.

  When `opts` contains a `:name`, it is used for process registration; otherwise
  the process starts unregistered. A freshly started server tracks zero services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    case Keyword.fetch(opts, :name) do
      {:ok, name} -> GenServer.start_link(__MODULE__, :ok, name: name)
      :error -> GenServer.start_link(__MODULE__, :ok)
    end
  end

  @doc """
  Registers a service to be monitored and returns `:ok`.

  `check_func` is a zero-arity function returning `:ok` or `{:error, reason}`.
  `interval_ms` is a positive integer number of milliseconds between automatic
  checks, or `:infinity` to disable automatic checks. `opts` may contain a
  positive-integer `:threshold` (default `3`) and an arity-2 `:notify` callback.

  Registering an existing `service_name` replaces its configuration and resets it
  to the initial state (`:up`, zero consecutive failures).
  """
  @spec register(
          GenServer.server(),
          term(),
          check_func(),
          pos_integer() | :infinity,
          keyword()
        ) :: :ok
  def register(server, service_name, check_func, interval_ms, opts \\ [])
      when is_function(check_func, 0) do
    GenServer.call(server, {:register, service_name, check_func, interval_ms, opts})
  end

  @doc """
  Returns `{:ok, :up}` or `{:ok, :down}` for a registered service, or
  `{:error, :not_found}` if the service has never been registered.
  """
  @spec status(GenServer.server(), term()) :: {:ok, status()} | {:error, :not_found}
  def status(server, service_name) do
    GenServer.call(server, {:status, service_name})
  end

  @doc """
  Returns a map of every currently registered service to its current status.

  For a server with no registered services this is the empty map `%{}`.
  """
  @spec statuses(GenServer.server()) :: %{optional(term()) => status()}
  def statuses(server) do
    GenServer.call(server, :statuses)
  end

  ## GenServer callbacks

  @impl true
  @spec init(:ok) :: {:ok, %{optional(term()) => map()}}
  def init(:ok) do
    {:ok, %{}}
  end

  @impl true
  def handle_call({:register, service_name, check_func, interval_ms, opts}, _from, services) do
    threshold = Keyword.get(opts, :threshold, @default_threshold)
    notify = Keyword.get(opts, :notify, fn _name, _status -> :ok end)

    service = %{
      check: check_func,
      interval: interval_ms,
      threshold: threshold,
      notify: notify,
      status: :up,
      failures: 0
    }

    schedule(service_name, interval_ms)
    {:reply, :ok, Map.put(services, service_name, service)}
  end

  def handle_call({:status, service_name}, _from, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} -> {:reply, {:ok, service.status}, services}
      :error -> {:reply, {:error, :not_found}, services}
    end
  end

  def handle_call(:statuses, _from, services) do
    result = Map.new(services, fn {name, service} -> {name, service.status} end)
    {:reply, result, services}
  end

  @impl true
  def handle_info({:tick, service_name}, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} ->
        schedule(service_name, service.interval)
        {:noreply, run_check(service_name, service, services)}

      :error ->
        {:noreply, services}
    end
  end

  def handle_info({:check, service_name}, services) do
    case Map.fetch(services, service_name) do
      {:ok, service} -> {:noreply, run_check(service_name, service, services)}
      :error -> {:noreply, services}
    end
  end

  def handle_info(_msg, services) do
    {:noreply, services}
  end

  ## Internal helpers

  # Schedules the next automatic tick for a service, unless disabled.
  @spec schedule(term(), pos_integer() | :infinity) :: reference() | :infinity
  defp schedule(_service_name, :infinity), do: :infinity

  defp schedule(service_name, interval_ms) when is_integer(interval_ms) and interval_ms > 0 do
    Process.send_after(self(), {:tick, service_name}, interval_ms)
  end

  # Runs one check for a service, updating state and firing notifications.
  @spec run_check(term(), map(), map()) :: map()
  defp run_check(service_name, service, services) do
    updated = apply_result(service, service.check.())

    if updated.status != service.status do
      service.notify.(service_name, updated.status)
    end

    Map.put(services, service_name, updated)
  end

  # Computes the new service record from a check result.
  @spec apply_result(map(), :ok | {:error, term()}) :: map()
  defp apply_result(service, :ok) do
    %{service | failures: 0, status: :up}
  end

  defp apply_result(service, {:error, _reason}) do
    failures = service.failures + 1

    if failures >= service.threshold and service.status == :up do
      %{service | failures: failures, status: :down}
    else
      %{service | failures: failures}
    end
  end
end
```

## Test harness — implement the `# TODO` test

```elixir
defmodule MonitorTest do
  use ExUnit.Case, async: false

  # --- Deterministic scripted check functions ---
  #
  # `script([...])` returns a zero-arity function that yields the given results in
  # order on successive calls; once the list is down to a single element, that
  # element is returned on every subsequent call. This makes "always fails" /
  # "fails then recovers" check functions fully deterministic.

  defp script(list) do
    {:ok, pid} = Agent.start_link(fn -> list end)
    fn -> next(pid) end
  end

  defp next(pid) do
    Agent.get_and_update(pid, fn
      [x] -> {x, [x]}
      [x | rest] -> {x, rest}
      [] -> {:ok, []}
    end)
  end

  setup do
    {:ok, server} = Monitor.start_link([])
    %{server: server}
  end

  # -------------------------------------------------------
  # Registration basics
  # -------------------------------------------------------

  test "register returns :ok and a new service starts :up", %{server: server} do
    assert :ok =
             Monitor.register(server, "svc", script([:ok]), :infinity)

    assert {:ok, :up} = Monitor.status(server, "svc")
  end

  test "statuses lists all registered services and is empty at first", %{server: server} do
    assert Monitor.statuses(server) == %{}

    :ok = Monitor.register(server, "a", script([:ok]), :infinity)
    :ok = Monitor.register(server, "b", script([:ok]), :infinity)

    assert Monitor.statuses(server) == %{"a" => :up, "b" => :up}
  end

  test "status of an unknown service is {:error, :not_found}", %{server: server} do
    assert {:error, :not_found} = Monitor.status(server, "nope")
  end

  # -------------------------------------------------------
  # Staying up
  # -------------------------------------------------------

  test "a healthy service stays up and never notifies", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok = Monitor.register(server, "svc", script([:ok]), :infinity, notify: notify)

    for _ <- 1..5, do: send(server, {:check, "svc"})

    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 100
  end

  # -------------------------------------------------------
  # Transition :up -> :down at the threshold, exactly once
  # -------------------------------------------------------

  test "service goes down after N consecutive failures, notifying once", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok =
      Monitor.register(server, "svc", script([{:error, :boom}]), :infinity,
        threshold: 3,
        notify: notify
      )

    # Two failures: still up, no notification.
    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 50

    # Third consecutive failure: down, notify once.
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}

    # Further failures while already down: stays down, no further notification.
    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 100
  end

  test "threshold defaults to 3", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok = Monitor.register(server, "svc", script([{:error, :boom}]), :infinity, notify: notify)

    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")

    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}
  end

  # -------------------------------------------------------
  # Consecutive-only counting
  # -------------------------------------------------------

  test "a healthy check resets the consecutive-failure count", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    # error, error, ok, error, error  -> never 3 in a row -> stays up
    seq = [
      {:error, :boom},
      {:error, :boom},
      :ok,
      {:error, :boom},
      {:error, :boom},
      {:error, :boom}
    ]

    :ok = Monitor.register(server, "svc", script(seq), :infinity, threshold: 3, notify: notify)

    for _ <- 1..5, do: send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 50

    # Sixth check is the third failure of an unbroken run -> down.
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}
  end

  # -------------------------------------------------------
  # Recovery :down -> :up
  # -------------------------------------------------------

  test "service recovers to up and notifies on the way back", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    seq = [{:error, :boom}, {:error, :boom}, {:error, :boom}, :ok]

    :ok = Monitor.register(server, "svc", script(seq), :infinity, threshold: 3, notify: notify)

    for _ <- 1..3, do: send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}

    # Next check succeeds -> back up, notify once.
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :up}
    refute_receive {:transition, _, _}, 100
  end

  # -------------------------------------------------------
  # Independence between services
  # -------------------------------------------------------

  test "services are independent", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok =
      Monitor.register(server, "a", script([{:error, :boom}]), :infinity,
        threshold: 1,
        notify: notify
      )

    :ok = Monitor.register(server, "b", script([:ok]), :infinity, notify: notify)

    send(server, {:check, "a"})
    assert {:ok, :down} = Monitor.status(server, "a")
    assert_receive {:transition, "a", :down}

    # b is untouched.
    assert {:ok, :up} = Monitor.status(server, "b")
    assert Monitor.statuses(server) == %{"a" => :down, "b" => :up}
    refute_receive {:transition, "b", _}, 50
  end

  # -------------------------------------------------------
  # Automatic periodic checks
  # -------------------------------------------------------

  test "automatic interval checks drive the service down", %{server: server} do
    # TODO
  end

  # -------------------------------------------------------
  # Robustness
  # -------------------------------------------------------

  test "unexpected messages are ignored and do not disturb state", %{server: server} do
    :ok = Monitor.register(server, "svc", script([:ok]), :infinity)

    send(server, :hello)
    send(server, {:weird, 1, 2})
    send(server, {:check, "unregistered-service"})

    assert {:ok, :up} = Monitor.status(server, "svc")
    assert Process.alive?(server)
  end

  test "a service with no :notify option can transition without crashing", %{server: server} do
    :ok =
      Monitor.register(server, "svc", script([{:error, :boom}]), :infinity, threshold: 1)

    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert Process.alive?(server)
  end
end
```
