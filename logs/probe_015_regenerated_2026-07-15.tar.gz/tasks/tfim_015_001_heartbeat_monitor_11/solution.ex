  test "automatic interval checks drive the service down", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok =
      Monitor.register(server, "auto", script([{:error, :boom}]), 20,
        threshold: 1,
        notify: notify
      )

    assert_receive {:transition, "auto", :down}, 2_000
    assert {:ok, :down} = Monitor.status(server, "auto")

    # Once down, repeated automatic failures do not notify again.
    refute_receive {:transition, _, _}, 200
  end