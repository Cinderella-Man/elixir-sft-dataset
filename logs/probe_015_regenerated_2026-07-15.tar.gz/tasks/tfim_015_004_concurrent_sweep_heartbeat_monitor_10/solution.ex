  test "probes within a sweep run concurrently in separate processes", %{server: server} do
    me = self()

    # Each probe announces its own process pid, then blocks until told to continue.
    # Both announcements can only arrive if both probes were dispatched before the
    # sweep waited for either to finish.
    rendezvous = fn tag ->
      fn ->
        send(me, {:started, tag, self()})

        receive do
          :go -> :ok
        end
      end
    end

    :ok = AsyncMonitor.enroll(server, "a", rendezvous.(:a))
    :ok = AsyncMonitor.enroll(server, "b", rendezvous.(:b))

    sweeper = Task.async(fn -> AsyncMonitor.sweep(server) end)

    assert_receive {:started, :a, pid_a}, 1_000
    assert_receive {:started, :b, pid_b}, 1_000

    send(pid_a, :go)
    send(pid_b, :go)

    assert :ok = Task.await(sweeper, 1_000)
    assert {:ok, :up} = AsyncMonitor.status(server, "a")
    assert {:ok, :up} = AsyncMonitor.status(server, "b")
  end