  test "threshold defaults to 3", %{server: server} do
    :ok = DepMonitor.add_node(server, "n", script([{:error, :boom}]))
    assert {:ok, :up} = DepMonitor.check(server, "n")
    assert {:ok, :up} = DepMonitor.check(server, "n")
    assert {:ok, :down} = DepMonitor.check(server, "n")
  end