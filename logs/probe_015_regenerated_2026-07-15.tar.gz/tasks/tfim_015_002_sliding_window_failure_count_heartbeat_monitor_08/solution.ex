  test "non-consecutive failures within the window still trip the threshold", %{server: server} do
    # error, ok, error, ok, error -> 3 failures in a 5-wide window -> down
    seq = [{:error, :boom}, :ok, {:error, :boom}, :ok, {:error, :boom}, :ok]

    :ok = WindowMonitor.watch(server, "svc", script(seq), window: 5, threshold: 3)

    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
  end