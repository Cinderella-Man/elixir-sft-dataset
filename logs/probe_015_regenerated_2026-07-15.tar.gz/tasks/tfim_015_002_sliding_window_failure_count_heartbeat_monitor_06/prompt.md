# Fill in the middle: implement the blanked test

Below is a module and its ExUnit test harness with the body of ONE `test` removed
(marked `# TODO`). The test's name states what it must verify. Implement just that one
test so the harness passes for a correct implementation of the module.

## Module under test

```elixir
defmodule WindowMonitor do
  @moduledoc """
  A `GenServer` that watches registered services and classifies each as `:up`
  or `:down` using a **sliding window of recent probe results**.

  For every watched service the server retains only its `:window` most-recent
  probe outcomes. After each probe it counts how many of those retained results
  were failures (`f`) and compares against the configured `:threshold` (`t`):
  the service is `:down` when `f >= t`, otherwise `:up`. Because the window
  slides, failures need not be consecutive and a service recovers on its own
  once enough healthy results push failures out of the window.

  Services are independent — one service's results, window, or status never
  affect another's. On each actual status change the service's `:on_change`
  callback is invoked exactly once. Unknown messages are ignored.

  Only the OTP standard library is used.
  """

  use GenServer

  @typedoc "A zero-arity health probe."
  @type probe :: (-> :ok | {:error, term()})

  @typedoc "A service status."
  @type status :: :up | :down

  # ── Public API ────────────────────────────────────────────────────────────

  @doc """
  Starts the monitor linked to the caller.

  When `opts` contains a `:name`, the process is registered under it; otherwise
  it starts unregistered. A freshly started server watches zero services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    case Keyword.fetch(opts, :name) do
      {:ok, name} -> GenServer.start_link(__MODULE__, opts, name: name)
      :error -> GenServer.start_link(__MODULE__, opts)
    end
  end

  @doc """
  Registers `name` to be watched using the zero-arity `probe`.

  Options: `:window` (positive integer, default `5`), `:threshold` (positive
  integer, default `3`), `:on_change` (arity-2 callback, default no-op) and
  `:interval` (positive integer milliseconds or `:manual`, default `:manual`).

  A newly watched service starts `:up` with an empty window. Re-watching an
  existing `name` replaces its configuration and resets it to this state.
  """
  @spec watch(GenServer.server(), term(), probe(), keyword()) :: :ok
  def watch(server, name, probe, opts \\ []) when is_function(probe, 0) do
    GenServer.call(server, {:watch, name, probe, opts})
  end

  @doc """
  Runs exactly one probe for `name` immediately, applies the result, and returns
  `{:ok, new_status}`. Returns `{:error, :not_found}` if `name` is not watched.
  """
  @spec probe_now(GenServer.server(), term()) ::
          {:ok, status()} | {:error, :not_found}
  def probe_now(server, name) do
    GenServer.call(server, {:probe_now, name})
  end

  @doc """
  Returns `{:ok, status}` for a watched service or `{:error, :not_found}`.
  """
  @spec health(GenServer.server(), term()) ::
          {:ok, status()} | {:error, :not_found}
  def health(server, name) do
    GenServer.call(server, {:health, name})
  end

  @doc """
  Returns a map `%{name => status}` for every currently watched service.
  """
  @spec report(GenServer.server()) :: %{optional(term()) => status()}
  def report(server) do
    GenServer.call(server, :report)
  end

  # ── GenServer callbacks ───────────────────────────────────────────────────

  @impl true
  @spec init(keyword()) :: {:ok, map()}
  def init(_opts) do
    {:ok, %{services: %{}, counter: 0}}
  end

  @impl true
  def handle_call({:watch, name, probe, opts}, _from, state) do
    window = Keyword.get(opts, :window, 5)
    threshold = Keyword.get(opts, :threshold, 3)
    on_change = Keyword.get(opts, :on_change, fn _name, _status -> :ok end)
    interval = Keyword.get(opts, :interval, :manual)
    epoch = state.counter + 1

    service = %{
      probe: probe,
      window: window,
      threshold: threshold,
      on_change: on_change,
      interval: interval,
      status: :up,
      results: [],
      epoch: epoch
    }

    maybe_schedule(name, interval, epoch)
    services = Map.put(state.services, name, service)
    {:reply, :ok, %{state | services: services, counter: epoch}}
  end

  def handle_call({:probe_now, name}, _from, state) do
    case Map.get(state.services, name) do
      nil ->
        {:reply, {:error, :not_found}, state}

      service ->
        {new_service, new_status} = probe_and_notify(name, service)
        services = Map.put(state.services, name, new_service)
        {:reply, {:ok, new_status}, %{state | services: services}}
    end
  end

  def handle_call({:health, name}, _from, state) do
    case Map.get(state.services, name) do
      nil -> {:reply, {:error, :not_found}, state}
      %{status: status} -> {:reply, {:ok, status}, state}
    end
  end

  def handle_call(:report, _from, state) do
    report = Map.new(state.services, fn {name, %{status: s}} -> {name, s} end)
    {:reply, report, state}
  end

  def handle_call(_other, _from, state) do
    {:reply, {:error, :unknown_request}, state}
  end

  @impl true
  def handle_info({:tick, name, epoch}, state) do
    case Map.get(state.services, name) do
      %{epoch: ^epoch, interval: interval} = service when is_integer(interval) ->
        {new_service, _status} = probe_and_notify(name, service)
        maybe_schedule(name, interval, epoch)
        services = Map.put(state.services, name, new_service)
        {:noreply, %{state | services: services}}

      _other ->
        {:noreply, state}
    end
  end

  def handle_info(_msg, state) do
    {:noreply, state}
  end

  @impl true
  def handle_cast(_msg, state) do
    {:noreply, state}
  end

  # ── Internal helpers ──────────────────────────────────────────────────────

  @spec maybe_schedule(term(), pos_integer() | :manual, non_neg_integer()) :: :ok
  defp maybe_schedule(name, interval, epoch) when is_integer(interval) do
    Process.send_after(self(), {:tick, name, epoch}, interval)
    :ok
  end

  defp maybe_schedule(_name, :manual, _epoch), do: :ok

  @spec probe_and_notify(term(), map()) :: {map(), status()}
  defp probe_and_notify(name, service) do
    outcome = run_probe(service.probe)
    results = Enum.take([outcome | service.results], service.window)
    failures = Enum.count(results, &(&1 == :fail))
    new_status = if failures >= service.threshold, do: :down, else: :up

    if new_status != service.status do
      service.on_change.(name, new_status)
    end

    {%{service | results: results, status: new_status}, new_status}
  end

  @spec run_probe(probe()) :: :ok | :fail
  defp run_probe(probe) do
    case probe.() do
      :ok -> :ok
      _other -> :fail
    end
  end
end
```

## Test harness — implement the `# TODO` test

```elixir
defmodule WindowMonitorTest do
  use ExUnit.Case, async: false

  # Deterministic scripted probe: yields the given results in order on successive
  # calls; once a single element remains, that element repeats forever.
  defp script(list) do
    {:ok, pid} = Agent.start_link(fn -> list end)
    fn -> next(pid) end
  end

  defp next(pid) do
    Agent.get_and_update(pid, fn
      [x] -> {x, [x]}
      [x | rest] -> {x, rest}
      [] -> {:ok, []}
    end)
  end

  setup do
    {:ok, server} = WindowMonitor.start_link([])
    %{server: server}
  end

  test "watch returns :ok, a new service is :up, and report starts empty", %{server: server} do
    assert WindowMonitor.report(server) == %{}
    assert :ok = WindowMonitor.watch(server, "svc", script([:ok]))
    assert {:ok, :up} = WindowMonitor.health(server, "svc")
    assert WindowMonitor.report(server) == %{"svc" => :up}
  end

  test "report lists all watched services", %{server: server} do
    :ok = WindowMonitor.watch(server, "a", script([:ok]))
    :ok = WindowMonitor.watch(server, "b", script([:ok]))
    assert WindowMonitor.report(server) == %{"a" => :up, "b" => :up}
  end

  test "health and probe_now on an unknown service return {:error, :not_found}", %{
    server: server
  } do
    assert {:error, :not_found} = WindowMonitor.health(server, "nope")
    assert {:error, :not_found} = WindowMonitor.probe_now(server, "nope")
  end

  test "probe_now returns {:ok, status}", %{server: server} do
    :ok = WindowMonitor.watch(server, "svc", script([:ok]))
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
  end

  test "service goes down when window failure count reaches threshold, notifying once",
    # TODO
  end

  test "threshold and window default to 3 and 5", %{server: server} do
    :ok = WindowMonitor.watch(server, "svc", script([{:error, :boom}]))
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
  end

  test "non-consecutive failures within the window still trip the threshold", %{server: server} do
    # error, ok, error, ok, error -> 3 failures in a 5-wide window -> down
    seq = [{:error, :boom}, :ok, {:error, :boom}, :ok, {:error, :boom}, :ok]

    :ok = WindowMonitor.watch(server, "svc", script(seq), window: 5, threshold: 3)

    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
  end

  test "a service recovers automatically as failures slide out of the window", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    seq = [{:error, :boom}, {:error, :boom}, {:error, :boom}, :ok, :ok, :ok, :ok]

    :ok =
      WindowMonitor.watch(server, "svc", script(seq),
        window: 5,
        threshold: 3,
        on_change: on_change
      )

    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
    assert_receive {:change, "svc", :down}

    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
    # 6th probe: window now holds only 2 failures -> back up.
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert_receive {:change, "svc", :up}
    refute_receive {:change, _, _}, 100
  end

  test "services are independent", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      WindowMonitor.watch(server, "a", script([{:error, :boom}]),
        threshold: 1,
        on_change: on_change
      )

    :ok = WindowMonitor.watch(server, "b", script([:ok]), on_change: on_change)

    assert {:ok, :down} = WindowMonitor.probe_now(server, "a")
    assert_receive {:change, "a", :down}
    assert {:ok, :up} = WindowMonitor.health(server, "b")
    assert WindowMonitor.report(server) == %{"a" => :down, "b" => :up}
    refute_receive {:change, "b", _}, 50
  end

  test "automatic interval probing drives a service down", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      WindowMonitor.watch(server, "auto", script([{:error, :boom}]),
        threshold: 1,
        interval: 20,
        on_change: on_change
      )

    assert_receive {:change, "auto", :down}, 2_000
    assert {:ok, :down} = WindowMonitor.health(server, "auto")
    refute_receive {:change, _, _}, 200
  end

  test "re-watching a name resets its state", %{server: server} do
    :ok = WindowMonitor.watch(server, "svc", script([{:error, :boom}]), threshold: 1)
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")

    :ok = WindowMonitor.watch(server, "svc", script([:ok]))
    assert {:ok, :up} = WindowMonitor.health(server, "svc")
    assert WindowMonitor.report(server) == %{"svc" => :up}
  end

  test "unexpected messages are ignored and do not disturb state", %{server: server} do
    :ok = WindowMonitor.watch(server, "svc", script([:ok]))
    send(server, :hello)
    send(server, {:weird, 1, 2})
    assert {:ok, :up} = WindowMonitor.health(server, "svc")
    assert Process.alive?(server)
  end

  test "unexpected casts are ignored and do not crash the server", %{server: server} do
    # Register a service so we can prove its state survives the casts untouched.
    :ok = WindowMonitor.watch(server, "svc", script([{:error, :boom}]), threshold: 1)

    # A gutted handle_cast/2 (one that raises) would crash the server here; the
    # follow-up synchronous calls would then exit instead of returning cleanly.
    assert :ok = GenServer.cast(server, :hello)
    assert :ok = GenServer.cast(server, {:weird, 1, 2})

    # The server must still be alive and its state must be exactly as before:
    # the casts must not have probed "svc" (which would flip it :down).
    assert Process.alive?(server)
    assert {:ok, :up} = WindowMonitor.health(server, "svc")
    assert WindowMonitor.report(server) == %{"svc" => :up}

    # And it must still function normally after ignoring the casts.
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
  end

  test "a manual (default interval) service is never probed automatically", %{server: server} do
    # Probe would fail with threshold 1, so any automatic probe would flip it :down.
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      WindowMonitor.watch(server, "svc", script([{:error, :boom}]),
        threshold: 1,
        on_change: on_change
      )

    # No :interval given -> :manual; nothing should probe it on its own.
    refute_receive {:change, _, _}, 150
    assert {:ok, :up} = WindowMonitor.health(server, "svc")
    assert WindowMonitor.report(server) == %{"svc" => :up}
  end

  test "probe_now only probes the named service, leaving others untouched", %{server: server} do
    :ok = WindowMonitor.watch(server, "a", script([{:error, :boom}]), threshold: 1)
    :ok = WindowMonitor.watch(server, "b", script([{:error, :boom}]), threshold: 1)

    assert {:ok, :down} = WindowMonitor.probe_now(server, "a")
    # "b" was never probed, so it must still be :up with an empty window.
    assert {:ok, :up} = WindowMonitor.health(server, "b")
    assert WindowMonitor.report(server) == %{"a" => :down, "b" => :up}
  end
end
```
