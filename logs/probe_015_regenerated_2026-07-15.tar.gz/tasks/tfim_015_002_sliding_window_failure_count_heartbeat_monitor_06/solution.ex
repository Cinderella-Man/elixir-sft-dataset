  test "service goes down when window failure count reaches threshold, notifying once",
       %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      WindowMonitor.watch(server, "svc", script([{:error, :boom}]),
        window: 5,
        threshold: 3,
        on_change: on_change
      )

    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    refute_receive {:change, _, _}, 50

    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
    assert_receive {:change, "svc", :down}

    # Still failing while already down: no further notification.
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
    refute_receive {:change, _, _}, 100
  end