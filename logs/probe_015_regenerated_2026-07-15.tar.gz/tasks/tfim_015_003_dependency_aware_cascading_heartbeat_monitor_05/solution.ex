  test "a consecutive-failure run is broken by any success", %{server: server} do
    seq = [{:error, :boom}, {:error, :boom}, :ok, {:error, :boom}, {:error, :boom}]
    :ok = DepMonitor.add_node(server, "n", script(seq), threshold: 3)
    for _ <- 1..5, do: assert({:ok, _} = DepMonitor.check(server, "n"))
    assert {:ok, :up} = DepMonitor.direct_status(server, "n")
  end