  test "probe_now returns {:ok, status}", %{server: server} do
    :ok = WindowMonitor.watch(server, "svc", script([:ok]))
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
  end