  test "recovery of a dependency cascades back up", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:eff, n, s}) end

    :ok =
      DepMonitor.add_node(server, "B", script([{:error, :boom}, :ok]),
        threshold: 1,
        on_change: on_change
      )

    :ok = DepMonitor.add_node(server, "A", script([:ok]), depends_on: ["B"], on_change: on_change)

    assert {:ok, :down} = DepMonitor.check(server, "B")
    assert_receive {:eff, "B", :down}
    assert_receive {:eff, "A", :down}

    assert {:ok, :up} = DepMonitor.check(server, "B")
    assert {:ok, :up} = DepMonitor.effective_status(server, "A")
    assert_receive {:eff, "B", :up}
    assert_receive {:eff, "A", :up}
  end