  test "report lists all watched services", %{server: server} do
    :ok = WindowMonitor.watch(server, "a", script([:ok]))
    :ok = WindowMonitor.watch(server, "b", script([:ok]))
    assert WindowMonitor.report(server) == %{"a" => :up, "b" => :up}
  end