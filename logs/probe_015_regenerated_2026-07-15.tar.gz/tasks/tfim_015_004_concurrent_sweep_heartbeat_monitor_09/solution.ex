  test "services are independent within a sweep", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      AsyncMonitor.enroll(server, "a", script([{:error, :boom}]),
        threshold: 1,
        on_change: on_change
      )

    :ok = AsyncMonitor.enroll(server, "b", script([:ok]), on_change: on_change)

    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "a")
    assert {:ok, :up} = AsyncMonitor.status(server, "b")
    assert AsyncMonitor.overview(server) == %{"a" => :down, "b" => :up}
    assert_receive {:change, "a", :down}
    refute_receive {:change, "b", _}, 50
  end