# Fix the bug

The module below was written for the task that follows, but ONE behavior bug
slipped in. The test suite (not shown) fails with the report at the bottom.
Find the bug and fix it — change as little as possible; do not restructure
working code. Reply with the complete corrected module.

## The task the module implements

# Sliding-Window Failure-Count Heartbeat Monitor

Write me an Elixir `GenServer` module called `WindowMonitor` that watches a set of
registered services by running a health *probe* for each one and deciding whether
the service is `:up` or `:down` based on **how many of its most recent probe
results were failures** — a sliding window, not a run of consecutive failures.

Use only the OTP standard library — no external dependencies. Give me the complete
module in a single file.

## Public API

- `WindowMonitor.start_link(opts \\ [])` — starts the process, linked to the caller,
  returning the usual `GenServer.on_start()` result. `opts` is a keyword list
  defaulting to `[]`. When a `:name` option is present it is used for process
  registration (so the other functions accept either the pid or the registered
  name); when absent the process starts unregistered. A freshly started server
  watches zero services.

- `WindowMonitor.watch(server, name, probe, opts \\ [])` — registers a service to
  be watched and returns `:ok`.
  - `name` is any term identifying the service (compared by value).
  - `probe` is a **zero-arity** function returning either `:ok` (healthy) or
    `{:error, reason}` (unhealthy); `reason` may be any term. Guard the public
    function with `is_function(probe, 0)`.
  - `opts` may contain:
    - `:window` — a positive integer, the number of most-recent probe results the
      server retains for this service. Defaults to `5`.
    - `:threshold` — a positive integer, the number of failures **within the
      retained window** at or above which the service is considered `:down`.
      Defaults to `3`.
    - `:on_change` — an arity-2 function called as `on_change.(name, new_status)`
      on each status transition (see below). Defaults to a no-op.
    - `:interval` — a positive integer number of milliseconds, or the atom
      `:manual` (the default). When a positive integer, the server automatically
      probes this service on that interval using `Process.send_after/3`; the first
      automatic probe fires one interval after `watch`, and probing repeats
      indefinitely. When `:manual`, the service is only probed via `probe_now/2`.
  - A newly watched service starts with status `:up` and an **empty** result
    window. Watching a `name` that already exists replaces its configuration and
    resets it to this initial state.

- `WindowMonitor.probe_now(server, name)` — runs exactly one probe for the named
  service immediately (the same work an automatic tick performs), applies the
  result, and returns `{:ok, new_status}` where `new_status` is that service's
  status after the probe. Returns `{:error, :not_found}` if `name` is not watched.

- `WindowMonitor.health(server, name)` — returns `{:ok, :up}` / `{:ok, :down}` for
  a watched service, or `{:error, :not_found}` if it was never watched.

- `WindowMonitor.report(server)` — returns a map `%{name => :up | :down}` of every
  currently watched service and its current status. Empty map `%{}` when nothing is
  watched.

## Running a probe

A single probe invokes the service's `probe` function (**synchronously inside the
server process**) and records the outcome as either a success or a failure. The
server keeps only the `:window` most-recent outcomes for the service (older ones are
discarded). After recording:

- Let `f` be the number of **failures among the retained results** (at most
  `:window` of them) and `t` be `:threshold`.
- The new status is `:down` when `f >= t`, otherwise `:up`.
- The status is recomputed from the window on **every** probe. Because the window
  slides, a service can recover automatically: once enough healthy results push
  failures out of the window so that `f < t`, it returns to `:up` — no explicit
  "success streak" is required.

Failures do **not** have to be consecutive. For example with `window: 5` and
`threshold: 3`, the sequence error, ok, error, ok, error leaves three failures in
the window and marks the service `:down`, even though no two failures were adjacent.

## Status transitions and notifications

A "transition" is any change of the status field (`:up` → `:down` or
`:down` → `:up`). On each actual change — and only then — the service's `:on_change`
function is called exactly once as `on_change.(name, new_status)` with the status
just entered. A probe that leaves the status unchanged calls nothing.

## Independence and robustness

- Services are fully independent: one service's results, window, or status never
  affect another's.
- Any message the server does not understand must be ignored: it must neither crash
  the process nor alter any service's state.

## The buggy module

```elixir
defmodule WindowMonitor do
  @moduledoc """
  A `GenServer` that watches registered services and classifies each as `:up`
  or `:down` using a **sliding window of recent probe results**.

  For every watched service the server retains only its `:window` most-recent
  probe outcomes. After each probe it counts how many of those retained results
  were failures (`f`) and compares against the configured `:threshold` (`t`):
  the service is `:down` when `f >= t`, otherwise `:up`. Because the window
  slides, failures need not be consecutive and a service recovers on its own
  once enough healthy results push failures out of the window.

  Services are independent — one service's results, window, or status never
  affect another's. On each actual status change the service's `:on_change`
  callback is invoked exactly once. Unknown messages are ignored.

  Only the OTP standard library is used.
  """

  use GenServer

  @typedoc "A zero-arity health probe."
  @type probe :: (-> :ok | {:error, term()})

  @typedoc "A service status."
  @type status :: :up | :down

  # ── Public API ────────────────────────────────────────────────────────────

  @doc """
  Starts the monitor linked to the caller.

  When `opts` contains a `:name`, the process is registered under it; otherwise
  it starts unregistered. A freshly started server watches zero services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    case Keyword.fetch(opts, :name) do
      {:ok, name} -> GenServer.start_link(__MODULE__, opts, name: name)
      :error -> GenServer.start_link(__MODULE__, opts)
    end
  end

  @doc """
  Registers `name` to be watched using the zero-arity `probe`.

  Options: `:window` (positive integer, default `5`), `:threshold` (positive
  integer, default `3`), `:on_change` (arity-2 callback, default no-op) and
  `:interval` (positive integer milliseconds or `:manual`, default `:manual`).

  A newly watched service starts `:up` with an empty window. Re-watching an
  existing `name` replaces its configuration and resets it to this state.
  """
  @spec watch(GenServer.server(), term(), probe(), keyword()) :: :ok
  def watch(server, name, probe, opts \\ []) when is_function(probe, 1) do
    GenServer.call(server, {:watch, name, probe, opts})
  end

  @doc """
  Runs exactly one probe for `name` immediately, applies the result, and returns
  `{:ok, new_status}`. Returns `{:error, :not_found}` if `name` is not watched.
  """
  @spec probe_now(GenServer.server(), term()) ::
          {:ok, status()} | {:error, :not_found}
  def probe_now(server, name) do
    GenServer.call(server, {:probe_now, name})
  end

  @doc """
  Returns `{:ok, status}` for a watched service or `{:error, :not_found}`.
  """
  @spec health(GenServer.server(), term()) ::
          {:ok, status()} | {:error, :not_found}
  def health(server, name) do
    GenServer.call(server, {:health, name})
  end

  @doc """
  Returns a map `%{name => status}` for every currently watched service.
  """
  @spec report(GenServer.server()) :: %{optional(term()) => status()}
  def report(server) do
    GenServer.call(server, :report)
  end

  # ── GenServer callbacks ───────────────────────────────────────────────────

  @impl true
  @spec init(keyword()) :: {:ok, map()}
  def init(_opts) do
    {:ok, %{services: %{}, counter: 0}}
  end

  @impl true
  def handle_call({:watch, name, probe, opts}, _from, state) do
    window = Keyword.get(opts, :window, 5)
    threshold = Keyword.get(opts, :threshold, 3)
    on_change = Keyword.get(opts, :on_change, fn _name, _status -> :ok end)
    interval = Keyword.get(opts, :interval, :manual)
    epoch = state.counter + 1

    service = %{
      probe: probe,
      window: window,
      threshold: threshold,
      on_change: on_change,
      interval: interval,
      status: :up,
      results: [],
      epoch: epoch
    }

    maybe_schedule(name, interval, epoch)
    services = Map.put(state.services, name, service)
    {:reply, :ok, %{state | services: services, counter: epoch}}
  end

  def handle_call({:probe_now, name}, _from, state) do
    case Map.get(state.services, name) do
      nil ->
        {:reply, {:error, :not_found}, state}

      service ->
        {new_service, new_status} = probe_and_notify(name, service)
        services = Map.put(state.services, name, new_service)
        {:reply, {:ok, new_status}, %{state | services: services}}
    end
  end

  def handle_call({:health, name}, _from, state) do
    case Map.get(state.services, name) do
      nil -> {:reply, {:error, :not_found}, state}
      %{status: status} -> {:reply, {:ok, status}, state}
    end
  end

  def handle_call(:report, _from, state) do
    report = Map.new(state.services, fn {name, %{status: s}} -> {name, s} end)
    {:reply, report, state}
  end

  def handle_call(_other, _from, state) do
    {:reply, {:error, :unknown_request}, state}
  end

  @impl true
  def handle_info({:tick, name, epoch}, state) do
    case Map.get(state.services, name) do
      %{epoch: ^epoch, interval: interval} = service when is_integer(interval) ->
        {new_service, _status} = probe_and_notify(name, service)
        maybe_schedule(name, interval, epoch)
        services = Map.put(state.services, name, new_service)
        {:noreply, %{state | services: services}}

      _other ->
        {:noreply, state}
    end
  end

  def handle_info(_msg, state) do
    {:noreply, state}
  end

  @impl true
  def handle_cast(_msg, state) do
    {:noreply, state}
  end

  # ── Internal helpers ──────────────────────────────────────────────────────

  @spec maybe_schedule(term(), pos_integer() | :manual, non_neg_integer()) :: :ok
  defp maybe_schedule(name, interval, epoch) when is_integer(interval) do
    Process.send_after(self(), {:tick, name, epoch}, interval)
    :ok
  end

  defp maybe_schedule(_name, :manual, _epoch), do: :ok

  @spec probe_and_notify(term(), map()) :: {map(), status()}
  defp probe_and_notify(name, service) do
    outcome = run_probe(service.probe)
    results = Enum.take([outcome | service.results], service.window)
    failures = Enum.count(results, &(&1 == :fail))
    new_status = if failures >= service.threshold, do: :down, else: :up

    if new_status != service.status do
      service.on_change.(name, new_status)
    end

    {%{service | results: results, status: new_status}, new_status}
  end

  @spec run_probe(probe()) :: :ok | :fail
  defp run_probe(probe) do
    case probe.() do
      :ok -> :ok
      _other -> :fail
    end
  end
end
```

## Failing test report

```
14 of 15 test(s) failed:

  * test watch returns :ok, a new service is :up, and report starts empty
      no function clause matching in WindowMonitor.watch/4

  * test report lists all watched services
      no function clause matching in WindowMonitor.watch/4

  * test probe_now returns {:ok, status}
      no function clause matching in WindowMonitor.watch/4

  * test service goes down when window failure count reaches threshold, notifying once
      no function clause matching in WindowMonitor.watch/4

  (…10 more)
```
