  test "a healthy probe resets the consecutive-failure count", %{server: server} do
    seq = [{:error, :boom}, {:error, :boom}, :ok, {:error, :boom}, {:error, :boom}]
    :ok = AsyncMonitor.enroll(server, "svc", script(seq), threshold: 3)
    for _ <- 1..5, do: assert(:ok = AsyncMonitor.sweep(server))
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
  end