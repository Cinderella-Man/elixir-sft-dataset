  test "threshold defaults to 3", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok = Monitor.register(server, "svc", script([{:error, :boom}]), :infinity, notify: notify)

    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")

    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}
  end