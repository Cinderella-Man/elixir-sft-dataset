  test "enroll returns :ok, a new service is up, overview starts empty", %{server: server} do
    assert AsyncMonitor.overview(server) == %{}
    assert :ok = AsyncMonitor.enroll(server, "svc", script([:ok]))
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert AsyncMonitor.overview(server) == %{"svc" => :up}
  end