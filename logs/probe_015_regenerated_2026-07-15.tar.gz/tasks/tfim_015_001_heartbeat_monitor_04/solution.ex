  test "status of an unknown service is {:error, :not_found}", %{server: server} do
    assert {:error, :not_found} = Monitor.status(server, "nope")
  end