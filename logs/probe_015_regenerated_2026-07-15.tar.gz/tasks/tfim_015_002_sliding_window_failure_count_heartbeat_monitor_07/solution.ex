  test "threshold and window default to 3 and 5", %{server: server} do
    :ok = WindowMonitor.watch(server, "svc", script([{:error, :boom}]))
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :up} = WindowMonitor.probe_now(server, "svc")
    assert {:ok, :down} = WindowMonitor.probe_now(server, "svc")
  end