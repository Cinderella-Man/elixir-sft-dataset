  test "service goes down after N consecutive failures, notifying once", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok =
      Monitor.register(server, "svc", script([{:error, :boom}]), :infinity,
        threshold: 3,
        notify: notify
      )

    # Two failures: still up, no notification.
    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :up} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 50

    # Third consecutive failure: down, notify once.
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    assert_receive {:transition, "svc", :down}

    # Further failures while already down: stays down, no further notification.
    send(server, {:check, "svc"})
    send(server, {:check, "svc"})
    assert {:ok, :down} = Monitor.status(server, "svc")
    refute_receive {:transition, _, _}, 100
  end