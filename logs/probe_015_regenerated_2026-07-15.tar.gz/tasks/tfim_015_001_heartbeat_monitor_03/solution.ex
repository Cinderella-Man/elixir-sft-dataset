  test "statuses lists all registered services and is empty at first", %{server: server} do
    assert Monitor.statuses(server) == %{}

    :ok = Monitor.register(server, "a", script([:ok]), :infinity)
    :ok = Monitor.register(server, "b", script([:ok]), :infinity)

    assert Monitor.statuses(server) == %{"a" => :up, "b" => :up}
  end