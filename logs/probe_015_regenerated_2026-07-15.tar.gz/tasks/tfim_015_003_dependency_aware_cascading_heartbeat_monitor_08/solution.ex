  test "cascades are transitive across a chain A -> B -> C", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:eff, n, s}) end

    :ok =
      DepMonitor.add_node(server, "C", script([{:error, :boom}]),
        threshold: 1,
        on_change: on_change
      )

    :ok = DepMonitor.add_node(server, "B", script([:ok]), depends_on: ["C"], on_change: on_change)
    :ok = DepMonitor.add_node(server, "A", script([:ok]), depends_on: ["B"], on_change: on_change)

    assert {:ok, :down} = DepMonitor.check(server, "C")
    assert {:ok, :down} = DepMonitor.effective_status(server, "B")
    assert {:ok, :down} = DepMonitor.effective_status(server, "A")

    assert_receive {:eff, "C", :down}
    assert_receive {:eff, "B", :down}
    assert_receive {:eff, "A", :down}
  end