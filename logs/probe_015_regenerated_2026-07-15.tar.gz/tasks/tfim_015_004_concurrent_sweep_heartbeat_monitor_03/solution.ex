  test "status of an unknown service is {:error, :not_found}", %{server: server} do
    assert {:error, :not_found} = AsyncMonitor.status(server, "nope")
  end