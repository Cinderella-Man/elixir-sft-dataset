  test "watch returns :ok, a new service is :up, and report starts empty", %{server: server} do
    assert WindowMonitor.report(server) == %{}
    assert :ok = WindowMonitor.watch(server, "svc", script([:ok]))
    assert {:ok, :up} = WindowMonitor.health(server, "svc")
    assert WindowMonitor.report(server) == %{"svc" => :up}
  end