  test "automatic interval probing drives a node's own status down", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:eff, n, s}) end

    :ok =
      DepMonitor.add_node(server, "auto", script([{:error, :boom}]),
        threshold: 1,
        interval: 20,
        on_change: on_change
      )

    assert_receive {:eff, "auto", :down}, 2_000
    assert {:ok, :down} = DepMonitor.effective_status(server, "auto")
  end