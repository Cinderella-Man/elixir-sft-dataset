  test "a service recovers to up and notifies", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    seq = [{:error, :boom}, {:error, :boom}, {:error, :boom}, :ok]
    :ok = AsyncMonitor.enroll(server, "svc", script(seq), threshold: 3, on_change: on_change)

    for _ <- 1..3, do: assert(:ok = AsyncMonitor.sweep(server))
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    assert_receive {:change, "svc", :down}

    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    assert_receive {:change, "svc", :up}
  end