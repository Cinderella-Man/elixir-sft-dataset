  test "re-adding a node resets it", %{server: server} do
    :ok = DepMonitor.add_node(server, "n", script([{:error, :boom}]), threshold: 1)
    assert {:ok, :down} = DepMonitor.check(server, "n")
    :ok = DepMonitor.add_node(server, "n", script([:ok]))
    assert {:ok, :up} = DepMonitor.direct_status(server, "n")
  end