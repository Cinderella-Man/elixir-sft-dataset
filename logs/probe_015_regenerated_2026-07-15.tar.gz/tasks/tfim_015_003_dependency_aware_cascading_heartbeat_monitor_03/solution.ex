  test "own status goes down after consecutive-failure threshold", %{server: server} do
    :ok = DepMonitor.add_node(server, "n", script([{:error, :boom}]), threshold: 3)
    assert {:ok, :up} = DepMonitor.check(server, "n")
    assert {:ok, :up} = DepMonitor.check(server, "n")
    assert {:ok, :down} = DepMonitor.check(server, "n")
    assert {:ok, :down} = DepMonitor.direct_status(server, "n")
  end