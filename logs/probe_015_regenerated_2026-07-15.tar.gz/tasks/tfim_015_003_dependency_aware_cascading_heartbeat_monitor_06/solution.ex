  test "a dependency going down cascades to dependents' effective status", %{server: server} do
    me = self()
    on_b = fn n, s -> send(me, {:eff, n, s}) end
    on_a = fn n, s -> send(me, {:eff, n, s}) end

    :ok =
      DepMonitor.add_node(server, "B", script([{:error, :boom}]), threshold: 1, on_change: on_b)

    :ok =
      DepMonitor.add_node(server, "A", script([:ok]),
        depends_on: ["B"],
        on_change: on_a
      )

    assert {:ok, :up} = DepMonitor.effective_status(server, "A")

    # Take B down; A's effective status must follow even though A's own probe is fine.
    assert {:ok, :down} = DepMonitor.check(server, "B")
    assert {:ok, :down} = DepMonitor.effective_status(server, "A")
    assert {:ok, :up} = DepMonitor.direct_status(server, "A")

    assert_receive {:eff, "B", :down}
    assert_receive {:eff, "A", :down}
  end