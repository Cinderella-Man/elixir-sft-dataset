  test "services are independent", %{server: server} do
    me = self()
    notify = fn n, s -> send(me, {:transition, n, s}) end

    :ok =
      Monitor.register(server, "a", script([{:error, :boom}]), :infinity,
        threshold: 1,
        notify: notify
      )

    :ok = Monitor.register(server, "b", script([:ok]), :infinity, notify: notify)

    send(server, {:check, "a"})
    assert {:ok, :down} = Monitor.status(server, "a")
    assert_receive {:transition, "a", :down}

    # b is untouched.
    assert {:ok, :up} = Monitor.status(server, "b")
    assert Monitor.statuses(server) == %{"a" => :down, "b" => :up}
    refute_receive {:transition, "b", _}, 50
  end