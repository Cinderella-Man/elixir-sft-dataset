  test "a sweep runs one probe per service and applies results", %{server: server} do
    me = self()
    on_change = fn n, s -> send(me, {:change, n, s}) end

    :ok =
      AsyncMonitor.enroll(server, "svc", script([{:error, :boom}]),
        threshold: 3,
        on_change: on_change
      )

    assert :ok = AsyncMonitor.sweep(server)
    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :up} = AsyncMonitor.status(server, "svc")
    refute_receive {:change, _, _}, 50

    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    assert_receive {:change, "svc", :down}

    assert :ok = AsyncMonitor.sweep(server)
    assert {:ok, :down} = AsyncMonitor.status(server, "svc")
    refute_receive {:change, _, _}, 100
  end