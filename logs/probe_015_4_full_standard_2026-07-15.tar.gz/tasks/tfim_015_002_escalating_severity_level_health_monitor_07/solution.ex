  test "consecutive failures escalate :ok -> :warning -> :critical, firing on_change per step" do
    test = self()
    hook = fn n, o, nw, r -> send(test, {:changed, n, o, nw, r}) end

    :ok =
      HealthMonitor.add_probe("svc", fn -> {:error, :boom} end, 10_000,
        warn_after: 2,
        crit_after: 3,
        on_change: hook
      )

    # First failure keeps it :ok (count 1 < warn_after 2): no callback.
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    refute_receive {:changed, "svc", _, _, _}, 50

    # Second failure reaches warn_after: escalate :ok -> :warning.
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
    assert_receive {:changed, "svc", :ok, :warning, :boom}, 500

    # Third failure reaches crit_after: escalate :warning -> :critical.
    assert {:ok, :critical} = HealthMonitor.probe_now("svc")
    assert_receive {:changed, "svc", :warning, :critical, :boom}, 500

    assert HealthMonitor.level("svc") == :critical
  end