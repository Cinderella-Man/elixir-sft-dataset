  test "status and check_now report unknown services" do
    assert Monitor.status("nope") == {:error, :not_found}
    assert Monitor.check_now("nope") == {:error, :not_found}
  end