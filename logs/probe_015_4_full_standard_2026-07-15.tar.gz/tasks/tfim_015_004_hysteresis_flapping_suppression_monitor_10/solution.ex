  test "alternating results are suppressed and never confirm a transition" do
    test = self()
    hook = fn n, f, t -> send(test, {:trans, n, f, t}) end
    {:ok, box} = Agent.start_link(fn -> {:error, :e} end)
    check = fn -> Agent.get(box, & &1) end

    :ok =
      StabilityMonitor.watch("svc", check, 10_000,
        fail_confirm: 2,
        ok_confirm: 2,
        on_transition: hook
      )

    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    Agent.update(box, fn _ -> {:error, :e} end)
    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :up} = StabilityMonitor.force_check("svc")

    assert StabilityMonitor.state("svc") == :up
    refute_receive {:trans, "svc", _, _}, 50
  end