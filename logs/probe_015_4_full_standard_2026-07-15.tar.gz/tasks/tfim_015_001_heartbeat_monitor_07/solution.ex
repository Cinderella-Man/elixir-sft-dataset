  test "a custom threshold of 1 goes :down on the first failure" do
    :ok = Monitor.register("svc", fn -> {:error, :boom} end, 10_000, threshold: 1)
    assert {:ok, :down} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :down
  end