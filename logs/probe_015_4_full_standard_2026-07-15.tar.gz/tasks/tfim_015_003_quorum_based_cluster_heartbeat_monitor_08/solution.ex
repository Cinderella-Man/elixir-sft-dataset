  test "notify fires exactly once per :up -> :down transition" do
    {:ok, b1} = Agent.start_link(fn -> :ok end)
    {:ok, b2} = Agent.start_link(fn -> :ok end)
    test = self()

    :ok =
      ClusterMonitor.register_cluster("c", [endpoint(b1), endpoint(b2)], 10_000,
        quorum: 2,
        notify: fn n, h -> send(test, {:down, n, h}) end
      )

    assert {:ok, :up} = ClusterMonitor.poll("c")
    refute_receive {:down, _, _}, 50

    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :down} = ClusterMonitor.poll("c")
    assert_receive {:down, "c", 1}, 500

    # Still down -> no re-notify.
    assert {:ok, :down} = ClusterMonitor.poll("c")
    refute_receive {:down, _, _}, 50

    # Recover -> no notify on up.
    Agent.update(b1, fn _ -> :ok end)
    assert {:ok, :up} = ClusterMonitor.poll("c")
    refute_receive {:down, _, _}, 50

    # Fresh down transition notifies again.
    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :down} = ClusterMonitor.poll("c")
    assert_receive {:down, "c", 1}, 500
  end