  test "poll and cluster_state report unknown clusters" do
    assert ClusterMonitor.poll("nope") == {:error, :not_found}
    assert ClusterMonitor.cluster_state("nope") == {:error, :not_found}
  end