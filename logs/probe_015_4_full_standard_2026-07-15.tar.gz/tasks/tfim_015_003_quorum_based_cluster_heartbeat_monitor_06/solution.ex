  test "the default quorum is a strict majority of endpoints" do
    {:ok, b1} = Agent.start_link(fn -> :ok end)
    {:ok, b2} = Agent.start_link(fn -> :ok end)
    {:ok, b3} = Agent.start_link(fn -> :ok end)
    test = self()

    :ok =
      ClusterMonitor.register_cluster("c", [endpoint(b1), endpoint(b2), endpoint(b3)], 10_000,
        notify: fn n, h -> send(test, {:down, n, h}) end
      )

    # 3 of 3 healthy >= majority (2): up.
    assert {:ok, :up} = ClusterMonitor.poll("c")

    # 2 of 3 healthy >= 2: still up.
    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :up} = ClusterMonitor.poll("c")

    # 1 of 3 healthy < 2: down, notify with healthy count 1.
    Agent.update(b2, fn _ -> {:error, :x} end)
    assert {:ok, :down} = ClusterMonitor.poll("c")
    assert_receive {:down, "c", 1}, 500
  end