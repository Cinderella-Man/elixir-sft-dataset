  test "re-watching resets the confirmed state and applies the new config" do
    :ok = StabilityMonitor.watch("svc", fn -> {:error, :x} end, 10_000, fail_confirm: 1)
    assert {:ok, :down} = StabilityMonitor.force_check("svc")
    assert StabilityMonitor.state("svc") == :down

    :ok = StabilityMonitor.watch("svc", fn -> {:error, :y} end, 10_000, fail_confirm: 2)
    assert StabilityMonitor.state("svc") == :up

    # New fail_confirm of 2 governs now: one failure stays :up.
    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    assert {:ok, :down} = StabilityMonitor.force_check("svc")
  end