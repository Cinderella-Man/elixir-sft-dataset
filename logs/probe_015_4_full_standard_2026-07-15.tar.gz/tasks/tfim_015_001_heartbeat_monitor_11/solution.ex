  test "re-registering resets status to :up and applies the new config" do
    test = self()

    # Drive the service :down under the original threshold and notify.
    :ok =
      Monitor.register("svc", fn -> {:error, :old} end, 10_000,
        threshold: 1,
        notify: fn name, reason -> send(test, {:old, name, reason}) end
      )

    assert {:ok, :down} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :down
    assert_receive {:old, "svc", :old}, 500

    # Re-registering replaces config (new check + threshold + notify) and
    # resets the status back to :up with a fresh failure count of 0.
    :ok =
      Monitor.register("svc", fn -> {:error, :new} end, 10_000,
        threshold: 2,
        notify: fn name, reason -> send(test, {:new, name, reason}) end
      )

    assert Monitor.status("svc") == :up

    # The new threshold of 2 governs now: one failure keeps it :up, and the
    # old notify function must never fire again.
    assert {:ok, :up} = Monitor.check_now("svc")
    refute_receive {:old, "svc", _}, 50
    refute_receive {:new, "svc", _}, 50

    # The second consecutive failure trips the NEW notify with the NEW reason.
    assert {:ok, :down} = Monitor.check_now("svc")
    assert_receive {:new, "svc", :new}, 500
    refute_receive {:old, "svc", _}, 50
  end