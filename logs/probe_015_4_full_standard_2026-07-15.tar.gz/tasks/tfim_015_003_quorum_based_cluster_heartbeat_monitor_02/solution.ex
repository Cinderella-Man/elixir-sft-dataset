  test "a freshly started monitor snapshots nothing" do
    assert ClusterMonitor.snapshot() == %{}
  end