# Fill in the middle: implement the blanked test

Below is a module and its ExUnit test harness with the body of ONE `test` removed
(marked `# TODO`). The test's name states what it must verify. Implement just that one
test so the harness passes for a correct implementation of the module.

## Module under test

```elixir
defmodule ClusterMonitor do
  @moduledoc """
  A singleton `GenServer` that supervises registered *clusters* and decides each
  cluster's `:up`/`:down` status by **quorum**.

  A cluster is a group of independent, zero-arity endpoint functions. On every poll
  the monitor calls all endpoints, counts how many report `:ok`, and sets the status
  to `:up` when that count is at least the configured quorum, otherwise `:down`. The
  status is recomputed fresh on every poll — there is no running consecutive-failure
  counter.

  The process is registered under the module name `ClusterMonitor`, so the
  convenience functions (`register_cluster/4`, `poll/1`, `cluster_state/1`,
  `snapshot/0`, `unregister/1`) take no server argument.

  Each registration is tagged with a generation token (a `t:reference/0`). Scheduled
  poll messages carrying a stale token are ignored, so superseded timer chains from
  replaced or removed registrations never run again.
  """

  use GenServer

  @typedoc "A zero-arity endpoint health check."
  @type check_fun :: (-> :ok | {:error, term()})

  @typedoc "The resulting status of a cluster."
  @type status :: :up | :down

  ## Public API

  @doc """
  Starts and links the singleton monitor.

  `opts` is a keyword list. A `:name` option overrides the registered name, but the
  convenience functions always target `ClusterMonitor`. A freshly started server
  tracks zero clusters.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) when is_list(opts) do
    {name, rest} = Keyword.pop(opts, :name, __MODULE__)
    GenServer.start_link(__MODULE__, rest, name: name)
  end

  @doc """
  Registers (or replaces) a cluster named `name`.

  `check_funcs` is a non-empty list of zero-arity functions returning `:ok` or
  `{:error, reason}`. `interval_ms` is a positive integer poll interval. Supported
  `opts`: `:quorum` (positive integer, defaults to a strict majority) and `:notify`
  (a two-arity function invoked on an `:up` -> `:down` transition, defaults to a
  no-op).

  Registration does not poll; the first poll runs one `interval_ms` later. The status
  starts as `:up` with `healthy` equal to `total`. Re-registering replaces the
  configuration and resets the status. Always returns `:ok`.
  """
  @spec register_cluster(term(), [check_fun(), ...], pos_integer(), keyword()) :: :ok
  def register_cluster(name, check_funcs, interval_ms, opts \\ [])
      when is_list(check_funcs) and check_funcs != [] and
             is_integer(interval_ms) and interval_ms > 0 and is_list(opts) do
    :ok = Enum.each(check_funcs, &assert_zero_arity!/1)
    GenServer.call(__MODULE__, {:register, name, check_funcs, interval_ms, opts})
  end

  @doc """
  Performs exactly one poll for `name` immediately, identical to a scheduled tick.

  Returns `{:ok, status}` with the resulting status, or `{:error, :not_found}` if the
  cluster is unknown. Does not alter or reschedule the periodic timer.
  """
  @spec poll(term()) :: {:ok, status()} | {:error, :not_found}
  def poll(name) do
    GenServer.call(__MODULE__, {:poll, name})
  end

  @doc """
  Returns the current state of the registered cluster `name`.

  The map has keys `:status`, `:healthy` and `:total`. Returns `{:error, :not_found}`
  if the cluster is unknown.
  """
  @spec cluster_state(term()) ::
          %{status: status(), healthy: non_neg_integer(), total: pos_integer()}
          | {:error, :not_found}
  def cluster_state(name) do
    GenServer.call(__MODULE__, {:cluster_state, name})
  end

  @doc """
  Returns a map of every registered cluster name to its current status.

  Returns `%{}` when no clusters are registered.
  """
  @spec snapshot() :: %{optional(term()) => status()}
  def snapshot do
    GenServer.call(__MODULE__, :snapshot)
  end

  @doc """
  Removes the cluster `name`.

  Returns `:ok` if the cluster existed, or `{:error, :not_found}` otherwise. After
  removal the cluster's scheduled polls never run again.
  """
  @spec unregister(term()) :: :ok | {:error, :not_found}
  def unregister(name) do
    GenServer.call(__MODULE__, {:unregister, name})
  end

  ## GenServer callbacks

  @impl true
  def init(_opts) do
    {:ok, %{clusters: %{}}}
  end

  @impl true
  def handle_call({:register, name, check_funcs, interval_ms, opts}, _from, state) do
    total = length(check_funcs)
    quorum = Keyword.get(opts, :quorum, div(total, 2) + 1)
    notify = Keyword.get(opts, :notify, fn _name, _healthy -> :ok end)
    gen = make_ref()

    cluster = %{
      check_funcs: check_funcs,
      interval_ms: interval_ms,
      quorum: quorum,
      notify: notify,
      status: :up,
      healthy: total,
      total: total,
      gen: gen
    }

    Process.send_after(self(), {:poll, name, gen}, interval_ms)
    {:reply, :ok, put_in(state.clusters[name], cluster)}
  end

  def handle_call({:poll, name}, _from, state) do
    case Map.fetch(state.clusters, name) do
      {:ok, cluster} ->
        updated = run_poll(cluster, name)
        {:reply, {:ok, updated.status}, put_in(state.clusters[name], updated)}

      :error ->
        {:reply, {:error, :not_found}, state}
    end
  end

  def handle_call({:cluster_state, name}, _from, state) do
    case Map.fetch(state.clusters, name) do
      {:ok, cluster} ->
        view = %{status: cluster.status, healthy: cluster.healthy, total: cluster.total}
        {:reply, view, state}

      :error ->
        {:reply, {:error, :not_found}, state}
    end
  end

  def handle_call(:snapshot, _from, state) do
    view = Map.new(state.clusters, fn {name, cluster} -> {name, cluster.status} end)
    {:reply, view, state}
  end

  def handle_call({:unregister, name}, _from, state) do
    case Map.fetch(state.clusters, name) do
      {:ok, _cluster} ->
        {:reply, :ok, %{state | clusters: Map.delete(state.clusters, name)}}

      :error ->
        {:reply, {:error, :not_found}, state}
    end
  end

  @impl true
  def handle_info({:poll, name, gen}, state) do
    case Map.fetch(state.clusters, name) do
      {:ok, %{gen: ^gen} = cluster} ->
        updated = run_poll(cluster, name)
        Process.send_after(self(), {:poll, name, gen}, cluster.interval_ms)
        {:noreply, put_in(state.clusters[name], updated)}

      _other ->
        {:noreply, state}
    end
  end

  def handle_info(_msg, state) do
    {:noreply, state}
  end

  ## Internal helpers

  @spec run_poll(map(), term()) :: map()
  defp run_poll(cluster, name) do
    healthy = Enum.count(cluster.check_funcs, fn check -> check.() == :ok end)
    new_status = if healthy >= cluster.quorum, do: :up, else: :down

    if cluster.status == :up and new_status == :down do
      cluster.notify.(name, healthy)
    end

    %{cluster | status: new_status, healthy: healthy}
  end

  @spec assert_zero_arity!(check_fun()) :: :ok
  defp assert_zero_arity!(fun) when is_function(fun, 0), do: :ok
end
```

## Test harness — implement the `# TODO` test

```elixir
defmodule ClusterMonitorTest do
  use ExUnit.Case, async: false

  setup do
    start_supervised!({ClusterMonitor, []})
    :ok
  end

  defp flush_probes do
    receive do
      {:probe, _} -> flush_probes()
    after
      0 -> :ok
    end
  end

  defp collect_probes(acc) do
    receive do
      {:probe, x} -> collect_probes([x | acc])
    after
      0 -> Enum.reverse(acc)
    end
  end

  defp endpoint(box), do: fn -> Agent.get(box, & &1) end

  test "a freshly started monitor snapshots nothing" do
    # TODO
  end

  test "register_cluster returns :ok, starts :up, and reports healthy == total" do
    funcs = [fn -> :ok end, fn -> :ok end, fn -> :ok end]
    assert :ok = ClusterMonitor.register_cluster("c", funcs, 10_000)
    assert ClusterMonitor.cluster_state("c") == %{status: :up, healthy: 3, total: 3}
    assert ClusterMonitor.snapshot() == %{"c" => :up}
  end

  test "register_cluster guards its arguments" do
    assert_raise FunctionClauseError, fn ->
      ClusterMonitor.register_cluster("c", [], 10_000)
    end

    assert_raise FunctionClauseError, fn ->
      ClusterMonitor.register_cluster("c", [fn -> :ok end], 0)
    end

    assert_raise FunctionClauseError, fn ->
      ClusterMonitor.register_cluster("c", [fn _x -> :ok end], 10_000)
    end

    assert :ok = ClusterMonitor.register_cluster("ok", [fn -> :ok end], 10_000)
    assert ClusterMonitor.cluster_state("ok").status == :up
  end

  test "poll and cluster_state report unknown clusters" do
    assert ClusterMonitor.poll("nope") == {:error, :not_found}
    assert ClusterMonitor.cluster_state("nope") == {:error, :not_found}
  end

  test "the default quorum is a strict majority of endpoints" do
    {:ok, b1} = Agent.start_link(fn -> :ok end)
    {:ok, b2} = Agent.start_link(fn -> :ok end)
    {:ok, b3} = Agent.start_link(fn -> :ok end)
    test = self()

    :ok =
      ClusterMonitor.register_cluster("c", [endpoint(b1), endpoint(b2), endpoint(b3)], 10_000,
        notify: fn n, h -> send(test, {:down, n, h}) end
      )

    # 3 of 3 healthy >= majority (2): up.
    assert {:ok, :up} = ClusterMonitor.poll("c")

    # 2 of 3 healthy >= 2: still up.
    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :up} = ClusterMonitor.poll("c")

    # 1 of 3 healthy < 2: down, notify with healthy count 1.
    Agent.update(b2, fn _ -> {:error, :x} end)
    assert {:ok, :down} = ClusterMonitor.poll("c")
    assert_receive {:down, "c", 1}, 500
  end

  test "a custom quorum requires that many healthy endpoints" do
    {:ok, b1} = Agent.start_link(fn -> :ok end)
    {:ok, b2} = Agent.start_link(fn -> :ok end)
    {:ok, b3} = Agent.start_link(fn -> :ok end)

    :ok =
      ClusterMonitor.register_cluster("c", [endpoint(b1), endpoint(b2), endpoint(b3)], 10_000,
        quorum: 3
      )

    assert {:ok, :up} = ClusterMonitor.poll("c")
    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :down} = ClusterMonitor.poll("c")
  end

  test "notify fires exactly once per :up -> :down transition" do
    {:ok, b1} = Agent.start_link(fn -> :ok end)
    {:ok, b2} = Agent.start_link(fn -> :ok end)
    test = self()

    :ok =
      ClusterMonitor.register_cluster("c", [endpoint(b1), endpoint(b2)], 10_000,
        quorum: 2,
        notify: fn n, h -> send(test, {:down, n, h}) end
      )

    assert {:ok, :up} = ClusterMonitor.poll("c")
    refute_receive {:down, _, _}, 50

    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :down} = ClusterMonitor.poll("c")
    assert_receive {:down, "c", 1}, 500

    # Still down -> no re-notify.
    assert {:ok, :down} = ClusterMonitor.poll("c")
    refute_receive {:down, _, _}, 50

    # Recover -> no notify on up.
    Agent.update(b1, fn _ -> :ok end)
    assert {:ok, :up} = ClusterMonitor.poll("c")
    refute_receive {:down, _, _}, 50

    # Fresh down transition notifies again.
    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :down} = ClusterMonitor.poll("c")
    assert_receive {:down, "c", 1}, 500
  end

  test "cluster_state reports healthy and total after a poll" do
    {:ok, b1} = Agent.start_link(fn -> :ok end)
    {:ok, b2} = Agent.start_link(fn -> :ok end)
    {:ok, b3} = Agent.start_link(fn -> :ok end)

    :ok =
      ClusterMonitor.register_cluster("c", [endpoint(b1), endpoint(b2), endpoint(b3)], 10_000,
        quorum: 2
      )

    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :up} = ClusterMonitor.poll("c")
    assert ClusterMonitor.cluster_state("c") == %{status: :up, healthy: 2, total: 3}
  end

  test "re-registering a cluster resets status and applies the new config" do
    {:ok, b1} = Agent.start_link(fn -> {:error, :x} end)
    :ok = ClusterMonitor.register_cluster("c", [endpoint(b1)], 10_000, quorum: 1)
    assert {:ok, :down} = ClusterMonitor.poll("c")
    assert ClusterMonitor.cluster_state("c").status == :down

    # Re-register with two healthy endpoints and quorum 2.
    :ok = ClusterMonitor.register_cluster("c", [fn -> :ok end, fn -> :ok end], 10_000, quorum: 2)
    assert ClusterMonitor.cluster_state("c") == %{status: :up, healthy: 2, total: 2}
    assert {:ok, :up} = ClusterMonitor.poll("c")
  end

  test "re-registering a cluster kills the previous schedule" do
    test = self()

    a = fn ->
      send(test, {:probe, :a})
      :ok
    end

    :ok = ClusterMonitor.register_cluster("c", [a], 20)
    assert_receive {:probe, :a}, 1_000
    assert_receive {:probe, :a}, 1_000

    b = fn ->
      send(test, {:probe, :b})
      :ok
    end

    :ok = ClusterMonitor.register_cluster("c", [b], 20)

    flush_probes()
    Process.sleep(200)
    ticks = collect_probes([])

    assert :b in ticks
    refute :a in ticks
  end

  test "unregister removes a cluster and kills its schedule" do
    test = self()

    c = fn ->
      send(test, {:probe, :c})
      :ok
    end

    :ok = ClusterMonitor.register_cluster("c", [c], 20)
    assert_receive {:probe, :c}, 1_000

    assert :ok = ClusterMonitor.unregister("c")
    assert ClusterMonitor.cluster_state("c") == {:error, :not_found}
    assert ClusterMonitor.unregister("c") == {:error, :not_found}

    flush_probes()
    Process.sleep(200)
    assert collect_probes([]) == []
  end

  test "periodic polling runs at the configured interval" do
    test = self()

    :ok =
      ClusterMonitor.register_cluster(
        "c",
        [
          fn ->
            send(test, {:probe, :a})
            :ok
          end
        ],
        20
      )

    assert_receive {:probe, :a}, 1_000
    assert_receive {:probe, :a}, 1_000
  end

  test "clusters are independent" do
    :ok = ClusterMonitor.register_cluster("a", [fn -> {:error, :x} end], 10_000, quorum: 1)
    :ok = ClusterMonitor.register_cluster("b", [fn -> :ok end], 10_000, quorum: 1)

    assert {:ok, :down} = ClusterMonitor.poll("a")
    assert {:ok, :up} = ClusterMonitor.poll("b")
    assert ClusterMonitor.snapshot() == %{"a" => :down, "b" => :up}
  end

  test "unexpected messages do not crash the server" do
    :ok = ClusterMonitor.register_cluster("c", [fn -> :ok end], 10_000)
    send(ClusterMonitor, :garbage)
    send(ClusterMonitor, {:more, :garbage})
    assert ClusterMonitor.cluster_state("c").status == :up
  end

  test "atom and tuple cluster names work and compare by value" do
    :ok = ClusterMonitor.register_cluster(:svc, [fn -> :ok end], 10_000, quorum: 1)
    :ok = ClusterMonitor.register_cluster({:svc, 1}, [fn -> {:error, :x} end], 10_000, quorum: 1)

    assert ClusterMonitor.cluster_state(:svc).status == :up
    assert {:ok, :down} = ClusterMonitor.poll({:svc, 1})
    assert ClusterMonitor.snapshot() == %{:svc => :up, {:svc, 1} => :down}
  end

  test "a scheduled poll fires notify on an up to down transition" do
    test = self()
    down = fn -> {:error, :x} end

    :ok =
      ClusterMonitor.register_cluster("c", [down], 30,
        quorum: 1,
        notify: fn n, h -> send(test, {:down, n, h}) end
      )

    # No poll/1 call: the periodic timer alone must poll, transition up -> down,
    # and fire notify exactly once with this poll's healthy count (0).
    assert_receive {:down, "c", 0}, 1_000
  end

  test "registration defers the first poll until one interval elapses" do
    test = self()

    probe = fn ->
      send(test, {:probe, :first})
      :ok
    end

    :ok = ClusterMonitor.register_cluster("c", [probe], 200)

    # Registration itself must not call any endpoint before the interval passes.
    refute_receive {:probe, :first}, 60
    # The first poll then arrives after one interval.
    assert_receive {:probe, :first}, 1_000
  end
end
```
