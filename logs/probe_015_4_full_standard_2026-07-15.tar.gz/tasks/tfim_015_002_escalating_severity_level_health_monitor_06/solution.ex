  test "level and probe_now report unknown probes" do
    assert HealthMonitor.level("nope") == {:error, :not_found}
    assert HealthMonitor.probe_now("nope") == {:error, :not_found}
  end