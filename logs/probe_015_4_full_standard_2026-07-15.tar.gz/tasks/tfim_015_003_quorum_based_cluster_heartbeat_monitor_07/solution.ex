  test "a custom quorum requires that many healthy endpoints" do
    {:ok, b1} = Agent.start_link(fn -> :ok end)
    {:ok, b2} = Agent.start_link(fn -> :ok end)
    {:ok, b3} = Agent.start_link(fn -> :ok end)

    :ok =
      ClusterMonitor.register_cluster("c", [endpoint(b1), endpoint(b2), endpoint(b3)], 10_000,
        quorum: 3
      )

    assert {:ok, :up} = ClusterMonitor.poll("c")
    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :down} = ClusterMonitor.poll("c")
  end