  test "watch guards a non-zero-arity check function" do
    assert_raise FunctionClauseError, fn ->
      StabilityMonitor.watch("bad", fn _x -> :ok end, 10_000)
    end

    assert :ok = StabilityMonitor.watch("ok", fn -> :ok end, 10_000)
    assert StabilityMonitor.state("ok") == :up
  end