  test "re-registering a cluster resets status and applies the new config" do
    {:ok, b1} = Agent.start_link(fn -> {:error, :x} end)
    :ok = ClusterMonitor.register_cluster("c", [endpoint(b1)], 10_000, quorum: 1)
    assert {:ok, :down} = ClusterMonitor.poll("c")
    assert ClusterMonitor.cluster_state("c").status == :down

    # Re-register with two healthy endpoints and quorum 2.
    :ok = ClusterMonitor.register_cluster("c", [fn -> :ok end, fn -> :ok end], 10_000, quorum: 2)
    assert ClusterMonitor.cluster_state("c") == %{status: :up, healthy: 2, total: 2}
    assert {:ok, :up} = ClusterMonitor.poll("c")
  end