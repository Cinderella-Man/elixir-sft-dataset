  test "a service goes :down only after fail_confirm consecutive failures" do
    test = self()
    hook = fn n, f, t -> send(test, {:trans, n, f, t}) end

    :ok =
      StabilityMonitor.watch("svc", fn -> {:error, :x} end, 10_000,
        fail_confirm: 3,
        ok_confirm: 2,
        on_transition: hook
      )

    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    refute_receive {:trans, "svc", _, _}, 50

    assert {:ok, :down} = StabilityMonitor.force_check("svc")
    assert_receive {:trans, "svc", :up, :down}, 500
    assert StabilityMonitor.state("svc") == :down

    # Already down: further failures do not re-fire.
    assert {:ok, :down} = StabilityMonitor.force_check("svc")
    refute_receive {:trans, "svc", _, _}, 50
  end