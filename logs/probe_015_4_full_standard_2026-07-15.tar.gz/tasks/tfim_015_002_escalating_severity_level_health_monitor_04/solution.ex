  test "add_probe guards a non-positive interval" do
    assert_raise FunctionClauseError, fn ->
      HealthMonitor.add_probe("bad", fn -> :ok end, 0)
    end

    assert :ok = HealthMonitor.add_probe("ok", fn -> :ok end, 10_000)
    assert HealthMonitor.level("ok") == :ok
  end