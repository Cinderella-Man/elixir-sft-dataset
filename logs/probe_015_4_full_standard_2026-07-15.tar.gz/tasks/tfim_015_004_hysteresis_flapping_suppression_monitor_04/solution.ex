  test "watch guards a non-positive interval" do
    assert_raise FunctionClauseError, fn ->
      StabilityMonitor.watch("bad", fn -> :ok end, 0)
    end

    assert :ok = StabilityMonitor.watch("ok", fn -> :ok end, 10_000)
    assert StabilityMonitor.state("ok") == :up
  end