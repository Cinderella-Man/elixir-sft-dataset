  test "register guards a non-positive interval" do
    assert_raise FunctionClauseError, fn ->
      Monitor.register("bad", fn -> :ok end, 0)
    end

    # The server must still be alive and usable afterwards.
    assert :ok = Monitor.register("ok", fn -> :ok end, 10_000)
    assert Monitor.status("ok") == :up
  end