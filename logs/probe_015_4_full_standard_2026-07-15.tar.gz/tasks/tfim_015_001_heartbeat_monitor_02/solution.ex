  test "a freshly started monitor tracks nothing" do
    assert Monitor.statuses() == %{}
  end