  test "register_cluster guards its arguments" do
    assert_raise FunctionClauseError, fn ->
      ClusterMonitor.register_cluster("c", [], 10_000)
    end

    assert_raise FunctionClauseError, fn ->
      ClusterMonitor.register_cluster("c", [fn -> :ok end], 0)
    end

    assert_raise FunctionClauseError, fn ->
      ClusterMonitor.register_cluster("c", [fn _x -> :ok end], 10_000)
    end

    assert :ok = ClusterMonitor.register_cluster("ok", [fn -> :ok end], 10_000)
    assert ClusterMonitor.cluster_state("ok").status == :up
  end