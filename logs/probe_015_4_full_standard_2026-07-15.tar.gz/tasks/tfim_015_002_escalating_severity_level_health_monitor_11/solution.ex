  test "remove_probe deletes a probe and reports not_found for unknown removals" do
    :ok = HealthMonitor.add_probe("svc", fn -> :ok end, 10_000)
    assert HealthMonitor.report() == %{"svc" => :ok}

    assert :ok = HealthMonitor.remove_probe("svc")
    assert HealthMonitor.level("svc") == {:error, :not_found}
    assert HealthMonitor.report() == %{}

    assert HealthMonitor.remove_probe("svc") == {:error, :not_found}
  end