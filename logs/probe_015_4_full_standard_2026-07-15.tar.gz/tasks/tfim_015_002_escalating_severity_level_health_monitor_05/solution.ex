  test "add_probe guards a non-zero-arity check function" do
    assert_raise FunctionClauseError, fn ->
      HealthMonitor.add_probe("bad", fn _x -> :ok end, 10_000)
    end

    assert :ok = HealthMonitor.add_probe("ok", fn -> :ok end, 10_000)
    assert HealthMonitor.level("ok") == :ok
  end