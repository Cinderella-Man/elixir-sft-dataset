# Write tests for this module

Below is a completed Elixir module and the original specification it was built to
satisfy. Write a comprehensive ExUnit test harness that verifies a correct
implementation of this module.

Requirements for the harness:
- Define a module `<Module>Test` that does `use ExUnit.Case, async: false`.
- Do NOT call `ExUnit.start()` — the evaluator starts ExUnit itself.
- Make it self-contained: any fakes, clock Agents, or helpers are defined inline.
- Cover the full public API and the important edge cases described in the spec.
- It must compile with ZERO warnings (prefix unused variables with `_`; match float
  zero as `+0.0`/`-0.0`).
- Give me the complete harness in a single file.

## Original specification

# Quorum-Based Cluster Heartbeat Monitor

Write me an Elixir module called `ClusterMonitor` — a `GenServer` that supervises a
set of registered **clusters**, where each cluster is a group of independent
endpoints, and decides the cluster's `:up`/`:down` status by **quorum**: the cluster
is `:up` when at least a configured number of its endpoints report healthy on a
single poll. Use only the OTP standard library, no external dependencies, and give me
the complete module in a single file.

Unlike a consecutive-failure monitor, the status here is recomputed **fresh** on
every poll from the current health of all endpoints — there is no running
consecutive-failure counter.

## The singleton and its lifecycle

`ClusterMonitor` is a singleton process. The convenience functions below
(`register_cluster`, `poll`, `cluster_state`, `snapshot`, `unregister`) take **no
server argument** — they operate on the process registered under the module name
`ClusterMonitor`.

- `ClusterMonitor.start_link(opts \\ [])` starts and links the process and returns
  the usual `GenServer.on_start()` result. `opts` is a keyword list defaulting to
  `[]`. The process must be registered under the name `ClusterMonitor` (i.e.
  `__MODULE__`) so the no-argument convenience API can find it. A `:name` option may
  override the registered name, but the convenience functions always target
  `ClusterMonitor`.
- Starting the server does no monitoring work; a freshly started server tracks zero
  clusters, and `ClusterMonitor.snapshot()` returns `%{}`.

## Registering clusters

`ClusterMonitor.register_cluster(name, check_funcs, interval_ms, opts \\ [])`

- `name` is any term used as the key (strings, atoms, tuples all work and are
  compared by value).
- `check_funcs` is a **non-empty list** of **zero-arity** endpoint functions, each
  returning either `:ok` (that endpoint is healthy) or `{:error, reason}` (that
  endpoint is unhealthy). The number of functions is the cluster's `total`.
- `interval_ms` is a **positive integer**: how often, in milliseconds, the monitor
  polls the whole cluster after registration.
- `opts` is a keyword list:
  - `:quorum` — a **positive integer** `Q`: the cluster is `:up` when at least `Q`
    endpoints are healthy on a poll. Defaults to a strict majority,
    `div(total, 2) + 1`.
  - `:notify` — a **two-arity** function `notify.(name, healthy_count)` invoked when
    the cluster transitions from `:up` to `:down` (see below). Defaults to a no-op.

`register_cluster/4` returns `:ok`.

Guards: `check_funcs` must be a non-empty list, `interval_ms` must be a positive
integer, and every element of `check_funcs` must be a zero-arity function. Violating
any of these is outside the contract and raises `FunctionClauseError`; guard the
public function accordingly.

On registration:

- The cluster's status starts as `:up`, and until the first poll runs,
  `cluster_state/1` reports `healthy` equal to `total`.
- Registration itself does **not** poll. The first poll happens one `interval_ms`
  later, then repeats every `interval_ms` thereafter (implemented with
  `Process.send_after/3`, re-scheduling itself after each poll).

Re-registering an already-registered `name` **replaces** its configuration (endpoint
functions, interval, quorum, notify) and **resets** its status to `:up` with
`healthy` equal to the new `total`.

### Lifecycle rule for re-registration (important)

When a cluster is re-registered, the **previous registration's scheduled polls must
never run again**. After a re-registration:

- The old endpoint functions are never called again by any leftover/previously-
  scheduled timer.
- Polls for that cluster happen only at the **new** interval, calling the **new**
  endpoint functions.

Superseded timer chains are dead. (A robust way to achieve this is to tag each
registration with a generation token and ignore scheduled poll messages whose token
no longer matches the current registration.)

## Performing a poll

Each poll — whether triggered by the periodic timer or by `poll/1` below — does
exactly the following:

- Calls **every** endpoint function once.
- Computes `healthy` = the number of endpoints that returned `:ok`.
- Sets the new status to `:up` if `healthy` is greater than or equal to `quorum`,
  otherwise `:down`.
- If the status transitions from `:up` to `:down` on this poll, the notify function
  is called **exactly once** as `notify.(name, healthy)`, with the `healthy` count
  from this poll.
- A transition from `:down` to `:up` (recovery) does **not** call the notify
  function. A poll that finds the cluster already `:down` and still `:down` does
  **not** call notify again.

The recorded `healthy` and `total` are updated to reflect this poll.

## Deterministic single poll

`ClusterMonitor.poll(name)` synchronously performs **one** poll for the named cluster
immediately — identical work to a scheduled interval tick (calling every endpoint,
recomputing `healthy`/status, and firing notify on an `:up` -> `:down` transition).
It returns `{:ok, status}` where `status` is the resulting status (`:up` or
`:down`), or `{:error, :not_found}` if no such cluster is registered. `poll/1` does
not alter or reschedule the periodic timer.

## Querying and removing

- `ClusterMonitor.cluster_state(name)` returns a map
  `%{status: :up | :down, healthy: non_neg_integer(), total: pos_integer()}` for a
  registered cluster, or `{:error, :not_found}` if the cluster is unknown.
- `ClusterMonitor.snapshot()` returns a map `%{name => status}` containing every
  currently registered cluster and its `:up`/`:down` status. With no clusters
  registered it returns `%{}`.
- `ClusterMonitor.unregister(name)` removes a cluster. It returns `:ok` if the
  cluster existed (after removal it no longer appears in `snapshot/0` and
  `cluster_state/1` returns `{:error, :not_found}`), or `{:error, :not_found}` if no
  such cluster was registered. After removal the cluster's scheduled polls must never
  run again — its timer chain is dead.

## Robustness

Any unexpected message sent to the server (anything other than the messages it uses
for its own scheduling) must be ignored: it must not crash the process or alter
state.

Clusters are fully independent: polling one cluster never affects another cluster's
status, `healthy`, or `total`.

## Module under test

```elixir
defmodule ClusterMonitor do
  @moduledoc """
  A singleton `GenServer` that supervises registered *clusters* and decides each
  cluster's `:up`/`:down` status by **quorum**.

  A cluster is a group of independent, zero-arity endpoint functions. On every poll
  the monitor calls all endpoints, counts how many report `:ok`, and sets the status
  to `:up` when that count is at least the configured quorum, otherwise `:down`. The
  status is recomputed fresh on every poll — there is no running consecutive-failure
  counter.

  The process is registered under the module name `ClusterMonitor`, so the
  convenience functions (`register_cluster/4`, `poll/1`, `cluster_state/1`,
  `snapshot/0`, `unregister/1`) take no server argument.

  Each registration is tagged with a generation token (a `t:reference/0`). Scheduled
  poll messages carrying a stale token are ignored, so superseded timer chains from
  replaced or removed registrations never run again.
  """

  use GenServer

  @typedoc "A zero-arity endpoint health check."
  @type check_fun :: (-> :ok | {:error, term()})

  @typedoc "The resulting status of a cluster."
  @type status :: :up | :down

  ## Public API

  @doc """
  Starts and links the singleton monitor.

  `opts` is a keyword list. A `:name` option overrides the registered name, but the
  convenience functions always target `ClusterMonitor`. A freshly started server
  tracks zero clusters.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) when is_list(opts) do
    {name, rest} = Keyword.pop(opts, :name, __MODULE__)
    GenServer.start_link(__MODULE__, rest, name: name)
  end

  @doc """
  Registers (or replaces) a cluster named `name`.

  `check_funcs` is a non-empty list of zero-arity functions returning `:ok` or
  `{:error, reason}`. `interval_ms` is a positive integer poll interval. Supported
  `opts`: `:quorum` (positive integer, defaults to a strict majority) and `:notify`
  (a two-arity function invoked on an `:up` -> `:down` transition, defaults to a
  no-op).

  Registration does not poll; the first poll runs one `interval_ms` later. The status
  starts as `:up` with `healthy` equal to `total`. Re-registering replaces the
  configuration and resets the status. Always returns `:ok`.
  """
  @spec register_cluster(term(), [check_fun(), ...], pos_integer(), keyword()) :: :ok
  def register_cluster(name, check_funcs, interval_ms, opts \\ [])
      when is_list(check_funcs) and check_funcs != [] and
             is_integer(interval_ms) and interval_ms > 0 and is_list(opts) do
    :ok = Enum.each(check_funcs, &assert_zero_arity!/1)
    GenServer.call(__MODULE__, {:register, name, check_funcs, interval_ms, opts})
  end

  @doc """
  Performs exactly one poll for `name` immediately, identical to a scheduled tick.

  Returns `{:ok, status}` with the resulting status, or `{:error, :not_found}` if the
  cluster is unknown. Does not alter or reschedule the periodic timer.
  """
  @spec poll(term()) :: {:ok, status()} | {:error, :not_found}
  def poll(name) do
    GenServer.call(__MODULE__, {:poll, name})
  end

  @doc """
  Returns the current state of the registered cluster `name`.

  The map has keys `:status`, `:healthy` and `:total`. Returns `{:error, :not_found}`
  if the cluster is unknown.
  """
  @spec cluster_state(term()) ::
          %{status: status(), healthy: non_neg_integer(), total: pos_integer()}
          | {:error, :not_found}
  def cluster_state(name) do
    GenServer.call(__MODULE__, {:cluster_state, name})
  end

  @doc """
  Returns a map of every registered cluster name to its current status.

  Returns `%{}` when no clusters are registered.
  """
  @spec snapshot() :: %{optional(term()) => status()}
  def snapshot do
    GenServer.call(__MODULE__, :snapshot)
  end

  @doc """
  Removes the cluster `name`.

  Returns `:ok` if the cluster existed, or `{:error, :not_found}` otherwise. After
  removal the cluster's scheduled polls never run again.
  """
  @spec unregister(term()) :: :ok | {:error, :not_found}
  def unregister(name) do
    GenServer.call(__MODULE__, {:unregister, name})
  end

  ## GenServer callbacks

  @impl true
  def init(_opts) do
    {:ok, %{clusters: %{}}}
  end

  @impl true
  def handle_call({:register, name, check_funcs, interval_ms, opts}, _from, state) do
    total = length(check_funcs)
    quorum = Keyword.get(opts, :quorum, div(total, 2) + 1)
    notify = Keyword.get(opts, :notify, fn _name, _healthy -> :ok end)
    gen = make_ref()

    cluster = %{
      check_funcs: check_funcs,
      interval_ms: interval_ms,
      quorum: quorum,
      notify: notify,
      status: :up,
      healthy: total,
      total: total,
      gen: gen
    }

    Process.send_after(self(), {:poll, name, gen}, interval_ms)
    {:reply, :ok, put_in(state.clusters[name], cluster)}
  end

  def handle_call({:poll, name}, _from, state) do
    case Map.fetch(state.clusters, name) do
      {:ok, cluster} ->
        updated = run_poll(cluster, name)
        {:reply, {:ok, updated.status}, put_in(state.clusters[name], updated)}

      :error ->
        {:reply, {:error, :not_found}, state}
    end
  end

  def handle_call({:cluster_state, name}, _from, state) do
    case Map.fetch(state.clusters, name) do
      {:ok, cluster} ->
        view = %{status: cluster.status, healthy: cluster.healthy, total: cluster.total}
        {:reply, view, state}

      :error ->
        {:reply, {:error, :not_found}, state}
    end
  end

  def handle_call(:snapshot, _from, state) do
    view = Map.new(state.clusters, fn {name, cluster} -> {name, cluster.status} end)
    {:reply, view, state}
  end

  def handle_call({:unregister, name}, _from, state) do
    case Map.fetch(state.clusters, name) do
      {:ok, _cluster} ->
        {:reply, :ok, %{state | clusters: Map.delete(state.clusters, name)}}

      :error ->
        {:reply, {:error, :not_found}, state}
    end
  end

  @impl true
  def handle_info({:poll, name, gen}, state) do
    case Map.fetch(state.clusters, name) do
      {:ok, %{gen: ^gen} = cluster} ->
        updated = run_poll(cluster, name)
        Process.send_after(self(), {:poll, name, gen}, cluster.interval_ms)
        {:noreply, put_in(state.clusters[name], updated)}

      _other ->
        {:noreply, state}
    end
  end

  def handle_info(_msg, state) do
    {:noreply, state}
  end

  ## Internal helpers

  @spec run_poll(map(), term()) :: map()
  defp run_poll(cluster, name) do
    healthy = Enum.count(cluster.check_funcs, fn check -> check.() == :ok end)
    new_status = if healthy >= cluster.quorum, do: :up, else: :down

    if cluster.status == :up and new_status == :down do
      cluster.notify.(name, healthy)
    end

    %{cluster | status: new_status, healthy: healthy}
  end

  @spec assert_zero_arity!(check_fun()) :: :ok
  defp assert_zero_arity!(fun) when is_function(fun, 0), do: :ok
end
```
