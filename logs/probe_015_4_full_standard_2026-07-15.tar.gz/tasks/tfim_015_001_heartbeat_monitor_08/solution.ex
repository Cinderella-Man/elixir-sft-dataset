  test "an :ok result resets the consecutive-failure counter" do
    {:ok, box} = Agent.start_link(fn -> {:error, :e} end)
    check = fn -> Agent.get(box, & &1) end

    :ok = Monitor.register("svc", check, 10_000, threshold: 3)

    # Two failures, then a success resets the counter.
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :up} = Monitor.check_now("svc")

    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :up} = Monitor.check_now("svc")

    # Now it takes three fresh failures to go down, not one.
    Agent.update(box, fn _ -> {:error, :e} end)
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :down} = Monitor.check_now("svc")
  end