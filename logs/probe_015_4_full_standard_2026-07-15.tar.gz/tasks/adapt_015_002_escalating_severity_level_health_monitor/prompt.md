# Adapt existing code to a new specification

Below is a complete, working, tested Elixir solution to a related task. Do not
start from scratch: treat it as the codebase you have been asked to change.
Modify it to satisfy the new specification that follows — keep whatever carries
over, and change, add, or remove whatever the new specification requires.

Where the existing code and the new specification disagree (module name, public
API, behavior, constraints, output format), the new specification wins. Give me
the complete final result.

## Existing code (your starting point)

```elixir
defmodule Monitor do
  @moduledoc """
  A singleton `GenServer` that supervises registered services by periodically
  calling a zero-arity check function for each one, tracking each service's
  `:up`/`:down` status, and firing a notification when a service transitions
  from `:up` to `:down`.

  The server is registered under the name `Monitor` (`__MODULE__`) so that the
  no-argument convenience API (`register/4`, `status/1`, `statuses/0`,
  `check_now/1`) can locate it without an explicit server reference.

  Each registration is tagged with a generation token (a `make_ref/0` value).
  Scheduled check messages whose token no longer matches the current
  registration are ignored, guaranteeing that a re-registration's superseded
  timer chain is dead and can never call the old check function again.
  """

  use GenServer

  @typedoc "The status of a monitored service."
  @type status :: :up | :down

  @typedoc "A zero-arity check function returning health of a service."
  @type check_func :: (-> :ok | {:error, term()})

  @typedoc "A two-arity notification function invoked on a down transition."
  @type notify_func :: (term(), term() -> any())

  # Internal per-service record kept in the server state map.
  @typep service :: %{
           check_func: check_func(),
           interval_ms: pos_integer(),
           threshold: pos_integer(),
           notify: notify_func(),
           status: status(),
           failures: non_neg_integer(),
           generation: reference()
         }

  # --- Public API --------------------------------------------------------

  @doc """
  Starts and links the `Monitor` singleton.

  `opts` is a keyword list (default `[]`). A `:name` option may override the
  registered name, but the convenience functions always target `Monitor`.
  A freshly started server tracks zero services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    {name, opts} = Keyword.pop(opts, :name, __MODULE__)
    GenServer.start_link(__MODULE__, opts, name: name)
  end

  @doc """
  Registers (or re-registers) `service_name` with the given zero-arity
  `check_func`, positive `interval_ms`, and options.

  Options:

    * `:threshold` — positive integer `N`; the service is marked `:down` after
      `N` consecutive failed checks (default `3`).
    * `:notify` — a two-arity function `notify.(service_name, reason)` invoked
      once on each `:up` -> `:down` transition (default no-op).

  Registration resets the status to `:up` with a failure count of `0` and does
  not itself run `check_func`; the first check happens one `interval_ms` later.
  Re-registering replaces the configuration and resets status. Always returns
  `:ok`.
  """
  @spec register(term(), check_func(), pos_integer(), keyword()) :: :ok
  def register(service_name, check_func, interval_ms, opts \\ [])
      when is_function(check_func, 0) and is_integer(interval_ms) and interval_ms > 0 do
    GenServer.call(__MODULE__, {:register, service_name, check_func, interval_ms, opts})
  end

  @doc """
  Returns `:up` or `:down` for a registered service, or `{:error, :not_found}`
  if the service is unknown.
  """
  @spec status(term()) :: status() | {:error, :not_found}
  def status(service_name) do
    GenServer.call(__MODULE__, {:status, service_name})
  end

  @doc """
  Returns a map `%{service_name => status}` for every currently registered
  service. Returns `%{}` when no services are registered.
  """
  @spec statuses() :: %{optional(term()) => status()}
  def statuses do
    GenServer.call(__MODULE__, :statuses)
  end

  @doc """
  Synchronously performs exactly one check for `service_name` immediately,
  doing identical work to a scheduled interval tick (calling the check
  function, updating the failure count and status, and firing the notify
  function on an `:up` -> `:down` transition).

  Returns `{:ok, status}` with the resulting status, or `{:error, :not_found}`
  if the service is unknown. Does not alter or reschedule the periodic timer.
  """
  @spec check_now(term()) :: {:ok, status()} | {:error, :not_found}
  def check_now(service_name) do
    GenServer.call(__MODULE__, {:check_now, service_name})
  end

  # --- GenServer callbacks ----------------------------------------------

  @impl true
  @spec init(keyword()) :: {:ok, %{optional(term()) => service()}}
  def init(_opts) do
    {:ok, %{}}
  end

  @impl true
  def handle_call({:register, name, func, interval, opts}, _from, state) do
    generation = make_ref()
    threshold = Keyword.get(opts, :threshold, 3)
    notify = Keyword.get(opts, :notify, fn _name, _reason -> :ok end)

    service = %{
      check_func: func,
      interval_ms: interval,
      threshold: threshold,
      notify: notify,
      status: :up,
      failures: 0,
      generation: generation
    }

    schedule(name, generation, interval)
    {:reply, :ok, Map.put(state, name, service)}
  end

  def handle_call({:status, name}, _from, state) do
    case Map.get(state, name) do
      nil -> {:reply, {:error, :not_found}, state}
      service -> {:reply, service.status, state}
    end
  end

  def handle_call(:statuses, _from, state) do
    result = Map.new(state, fn {name, service} -> {name, service.status} end)
    {:reply, result, state}
  end

  def handle_call({:check_now, name}, _from, state) do
    case Map.get(state, name) do
      nil ->
        {:reply, {:error, :not_found}, state}

      service ->
        {updated, status} = run_check(service, name)
        {:reply, {:ok, status}, Map.put(state, name, updated)}
    end
  end

  def handle_call(_request, _from, state) do
    {:reply, {:error, :unknown_request}, state}
  end

  @impl true
  def handle_info({:check, name, generation}, state) do
    case Map.get(state, name) do
      %{generation: ^generation} = service ->
        {updated, _status} = run_check(service, name)
        schedule(name, generation, updated.interval_ms)
        {:noreply, Map.put(state, name, updated)}

      _other ->
        # Unknown service or a superseded generation token: ignore.
        {:noreply, state}
    end
  end

  def handle_info(_msg, state) do
    {:noreply, state}
  end

  # --- Internal helpers --------------------------------------------------

  # Schedules the next check tick for `name` under the given generation token.
  @spec schedule(term(), reference(), pos_integer()) :: reference()
  defp schedule(name, generation, interval) do
    Process.send_after(self(), {:check, name, generation}, interval)
  end

  # Runs one check, updating failure count/status and firing notify on an
  # `:up` -> `:down` transition. Returns `{updated_service, resulting_status}`.
  @spec run_check(service(), term()) :: {service(), status()}
  defp run_check(service, name) do
    case service.check_func.() do
      :ok ->
        {%{service | failures: 0, status: :up}, :up}

      {:error, reason} ->
        failures = service.failures + 1

        if service.status == :up and failures >= service.threshold do
          service.notify.(name, reason)
          {%{service | failures: failures, status: :down}, :down}
        else
          {%{service | failures: failures}, service.status}
        end
    end
  end
end
```

## New specification

# Escalating Severity-Level Health Monitor

Write me an Elixir module called `HealthMonitor` — a `GenServer` that supervises a
set of registered *probes* by calling a check function for each one on a periodic
interval, tracking each probe's **severity level**, and firing a callback whenever a
probe's level changes. Use only the OTP standard library, no external dependencies,
and give me the complete module in a single file.

Unlike a plain up/down monitor, each probe has **three** severity levels —
`:ok`, `:warning`, and `:critical` — driven by how many checks have failed in a row.

## The singleton and its lifecycle

`HealthMonitor` is a singleton process. The convenience functions below
(`add_probe`, `level`, `report`, `probe_now`, `remove_probe`) take **no server
argument** — they operate on the process registered under the module name
`HealthMonitor`.

- `HealthMonitor.start_link(opts \\ [])` starts and links the process and returns
  the usual `GenServer.on_start()` result. `opts` is a keyword list defaulting to
  `[]`. The process must be registered under the name `HealthMonitor` (i.e.
  `__MODULE__`) so the no-argument convenience API can find it. A `:name` option may
  override the registered name, but the convenience functions always target
  `HealthMonitor`.
- Starting the server does no monitoring work; a freshly started server tracks zero
  probes, and `HealthMonitor.report()` returns `%{}`.

## Registering probes

`HealthMonitor.add_probe(name, check_func, interval_ms, opts \\ [])`

- `name` is any term used as the key (strings, atoms, tuples all work and are
  compared by value).
- `check_func` is a **zero-arity** function returning either `:ok` (healthy) or
  `{:error, reason}` (unhealthy), where `reason` is any term.
- `interval_ms` is a **positive integer**: how often, in milliseconds, the monitor
  calls `check_func` after registration.
- `opts` is a keyword list:
  - `:warn_after` — a **positive integer** `W`; defaults to `2`.
  - `:crit_after` — a **positive integer** `C`; defaults to `4`.
  - `:on_change` — a **four-arity** function
    `on_change.(name, old_level, new_level, reason)` invoked whenever the probe's
    level changes (see below). Defaults to a no-op.

`add_probe/4` returns `:ok`.

Guards: `check_func` must be a zero-arity function and `interval_ms` must be a
positive integer. Calling `add_probe` with a non-positive or non-integer
`interval_ms`, or a check function of the wrong arity, is outside the contract and
raises `FunctionClauseError`; guard the public function accordingly.

On registration:

- The probe's level starts as `:ok` with a consecutive-failure count of `0`.
- Registration itself does **not** run the check function. The first check happens
  one `interval_ms` later, then repeats every `interval_ms` thereafter (implemented
  with `Process.send_after/3`, re-scheduling itself after each check).

Re-adding an already-registered `name` **replaces** its configuration (check
function, interval, thresholds, on_change) and **resets** its level to `:ok` with a
failure count of `0`.

### Lifecycle rule for re-adding (important)

When a probe is re-added, the **previous registration's scheduled checks must never
run again**. After a re-add:

- The old check function is never called again by any leftover/previously-scheduled
  timer.
- Checks for that probe happen only at the **new** interval, calling the **new**
  check function.

Superseded timer chains are dead. (A robust way to achieve this is to tag each
registration with a generation token and ignore scheduled check messages whose token
no longer matches the current registration.)

## Performing a check

Each check — whether triggered by the periodic timer or by `probe_now/1` below —
calls `check_func.()` exactly once and then updates the probe:

- If the result is `:ok`: the consecutive-failure count is reset to `0` and the new
  level is `:ok`.
- If the result is `{:error, reason}`: the consecutive-failure count is incremented
  by one. The new level is then determined **solely** by the resulting count:
  - `:critical` if the count is greater than or equal to `crit_after`;
  - otherwise `:warning` if the count is greater than or equal to `warn_after`;
  - otherwise `:ok`.

After computing the new level, if (and only if) it **differs** from the probe's
previous level, the `on_change` callback is invoked **exactly once** as
`on_change.(name, old_level, new_level, reason)`, where:

- on an escalation caused by a failing check, `reason` is the reason returned by
  **that** failing check;
- on a recovery to `:ok` caused by a successful check, `reason` is `nil`.

If the new level equals the previous level, `on_change` is **not** called.

"Consecutive" means any `:ok` result resets the counter to zero, so a probe that
recovers and later fails again escalates again from scratch.

## Deterministic single check

`HealthMonitor.probe_now(name)` synchronously performs **one** check for the named
probe immediately — identical work to a scheduled interval tick (calling the check
function, updating the failure count and level, and firing `on_change` on a level
change). It returns `{:ok, level}` where `level` is the resulting level (`:ok`,
`:warning`, or `:critical`), or `{:error, :not_found}` if no such probe is
registered. `probe_now/1` does not alter or reschedule the periodic timer.

## Querying and removing

- `HealthMonitor.level(name)` returns `:ok`, `:warning`, or `:critical` for a
  registered probe, or `{:error, :not_found}` if the probe is unknown.
- `HealthMonitor.report()` returns a map `%{name => level}` containing every
  currently registered probe and its level. With no probes registered it returns
  `%{}`.
- `HealthMonitor.remove_probe(name)` removes a probe. It returns `:ok` if the probe
  existed (after removal it no longer appears in `report/0` and `level/1` returns
  `{:error, :not_found}`), or `{:error, :not_found}` if no such probe was registered.
  After removal the probe's scheduled checks must never run again — its timer chain
  is dead.

## Robustness

Any unexpected message sent to the server (anything other than the messages it uses
for its own scheduling) must be ignored: it must not crash the process or alter
state.

Probes are fully independent: escalating one probe never affects another probe's
level or failure count.
