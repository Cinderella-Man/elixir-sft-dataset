  test "recovery then re-failure notifies again (once per distinct transition)" do
    test = self()
    {:ok, box} = Agent.start_link(fn -> {:error, :down1} end)
    check = fn -> Agent.get(box, & &1) end

    :ok =
      Monitor.register("svc", check, 10_000,
        threshold: 2,
        notify: fn name, reason -> send(test, {:notified, name, reason}) end
      )

    # First down transition.
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :down} = Monitor.check_now("svc")
    assert_receive {:notified, "svc", :down1}, 500

    # Recover to :up (no notification on recovery).
    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :up} = Monitor.check_now("svc")
    refute_receive {:notified, "svc", _}, 50

    # Fail again -> a fresh down transition fires the notification again.
    Agent.update(box, fn _ -> {:error, :down2} end)
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :down} = Monitor.check_now("svc")
    assert_receive {:notified, "svc", :down2}, 500
  end