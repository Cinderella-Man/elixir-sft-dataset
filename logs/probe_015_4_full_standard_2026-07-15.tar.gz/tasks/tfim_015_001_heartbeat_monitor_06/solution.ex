  test "default threshold of 3 consecutive failures marks the service :down" do
    # Long interval so the periodic timer never fires during the test.
    :ok = Monitor.register("svc", fn -> {:error, :x} end, 10_000)

    assert {:ok, :up} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :up

    assert {:ok, :up} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :up

    assert {:ok, :down} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :down
  end