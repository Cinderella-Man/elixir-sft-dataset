  test "add_probe returns :ok and the probe starts at :ok" do
    assert :ok = HealthMonitor.add_probe("svc", fn -> :ok end, 10_000)
    assert HealthMonitor.level("svc") == :ok
    assert HealthMonitor.report() == %{"svc" => :ok}
  end