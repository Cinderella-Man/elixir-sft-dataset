  test "state and force_check report unknown services" do
    assert StabilityMonitor.state("nope") == {:error, :not_found}
    assert StabilityMonitor.force_check("nope") == {:error, :not_found}
  end