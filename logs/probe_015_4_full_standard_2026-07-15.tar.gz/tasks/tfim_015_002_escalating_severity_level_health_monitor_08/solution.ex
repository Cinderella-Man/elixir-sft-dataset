  test "default thresholds are warn_after 2 and crit_after 4" do
    :ok = HealthMonitor.add_probe("svc", fn -> {:error, :e} end, 10_000)
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
    assert {:ok, :critical} = HealthMonitor.probe_now("svc")
  end