  test "a freshly started monitor reports nothing" do
    assert HealthMonitor.report() == %{}
  end