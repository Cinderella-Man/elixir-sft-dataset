  test "recovery requires ok_confirm consecutive successes" do
    test = self()
    hook = fn n, f, t -> send(test, {:trans, n, f, t}) end
    {:ok, box} = Agent.start_link(fn -> {:error, :e} end)
    check = fn -> Agent.get(box, & &1) end

    :ok =
      StabilityMonitor.watch("svc", check, 10_000,
        fail_confirm: 1,
        ok_confirm: 2,
        on_transition: hook
      )

    assert {:ok, :down} = StabilityMonitor.force_check("svc")
    assert_receive {:trans, "svc", :up, :down}, 500

    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :down} = StabilityMonitor.force_check("svc")
    refute_receive {:trans, "svc", _, _}, 50

    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    assert_receive {:trans, "svc", :down, :up}, 500
  end