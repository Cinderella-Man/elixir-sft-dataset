  test "a success recovers to :ok and fires on_change with a nil reason" do
    test = self()
    hook = fn n, o, nw, r -> send(test, {:changed, n, o, nw, r}) end
    {:ok, box} = Agent.start_link(fn -> {:error, :e} end)
    check = fn -> Agent.get(box, & &1) end

    :ok =
      HealthMonitor.add_probe("svc", check, 10_000,
        warn_after: 1,
        crit_after: 1,
        on_change: hook
      )

    assert {:ok, :critical} = HealthMonitor.probe_now("svc")
    assert_receive {:changed, "svc", :ok, :critical, :e}, 500

    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert_receive {:changed, "svc", :critical, :ok, nil}, 500

    # A success while already :ok changes nothing and fires no callback.
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    refute_receive {:changed, "svc", _, _, _}, 50
  end