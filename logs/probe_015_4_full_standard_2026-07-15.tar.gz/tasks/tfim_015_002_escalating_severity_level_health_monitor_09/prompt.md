# Fill in the middle: implement the blanked test

Below is a module and its ExUnit test harness with the body of ONE `test` removed
(marked `# TODO`). The test's name states what it must verify. Implement just that one
test so the harness passes for a correct implementation of the module.

## Module under test

```elixir
defmodule HealthMonitor do
  @moduledoc """
  A singleton `GenServer` that supervises a set of registered *probes*.

  Each probe has a zero-arity check function that is invoked on a periodic
  interval. Rather than a simple up/down status, every probe tracks one of
  three **severity levels** — `:ok`, `:warning`, or `:critical` — driven by
  how many checks have failed in a row:

    * a successful check (`:ok`) resets the consecutive-failure count to `0`
      and the level to `:ok`;
    * a failing check (`{:error, reason}`) increments the count, and the new
      level becomes `:critical` when the count is `>= :crit_after`, otherwise
      `:warning` when the count is `>= :warn_after`, otherwise `:ok`.

  Whenever a probe's level changes, an optional four-arity `on_change`
  callback is invoked exactly once with `(name, old_level, new_level, reason)`.

  The process is registered under the module name `HealthMonitor`, so the
  convenience functions take no server argument. Only the OTP standard
  library is used.
  """

  use GenServer

  @typedoc "A probe severity level."
  @type level :: :ok | :warning | :critical

  @typedoc "The result returned by a probe's check function."
  @type check_result :: :ok | {:error, term()}

  # ── Public API ────────────────────────────────────────────────────────────

  @doc """
  Starts and links the monitor process.

  The process is registered under `HealthMonitor` unless a `:name` option is
  given. A freshly started server tracks zero probes.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    name = Keyword.get(opts, :name, __MODULE__)
    GenServer.start_link(__MODULE__, opts, name: name)
  end

  @doc """
  Registers (or re-registers) a probe under `name`.

  `check_func` must be a zero-arity function returning `:ok` or
  `{:error, reason}`. `interval_ms` is a positive integer giving how often the
  check runs after registration (the first check happens one interval later).

  Options:

    * `:warn_after` — positive integer, defaults to `2`;
    * `:crit_after` — positive integer, defaults to `4`;
    * `:on_change` — four-arity callback, defaults to a no-op.

  Re-adding an existing `name` replaces its configuration and resets its level
  to `:ok` with a failure count of `0`; previously scheduled checks for that
  name never run again.
  """
  @spec add_probe(term(), (-> check_result()), pos_integer(), keyword()) :: :ok
  def add_probe(name, check_func, interval_ms, opts \\ [])
      when is_function(check_func, 0) and is_integer(interval_ms) and interval_ms > 0 do
    GenServer.call(__MODULE__, {:add_probe, name, check_func, interval_ms, opts})
  end

  @doc """
  Returns the current severity level for `name`, or `{:error, :not_found}`.
  """
  @spec level(term()) :: level() | {:error, :not_found}
  def level(name) do
    GenServer.call(__MODULE__, {:level, name})
  end

  @doc """
  Returns a map of `%{name => level}` for every registered probe.
  """
  @spec report() :: %{optional(term()) => level()}
  def report do
    GenServer.call(__MODULE__, :report)
  end

  @doc """
  Synchronously performs exactly one check for `name`, immediately.

  Performs the identical work of a scheduled tick (running the check function,
  updating the failure count and level, and firing `on_change` on a level
  change) without altering or rescheduling the periodic timer.

  Returns `{:ok, level}` or `{:error, :not_found}`.
  """
  @spec probe_now(term()) :: {:ok, level()} | {:error, :not_found}
  def probe_now(name) do
    GenServer.call(__MODULE__, {:probe_now, name})
  end

  @doc """
  Removes the probe registered under `name`.

  Returns `:ok` if the probe existed (its scheduled checks never run again), or
  `{:error, :not_found}` if no such probe was registered.
  """
  @spec remove_probe(term()) :: :ok | {:error, :not_found}
  def remove_probe(name) do
    GenServer.call(__MODULE__, {:remove_probe, name})
  end

  # ── GenServer callbacks ───────────────────────────────────────────────────

  @impl true
  @spec init(keyword()) :: {:ok, map()}
  def init(_opts) do
    {:ok, %{}}
  end

  @impl true
  def handle_call({:add_probe, name, check_func, interval_ms, opts}, _from, state) do
    warn_after = Keyword.get(opts, :warn_after, 2)
    crit_after = Keyword.get(opts, :crit_after, 4)
    on_change = Keyword.get(opts, :on_change, fn _name, _old, _new, _reason -> :ok end)
    token = make_ref()

    probe = %{
      check_func: check_func,
      interval_ms: interval_ms,
      warn_after: warn_after,
      crit_after: crit_after,
      on_change: on_change,
      level: :ok,
      fail_count: 0,
      token: token
    }

    Process.send_after(self(), {:check, name, token}, interval_ms)
    {:reply, :ok, Map.put(state, name, probe)}
  end

  def handle_call({:level, name}, _from, state) do
    case Map.fetch(state, name) do
      {:ok, probe} -> {:reply, probe.level, state}
      :error -> {:reply, {:error, :not_found}, state}
    end
  end

  def handle_call(:report, _from, state) do
    report = Map.new(state, fn {name, probe} -> {name, probe.level} end)
    {:reply, report, state}
  end

  def handle_call({:probe_now, name}, _from, state) do
    case Map.fetch(state, name) do
      {:ok, probe} ->
        updated = run_check(name, probe)
        {:reply, {:ok, updated.level}, Map.put(state, name, updated)}

      :error ->
        {:reply, {:error, :not_found}, state}
    end
  end

  def handle_call({:remove_probe, name}, _from, state) do
    case Map.has_key?(state, name) do
      true -> {:reply, :ok, Map.delete(state, name)}
      false -> {:reply, {:error, :not_found}, state}
    end
  end

  @impl true
  def handle_info({:check, name, token}, state) do
    case Map.fetch(state, name) do
      {:ok, %{token: ^token} = probe} ->
        updated = run_check(name, probe)
        Process.send_after(self(), {:check, name, token}, probe.interval_ms)
        {:noreply, Map.put(state, name, updated)}

      _ ->
        {:noreply, state}
    end
  end

  def handle_info(_msg, state) do
    {:noreply, state}
  end

  # ── Internal helpers ──────────────────────────────────────────────────────

  @spec run_check(term(), map()) :: map()
  defp run_check(name, probe) do
    old_level = probe.level

    {new_count, new_level, reason} =
      case probe.check_func.() do
        :ok ->
          {0, :ok, nil}

        {:error, reason} ->
          count = probe.fail_count + 1
          {count, level_for(count, probe.warn_after, probe.crit_after), reason}
      end

    if new_level != old_level do
      probe.on_change.(name, old_level, new_level, reason)
    end

    %{probe | fail_count: new_count, level: new_level}
  end

  @spec level_for(non_neg_integer(), pos_integer(), pos_integer()) :: level()
  defp level_for(count, warn_after, crit_after) do
    cond do
      count >= crit_after -> :critical
      count >= warn_after -> :warning
      true -> :ok
    end
  end
end
```

## Test harness — implement the `# TODO` test

```elixir
defmodule HealthMonitorTest do
  use ExUnit.Case, async: false

  setup do
    start_supervised!({HealthMonitor, []})
    :ok
  end

  defp flush_probes do
    receive do
      {:probe, _} -> flush_probes()
    after
      0 -> :ok
    end
  end

  defp collect_probes(acc) do
    receive do
      {:probe, x} -> collect_probes([x | acc])
    after
      0 -> Enum.reverse(acc)
    end
  end

  test "a freshly started monitor reports nothing" do
    assert HealthMonitor.report() == %{}
  end

  test "add_probe returns :ok and the probe starts at :ok" do
    assert :ok = HealthMonitor.add_probe("svc", fn -> :ok end, 10_000)
    assert HealthMonitor.level("svc") == :ok
    assert HealthMonitor.report() == %{"svc" => :ok}
  end

  test "add_probe guards a non-positive interval" do
    assert_raise FunctionClauseError, fn ->
      HealthMonitor.add_probe("bad", fn -> :ok end, 0)
    end

    assert :ok = HealthMonitor.add_probe("ok", fn -> :ok end, 10_000)
    assert HealthMonitor.level("ok") == :ok
  end

  test "add_probe guards a non-zero-arity check function" do
    assert_raise FunctionClauseError, fn ->
      HealthMonitor.add_probe("bad", fn _x -> :ok end, 10_000)
    end

    assert :ok = HealthMonitor.add_probe("ok", fn -> :ok end, 10_000)
    assert HealthMonitor.level("ok") == :ok
  end

  test "level and probe_now report unknown probes" do
    assert HealthMonitor.level("nope") == {:error, :not_found}
    assert HealthMonitor.probe_now("nope") == {:error, :not_found}
  end

  test "consecutive failures escalate :ok -> :warning -> :critical, firing on_change per step" do
    test = self()
    hook = fn n, o, nw, r -> send(test, {:changed, n, o, nw, r}) end

    :ok =
      HealthMonitor.add_probe("svc", fn -> {:error, :boom} end, 10_000,
        warn_after: 2,
        crit_after: 3,
        on_change: hook
      )

    # First failure keeps it :ok (count 1 < warn_after 2): no callback.
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    refute_receive {:changed, "svc", _, _, _}, 50

    # Second failure reaches warn_after: escalate :ok -> :warning.
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
    assert_receive {:changed, "svc", :ok, :warning, :boom}, 500

    # Third failure reaches crit_after: escalate :warning -> :critical.
    assert {:ok, :critical} = HealthMonitor.probe_now("svc")
    assert_receive {:changed, "svc", :warning, :critical, :boom}, 500

    assert HealthMonitor.level("svc") == :critical
  end

  test "default thresholds are warn_after 2 and crit_after 4" do
    :ok = HealthMonitor.add_probe("svc", fn -> {:error, :e} end, 10_000)
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
    assert {:ok, :critical} = HealthMonitor.probe_now("svc")
  end

  test "a success recovers to :ok and fires on_change with a nil reason" do
    # TODO
  end

  test "a success resets the consecutive-failure count" do
    {:ok, box} = Agent.start_link(fn -> {:error, :e} end)
    check = fn -> Agent.get(box, & &1) end
    :ok = HealthMonitor.add_probe("svc", check, 10_000, warn_after: 3, crit_after: 5)

    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")

    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")

    Agent.update(box, fn _ -> {:error, :e} end)
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
  end

  test "remove_probe deletes a probe and reports not_found for unknown removals" do
    :ok = HealthMonitor.add_probe("svc", fn -> :ok end, 10_000)
    assert HealthMonitor.report() == %{"svc" => :ok}

    assert :ok = HealthMonitor.remove_probe("svc")
    assert HealthMonitor.level("svc") == {:error, :not_found}
    assert HealthMonitor.report() == %{}

    assert HealthMonitor.remove_probe("svc") == {:error, :not_found}
  end

  test "re-adding a probe resets its level and applies the new config" do
    :ok =
      HealthMonitor.add_probe("svc", fn -> {:error, :x} end, 10_000,
        warn_after: 1,
        crit_after: 1
      )

    assert {:ok, :critical} = HealthMonitor.probe_now("svc")
    assert HealthMonitor.level("svc") == :critical

    :ok =
      HealthMonitor.add_probe("svc", fn -> {:error, :y} end, 10_000,
        warn_after: 1,
        crit_after: 2
      )

    assert HealthMonitor.level("svc") == :ok

    # New crit_after of 2 governs now: one failure is only :warning.
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
  end

  test "re-adding a probe kills the previous schedule" do
    test = self()

    a = fn ->
      send(test, {:probe, :a})
      :ok
    end

    :ok = HealthMonitor.add_probe("svc", a, 20)
    assert_receive {:probe, :a}, 1_000
    assert_receive {:probe, :a}, 1_000

    b = fn ->
      send(test, {:probe, :b})
      :ok
    end

    :ok = HealthMonitor.add_probe("svc", b, 20)

    flush_probes()
    Process.sleep(200)
    ticks = collect_probes([])

    assert :b in ticks
    refute :a in ticks
  end

  test "remove_probe kills the previous schedule" do
    test = self()

    c = fn ->
      send(test, {:probe, :c})
      :ok
    end

    :ok = HealthMonitor.add_probe("svc", c, 20)
    assert_receive {:probe, :c}, 1_000

    assert :ok = HealthMonitor.remove_probe("svc")

    flush_probes()
    Process.sleep(200)
    assert collect_probes([]) == []
  end

  test "periodic checks run at the configured interval" do
    test = self()

    :ok =
      HealthMonitor.add_probe(
        "svc",
        fn ->
          send(test, {:probe, :a})
          :ok
        end,
        20
      )

    assert_receive {:probe, :a}, 1_000
    assert_receive {:probe, :a}, 1_000
  end

  test "probes are independent" do
    :ok =
      HealthMonitor.add_probe("a", fn -> {:error, :x} end, 10_000, warn_after: 1, crit_after: 1)

    :ok = HealthMonitor.add_probe("b", fn -> :ok end, 10_000)

    assert {:ok, :critical} = HealthMonitor.probe_now("a")
    assert {:ok, :ok} = HealthMonitor.probe_now("b")

    assert HealthMonitor.level("a") == :critical
    assert HealthMonitor.level("b") == :ok
    assert HealthMonitor.report() == %{"a" => :critical, "b" => :ok}
  end

  test "unexpected messages do not crash the server" do
    :ok = HealthMonitor.add_probe("svc", fn -> :ok end, 10_000)
    send(HealthMonitor, :garbage)
    send(HealthMonitor, {:more, :garbage})
    assert HealthMonitor.level("svc") == :ok
  end

  test "atom and tuple probe names work and compare by value" do
    :ok = HealthMonitor.add_probe(:svc, fn -> :ok end, 10_000)

    :ok =
      HealthMonitor.add_probe({:svc, 1}, fn -> {:error, :x} end, 10_000,
        warn_after: 1,
        crit_after: 1
      )

    assert HealthMonitor.level(:svc) == :ok
    assert {:ok, :critical} = HealthMonitor.probe_now({:svc, 1})
    assert HealthMonitor.level({:svc, 1}) == :critical
    assert HealthMonitor.report() == %{:svc => :ok, {:svc, 1} => :critical}
  end

  test "registering a probe does not immediately invoke the check function" do
    test = self()

    check = fn ->
      send(test, {:probe, :called})
      :ok
    end

    :ok = HealthMonitor.add_probe("svc", check, 10_000)
    refute_receive {:probe, :called}, 100
    assert HealthMonitor.level("svc") == :ok
  end

  test "a single escalating check fires on_change only once" do
    test = self()
    hook = fn n, o, nw, r -> send(test, {:changed, n, o, nw, r}) end

    :ok =
      HealthMonitor.add_probe("svc", fn -> {:error, :boom} end, 10_000,
        warn_after: 1,
        crit_after: 5,
        on_change: hook
      )

    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
    assert_receive {:changed, "svc", :ok, :warning, :boom}, 500
    refute_receive {:changed, "svc", _, _, _}, 100
  end

  test "add_probe guards a non-integer interval" do
    assert_raise FunctionClauseError, fn ->
      HealthMonitor.add_probe("bad", fn -> :ok end, 10.5)
    end

    assert :ok = HealthMonitor.add_probe("ok", fn -> :ok end, 10_000)
    assert HealthMonitor.level("ok") == :ok
  end
end
```
