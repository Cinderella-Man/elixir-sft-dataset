  test "watch returns :ok and the service starts :up" do
    assert :ok = StabilityMonitor.watch("svc", fn -> :ok end, 10_000)
    assert StabilityMonitor.state("svc") == :up
    assert StabilityMonitor.states() == %{"svc" => :up}
  end