  test "the default confirmations are fail_confirm 3 and ok_confirm 2" do
    {:ok, box} = Agent.start_link(fn -> {:error, :e} end)
    check = fn -> Agent.get(box, & &1) end
    :ok = StabilityMonitor.watch("svc", check, 10_000)

    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    assert {:ok, :up} = StabilityMonitor.force_check("svc")
    assert {:ok, :down} = StabilityMonitor.force_check("svc")

    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :down} = StabilityMonitor.force_check("svc")
    assert {:ok, :up} = StabilityMonitor.force_check("svc")
  end