  test "a freshly started monitor tracks nothing" do
    assert StabilityMonitor.states() == %{}
  end