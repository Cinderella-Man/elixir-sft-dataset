  test "notify fires exactly once on the :up -> :down transition" do
    test = self()

    :ok =
      Monitor.register("svc", fn -> {:error, :boom} end, 10_000,
        threshold: 3,
        notify: fn name, reason -> send(test, {:notified, name, reason}) end
      )

    # No notification before the threshold is reached.
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :up} = Monitor.check_now("svc")
    refute_receive {:notified, "svc", _}, 50

    # The third consecutive failure fires the notification once.
    assert {:ok, :down} = Monitor.check_now("svc")
    assert_receive {:notified, "svc", :boom}, 500

    # Further failures while already down must NOT re-notify.
    assert {:ok, :down} = Monitor.check_now("svc")
    assert {:ok, :down} = Monitor.check_now("svc")
    refute_receive {:notified, "svc", _}, 100
  end