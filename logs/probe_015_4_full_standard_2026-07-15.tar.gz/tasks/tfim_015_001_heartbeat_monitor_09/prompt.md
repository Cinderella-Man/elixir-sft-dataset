# Fill in the middle: implement the blanked test

Below is a module and its ExUnit test harness with the body of ONE `test` removed
(marked `# TODO`). The test's name states what it must verify. Implement just that one
test so the harness passes for a correct implementation of the module.

## Module under test

```elixir
defmodule Monitor do
  @moduledoc """
  A singleton `GenServer` that supervises registered services by periodically
  calling a zero-arity check function for each one, tracking each service's
  `:up`/`:down` status, and firing a notification when a service transitions
  from `:up` to `:down`.

  The server is registered under the name `Monitor` (`__MODULE__`) so that the
  no-argument convenience API (`register/4`, `status/1`, `statuses/0`,
  `check_now/1`) can locate it without an explicit server reference.

  Each registration is tagged with a generation token (a `make_ref/0` value).
  Scheduled check messages whose token no longer matches the current
  registration are ignored, guaranteeing that a re-registration's superseded
  timer chain is dead and can never call the old check function again.
  """

  use GenServer

  @typedoc "The status of a monitored service."
  @type status :: :up | :down

  @typedoc "A zero-arity check function returning health of a service."
  @type check_func :: (-> :ok | {:error, term()})

  @typedoc "A two-arity notification function invoked on a down transition."
  @type notify_func :: (term(), term() -> any())

  # Internal per-service record kept in the server state map.
  @typep service :: %{
           check_func: check_func(),
           interval_ms: pos_integer(),
           threshold: pos_integer(),
           notify: notify_func(),
           status: status(),
           failures: non_neg_integer(),
           generation: reference()
         }

  # --- Public API --------------------------------------------------------

  @doc """
  Starts and links the `Monitor` singleton.

  `opts` is a keyword list (default `[]`). A `:name` option may override the
  registered name, but the convenience functions always target `Monitor`.
  A freshly started server tracks zero services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    {name, opts} = Keyword.pop(opts, :name, __MODULE__)
    GenServer.start_link(__MODULE__, opts, name: name)
  end

  @doc """
  Registers (or re-registers) `service_name` with the given zero-arity
  `check_func`, positive `interval_ms`, and options.

  Options:

    * `:threshold` — positive integer `N`; the service is marked `:down` after
      `N` consecutive failed checks (default `3`).
    * `:notify` — a two-arity function `notify.(service_name, reason)` invoked
      once on each `:up` -> `:down` transition (default no-op).

  Registration resets the status to `:up` with a failure count of `0` and does
  not itself run `check_func`; the first check happens one `interval_ms` later.
  Re-registering replaces the configuration and resets status. Always returns
  `:ok`.
  """
  @spec register(term(), check_func(), pos_integer(), keyword()) :: :ok
  def register(service_name, check_func, interval_ms, opts \\ [])
      when is_function(check_func, 0) and is_integer(interval_ms) and interval_ms > 0 do
    GenServer.call(__MODULE__, {:register, service_name, check_func, interval_ms, opts})
  end

  @doc """
  Returns `:up` or `:down` for a registered service, or `{:error, :not_found}`
  if the service is unknown.
  """
  @spec status(term()) :: status() | {:error, :not_found}
  def status(service_name) do
    GenServer.call(__MODULE__, {:status, service_name})
  end

  @doc """
  Returns a map `%{service_name => status}` for every currently registered
  service. Returns `%{}` when no services are registered.
  """
  @spec statuses() :: %{optional(term()) => status()}
  def statuses do
    GenServer.call(__MODULE__, :statuses)
  end

  @doc """
  Synchronously performs exactly one check for `service_name` immediately,
  doing identical work to a scheduled interval tick (calling the check
  function, updating the failure count and status, and firing the notify
  function on an `:up` -> `:down` transition).

  Returns `{:ok, status}` with the resulting status, or `{:error, :not_found}`
  if the service is unknown. Does not alter or reschedule the periodic timer.
  """
  @spec check_now(term()) :: {:ok, status()} | {:error, :not_found}
  def check_now(service_name) do
    GenServer.call(__MODULE__, {:check_now, service_name})
  end

  # --- GenServer callbacks ----------------------------------------------

  @impl true
  @spec init(keyword()) :: {:ok, %{optional(term()) => service()}}
  def init(_opts) do
    {:ok, %{}}
  end

  @impl true
  def handle_call({:register, name, func, interval, opts}, _from, state) do
    generation = make_ref()
    threshold = Keyword.get(opts, :threshold, 3)
    notify = Keyword.get(opts, :notify, fn _name, _reason -> :ok end)

    service = %{
      check_func: func,
      interval_ms: interval,
      threshold: threshold,
      notify: notify,
      status: :up,
      failures: 0,
      generation: generation
    }

    schedule(name, generation, interval)
    {:reply, :ok, Map.put(state, name, service)}
  end

  def handle_call({:status, name}, _from, state) do
    case Map.get(state, name) do
      nil -> {:reply, {:error, :not_found}, state}
      service -> {:reply, service.status, state}
    end
  end

  def handle_call(:statuses, _from, state) do
    result = Map.new(state, fn {name, service} -> {name, service.status} end)
    {:reply, result, state}
  end

  def handle_call({:check_now, name}, _from, state) do
    case Map.get(state, name) do
      nil ->
        {:reply, {:error, :not_found}, state}

      service ->
        {updated, status} = run_check(service, name)
        {:reply, {:ok, status}, Map.put(state, name, updated)}
    end
  end

  def handle_call(_request, _from, state) do
    {:reply, {:error, :unknown_request}, state}
  end

  @impl true
  def handle_info({:check, name, generation}, state) do
    case Map.get(state, name) do
      %{generation: ^generation} = service ->
        {updated, _status} = run_check(service, name)
        schedule(name, generation, updated.interval_ms)
        {:noreply, Map.put(state, name, updated)}

      _other ->
        # Unknown service or a superseded generation token: ignore.
        {:noreply, state}
    end
  end

  def handle_info(_msg, state) do
    {:noreply, state}
  end

  # --- Internal helpers --------------------------------------------------

  # Schedules the next check tick for `name` under the given generation token.
  @spec schedule(term(), reference(), pos_integer()) :: reference()
  defp schedule(name, generation, interval) do
    Process.send_after(self(), {:check, name, generation}, interval)
  end

  # Runs one check, updating failure count/status and firing notify on an
  # `:up` -> `:down` transition. Returns `{updated_service, resulting_status}`.
  @spec run_check(service(), term()) :: {service(), status()}
  defp run_check(service, name) do
    case service.check_func.() do
      :ok ->
        {%{service | failures: 0, status: :up}, :up}

      {:error, reason} ->
        failures = service.failures + 1

        if service.status == :up and failures >= service.threshold do
          service.notify.(name, reason)
          {%{service | failures: failures, status: :down}, :down}
        else
          {%{service | failures: failures}, service.status}
        end
    end
  end
end
```

## Test harness — implement the `# TODO` test

```elixir
defmodule MonitorTest do
  use ExUnit.Case, async: false

  setup do
    start_supervised!({Monitor, []})
    :ok
  end

  # ------------------------------------------------------------------
  # Small mailbox helpers for the timer-based lifecycle test
  # ------------------------------------------------------------------

  defp flush_ticks do
    receive do
      {:tick, _} -> flush_ticks()
    after
      0 -> :ok
    end
  end

  defp collect_ticks(acc) do
    receive do
      {:tick, x} -> collect_ticks([x | acc])
    after
      0 -> Enum.reverse(acc)
    end
  end

  # ------------------------------------------------------------------
  # Registration basics
  # ------------------------------------------------------------------

  test "a freshly started monitor tracks nothing" do
    assert Monitor.statuses() == %{}
  end

  test "register returns :ok and the service starts :up" do
    assert :ok = Monitor.register("svc", fn -> :ok end, 10_000)
    assert Monitor.status("svc") == :up
    assert Monitor.statuses() == %{"svc" => :up}
  end

  test "register guards a non-positive interval" do
    assert_raise FunctionClauseError, fn ->
      Monitor.register("bad", fn -> :ok end, 0)
    end

    # The server must still be alive and usable afterwards.
    assert :ok = Monitor.register("ok", fn -> :ok end, 10_000)
    assert Monitor.status("ok") == :up
  end

  # ------------------------------------------------------------------
  # Unknown services
  # ------------------------------------------------------------------

  test "status and check_now report unknown services" do
    assert Monitor.status("nope") == {:error, :not_found}
    assert Monitor.check_now("nope") == {:error, :not_found}
  end

  # ------------------------------------------------------------------
  # Status transitions via deterministic check_now
  # ------------------------------------------------------------------

  test "default threshold of 3 consecutive failures marks the service :down" do
    # Long interval so the periodic timer never fires during the test.
    :ok = Monitor.register("svc", fn -> {:error, :x} end, 10_000)

    assert {:ok, :up} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :up

    assert {:ok, :up} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :up

    assert {:ok, :down} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :down
  end

  test "a custom threshold of 1 goes :down on the first failure" do
    :ok = Monitor.register("svc", fn -> {:error, :boom} end, 10_000, threshold: 1)
    assert {:ok, :down} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :down
  end

  test "an :ok result resets the consecutive-failure counter" do
    {:ok, box} = Agent.start_link(fn -> {:error, :e} end)
    check = fn -> Agent.get(box, & &1) end

    :ok = Monitor.register("svc", check, 10_000, threshold: 3)

    # Two failures, then a success resets the counter.
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :up} = Monitor.check_now("svc")

    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :up} = Monitor.check_now("svc")

    # Now it takes three fresh failures to go down, not one.
    Agent.update(box, fn _ -> {:error, :e} end)
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :down} = Monitor.check_now("svc")
  end

  # ------------------------------------------------------------------
  # Notification: exactly once per transition
  # ------------------------------------------------------------------

  test "notify fires exactly once on the :up -> :down transition" do
    # TODO
  end

  test "recovery then re-failure notifies again (once per distinct transition)" do
    test = self()
    {:ok, box} = Agent.start_link(fn -> {:error, :down1} end)
    check = fn -> Agent.get(box, & &1) end

    :ok =
      Monitor.register("svc", check, 10_000,
        threshold: 2,
        notify: fn name, reason -> send(test, {:notified, name, reason}) end
      )

    # First down transition.
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :down} = Monitor.check_now("svc")
    assert_receive {:notified, "svc", :down1}, 500

    # Recover to :up (no notification on recovery).
    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :up} = Monitor.check_now("svc")
    refute_receive {:notified, "svc", _}, 50

    # Fail again -> a fresh down transition fires the notification again.
    Agent.update(box, fn _ -> {:error, :down2} end)
    assert {:ok, :up} = Monitor.check_now("svc")
    assert {:ok, :down} = Monitor.check_now("svc")
    assert_receive {:notified, "svc", :down2}, 500
  end

  # ------------------------------------------------------------------
  # Re-registration resets configuration and status
  # ------------------------------------------------------------------

  test "re-registering resets status to :up and applies the new config" do
    test = self()

    # Drive the service :down under the original threshold and notify.
    :ok =
      Monitor.register("svc", fn -> {:error, :old} end, 10_000,
        threshold: 1,
        notify: fn name, reason -> send(test, {:old, name, reason}) end
      )

    assert {:ok, :down} = Monitor.check_now("svc")
    assert Monitor.status("svc") == :down
    assert_receive {:old, "svc", :old}, 500

    # Re-registering replaces config (new check + threshold + notify) and
    # resets the status back to :up with a fresh failure count of 0.
    :ok =
      Monitor.register("svc", fn -> {:error, :new} end, 10_000,
        threshold: 2,
        notify: fn name, reason -> send(test, {:new, name, reason}) end
      )

    assert Monitor.status("svc") == :up

    # The new threshold of 2 governs now: one failure keeps it :up, and the
    # old notify function must never fire again.
    assert {:ok, :up} = Monitor.check_now("svc")
    refute_receive {:old, "svc", _}, 50
    refute_receive {:new, "svc", _}, 50

    # The second consecutive failure trips the NEW notify with the NEW reason.
    assert {:ok, :down} = Monitor.check_now("svc")
    assert_receive {:new, "svc", :new}, 500
    refute_receive {:old, "svc", _}, 50
  end

  # ------------------------------------------------------------------
  # Independence between services
  # ------------------------------------------------------------------

  test "services are independent" do
    :ok = Monitor.register("a", fn -> {:error, :x} end, 10_000, threshold: 1)
    :ok = Monitor.register("b", fn -> :ok end, 10_000, threshold: 1)

    assert {:ok, :down} = Monitor.check_now("a")
    assert {:ok, :up} = Monitor.check_now("b")

    assert Monitor.status("a") == :down
    assert Monitor.status("b") == :up
    assert Monitor.statuses() == %{"a" => :down, "b" => :up}
  end

  # ------------------------------------------------------------------
  # Robustness: unexpected messages are ignored
  # ------------------------------------------------------------------

  test "unexpected messages do not crash the server" do
    :ok = Monitor.register("svc", fn -> :ok end, 10_000)
    send(Monitor, :some_garbage_message)
    send(Monitor, {:more, :garbage})
    # A synchronous call proves the server processed past the garbage intact.
    assert Monitor.status("svc") == :up
  end

  # ------------------------------------------------------------------
  # Periodic scheduling + lifecycle: re-registration kills the old schedule
  # ------------------------------------------------------------------

  test "periodic checks run, and re-registration kills the previous schedule" do
    test = self()

    a = fn ->
      send(test, {:tick, :a})
      :ok
    end

    # First registration: prove the periodic schedule actually runs.
    :ok = Monitor.register("svc", a, 20)
    assert_receive {:tick, :a}, 1_000
    assert_receive {:tick, :a}, 1_000

    # Re-register with a different check function. Because register/4 is a
    # synchronous call, once it returns the new generation is in effect and the
    # old check function can never be invoked again by a leftover timer.
    b = fn ->
      send(test, {:tick, :b})
      :ok
    end

    :ok = Monitor.register("svc", b, 20)

    # Drop any :a ticks queued in our mailbox from before the swap.
    flush_ticks()

    # Over a fresh window we must see the NEW check running and NEVER the old one.
    Process.sleep(200)
    ticks = collect_ticks([])

    assert :b in ticks
    refute :a in ticks
  end

  test "the down notification carries the Nth consecutive failure's reason" do
    test = self()
    {:ok, box} = Agent.start_link(fn -> {:error, :first} end)
    check = fn -> Agent.get(box, & &1) end

    :ok =
      Monitor.register("svc", check, 10_000,
        threshold: 2,
        notify: fn name, reason -> send(test, {:notified, name, reason}) end
      )

    # First failure keeps it :up with reason :first.
    assert {:ok, :up} = Monitor.check_now("svc")

    # Second (threshold-reaching) failure carries a DIFFERENT reason.
    Agent.update(box, fn _ -> {:error, :second} end)
    assert {:ok, :down} = Monitor.check_now("svc")

    # The notify reason must be the 2nd failing check's reason, not the 1st.
    assert_receive {:notified, "svc", :second}, 500
  end

  test "register guards against a non-zero-arity check function" do
    assert_raise FunctionClauseError, fn ->
      Monitor.register("bad", fn _x -> :ok end, 10_000)
    end

    # The server must still be alive and usable afterwards.
    assert :ok = Monitor.register("ok", fn -> :ok end, 10_000)
    assert Monitor.status("ok") == :up
  end

  test "atom and tuple service names work and compare by value" do
    :ok = Monitor.register(:svc, fn -> :ok end, 10_000)
    :ok = Monitor.register({:svc, 1}, fn -> {:error, :x} end, 10_000, threshold: 1)

    assert Monitor.status(:svc) == :up

    # A freshly built equal tuple must address the same registration.
    assert {:ok, :down} = Monitor.check_now({:svc, 1})
    assert Monitor.status({:svc, 1}) == :down
    assert Monitor.statuses() == %{:svc => :up, {:svc, 1} => :down}
  end
end
```
