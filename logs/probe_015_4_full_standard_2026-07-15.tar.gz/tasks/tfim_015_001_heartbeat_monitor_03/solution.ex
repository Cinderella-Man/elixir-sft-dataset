  test "register returns :ok and the service starts :up" do
    assert :ok = Monitor.register("svc", fn -> :ok end, 10_000)
    assert Monitor.status("svc") == :up
    assert Monitor.statuses() == %{"svc" => :up}
  end