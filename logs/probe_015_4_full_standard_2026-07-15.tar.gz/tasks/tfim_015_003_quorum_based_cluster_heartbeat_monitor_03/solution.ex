  test "register_cluster returns :ok, starts :up, and reports healthy == total" do
    funcs = [fn -> :ok end, fn -> :ok end, fn -> :ok end]
    assert :ok = ClusterMonitor.register_cluster("c", funcs, 10_000)
    assert ClusterMonitor.cluster_state("c") == %{status: :up, healthy: 3, total: 3}
    assert ClusterMonitor.snapshot() == %{"c" => :up}
  end