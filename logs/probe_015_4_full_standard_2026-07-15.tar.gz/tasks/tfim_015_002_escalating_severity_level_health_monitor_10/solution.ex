  test "a success resets the consecutive-failure count" do
    {:ok, box} = Agent.start_link(fn -> {:error, :e} end)
    check = fn -> Agent.get(box, & &1) end
    :ok = HealthMonitor.add_probe("svc", check, 10_000, warn_after: 3, crit_after: 5)

    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")

    Agent.update(box, fn _ -> :ok end)
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")

    Agent.update(box, fn _ -> {:error, :e} end)
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert {:ok, :ok} = HealthMonitor.probe_now("svc")
    assert {:ok, :warning} = HealthMonitor.probe_now("svc")
  end