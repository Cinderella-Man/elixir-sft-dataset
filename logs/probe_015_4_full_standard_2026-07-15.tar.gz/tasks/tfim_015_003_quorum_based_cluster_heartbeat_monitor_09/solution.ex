  test "cluster_state reports healthy and total after a poll" do
    {:ok, b1} = Agent.start_link(fn -> :ok end)
    {:ok, b2} = Agent.start_link(fn -> :ok end)
    {:ok, b3} = Agent.start_link(fn -> :ok end)

    :ok =
      ClusterMonitor.register_cluster("c", [endpoint(b1), endpoint(b2), endpoint(b3)], 10_000,
        quorum: 2
      )

    Agent.update(b1, fn _ -> {:error, :x} end)
    assert {:ok, :up} = ClusterMonitor.poll("c")
    assert ClusterMonitor.cluster_state("c") == %{status: :up, healthy: 2, total: 3}
  end