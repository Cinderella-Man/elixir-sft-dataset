# Write tests for this module

Below is a completed Elixir module and the original specification it was built to
satisfy. Write a comprehensive ExUnit test harness that verifies a correct
implementation of this module.

Requirements for the harness:
- Define a module `<Module>Test` that does `use ExUnit.Case, async: false`.
- Do NOT call `ExUnit.start()` — the evaluator starts ExUnit itself.
- Make it self-contained: any fakes, clock Agents, or helpers are defined inline.
- Cover the full public API and the important edge cases described in the spec.
- It must compile with ZERO warnings (prefix unused variables with `_`; match float
  zero as `+0.0`/`-0.0`).
- Give me the complete harness in a single file.

## Original specification

# Hysteresis Flapping-Suppression Monitor

Write me an Elixir module called `StabilityMonitor` — a `GenServer` that supervises
registered services by calling a check function for each one on a periodic interval,
and reports a **confirmed** `:up`/`:down` state that changes only after the service
has been consistently failing (or consistently recovering) for a configured number
of checks. This hysteresis suppresses "flapping" — a service that alternates between
success and failure never changes its confirmed state. Use only the OTP standard
library, no external dependencies, and give me the complete module in a single file.

## The singleton and its lifecycle

`StabilityMonitor` is a singleton process. The convenience functions below
(`watch`, `force_check`, `state`, `states`, `unwatch`) take **no server argument** —
they operate on the process registered under the module name `StabilityMonitor`.

- `StabilityMonitor.start_link(opts \\ [])` starts and links the process and returns
  the usual `GenServer.on_start()` result. `opts` is a keyword list defaulting to
  `[]`. The process must be registered under the name `StabilityMonitor` (i.e.
  `__MODULE__`) so the no-argument convenience API can find it. A `:name` option may
  override the registered name, but the convenience functions always target
  `StabilityMonitor`.
- Starting the server does no monitoring work; a freshly started server tracks zero
  services, and `StabilityMonitor.states()` returns `%{}`.

## Registering services

`StabilityMonitor.watch(name, check_func, interval_ms, opts \\ [])`

- `name` is any term used as the key (strings, atoms, tuples all work and are
  compared by value).
- `check_func` is a **zero-arity** function returning either `:ok` (healthy) or
  `{:error, reason}` (unhealthy), where `reason` is any term.
- `interval_ms` is a **positive integer**: how often, in milliseconds, the monitor
  calls `check_func` after registration.
- `opts` is a keyword list:
  - `:fail_confirm` — a **positive integer** `F`: the number of **consecutive**
    failures required to confirm a transition to `:down`. Defaults to `3`.
  - `:ok_confirm` — a **positive integer** `K`: the number of **consecutive**
    successes required to confirm a transition back to `:up`. Defaults to `2`.
  - `:on_transition` — a **three-arity** function
    `on_transition.(name, from_state, to_state)` invoked whenever the confirmed
    state changes (see below). Defaults to a no-op.

`watch/4` returns `:ok`.

Guards: `check_func` must be a zero-arity function and `interval_ms` must be a
positive integer. Calling `watch` with a non-positive or non-integer `interval_ms`,
or a check function of the wrong arity, is outside the contract and raises
`FunctionClauseError`; guard the public function accordingly.

On registration:

- The service's confirmed state starts as `:up`, with a failure streak of `0` and a
  success streak of `0`.
- Registration itself does **not** run the check function. The first check happens
  one `interval_ms` later, then repeats every `interval_ms` thereafter (implemented
  with `Process.send_after/3`, re-scheduling itself after each check).

Re-watching an already-registered `name` **replaces** its configuration (check
function, interval, confirmations, on_transition) and **resets** its confirmed state
to `:up` with both streaks at `0`.

### Lifecycle rule for re-watching (important)

When a service is re-watched, the **previous registration's scheduled checks must
never run again**. After a re-watch:

- The old check function is never called again by any leftover/previously-scheduled
  timer.
- Checks for that service happen only at the **new** interval, calling the **new**
  check function.

Superseded timer chains are dead. (A robust way to achieve this is to tag each
registration with a generation token and ignore scheduled check messages whose token
no longer matches the current registration.)

## Performing a check

Each check — whether triggered by the periodic timer or by `force_check/1` below —
calls `check_func.()` exactly once and then updates the service using two counters,
a failure streak and a success streak:

- On `:ok`:
  - The failure streak is reset to `0`.
  - If the confirmed state is currently `:down`, the success streak is incremented
    by one. If it then **reaches** `ok_confirm`, the confirmed state transitions to
    `:up`, `on_transition.(name, :down, :up)` is called **exactly once**, and the
    success streak is reset to `0`. Otherwise the confirmed state stays `:down`.
  - If the confirmed state is currently `:up`, the success streak is reset to `0`
    (a healthy check simply keeps a healthy service up; no callback fires).

- On `{:error, _reason}`:
  - The success streak is reset to `0`.
  - If the confirmed state is currently `:up`, the failure streak is incremented by
    one. If it then **reaches** `fail_confirm`, the confirmed state transitions to
    `:down`, `on_transition.(name, :up, :down)` is called **exactly once**, and the
    failure streak is reset to `0`. Otherwise the confirmed state stays `:up`.
  - If the confirmed state is currently `:down`, the failure streak is reset to `0`
    (a failing check simply keeps a down service down; no callback fires).

Because a result opposite to the current confirmed state resets the streak that was
building toward the current state, **alternating** results (a failure, then a
success, then a failure, …) never accumulate enough in a row to confirm a transition:
the confirmed state stays put and `on_transition` never fires. A confirmed transition
fires `on_transition` exactly once, and going down, then up, then down again fires it
once per confirmed change.

## Deterministic single check

`StabilityMonitor.force_check(name)` synchronously performs **one** check for the
named service immediately — identical work to a scheduled interval tick (calling the
check function, updating the streaks and confirmed state, and firing `on_transition`
on a confirmed change). It returns `{:ok, state}` where `state` is the resulting
confirmed state (`:up` or `:down`), or `{:error, :not_found}` if no such service is
registered. `force_check/1` does not alter or reschedule the periodic timer.

## Querying and removing

- `StabilityMonitor.state(name)` returns the confirmed state `:up` or `:down` for a
  registered service, or `{:error, :not_found}` if the service is unknown.
- `StabilityMonitor.states()` returns a map `%{name => state}` containing every
  currently registered service and its confirmed `:up`/`:down` state. With no
  services registered it returns `%{}`.
- `StabilityMonitor.unwatch(name)` removes a service. It returns `:ok` if the service
  existed (after removal it no longer appears in `states/0` and `state/1` returns
  `{:error, :not_found}`), or `{:error, :not_found}` if no such service was
  registered. After removal the service's scheduled checks must never run again — its
  timer chain is dead.

## Robustness

Any unexpected message sent to the server (anything other than the messages it uses
for its own scheduling) must be ignored: it must not crash the process or alter
state.

Services are fully independent: driving one service's streaks never affects another
service's confirmed state or counters.

## Module under test

```elixir
defmodule StabilityMonitor do
  @moduledoc """
  A singleton `GenServer` that supervises registered services by periodically
  calling a zero-arity check function for each one, and reports a *confirmed*
  `:up`/`:down` state that changes only after the service has been consistently
  failing (or consistently recovering) for a configured number of checks.

  This hysteresis suppresses "flapping": a service that alternates between success
  and failure never changes its confirmed state, because a result opposite to the
  current confirmed state resets the streak that was building toward a transition.

  Each service tracks:

    * a confirmed `state` (`:up` or `:down`), starting at `:up`;
    * a `fail_streak` counter of consecutive failures while `:up`;
    * an `ok_streak` counter of consecutive successes while `:down`.

  A confirmed transition invokes the service's `:on_transition` callback exactly
  once. Services are fully independent of one another.

  Only the OTP standard library is used.
  """

  use GenServer

  @default_fail_confirm 3
  @default_ok_confirm 2
  @noop_transition &StabilityMonitor.__noop_transition__/3

  @typedoc "Confirmed service state."
  @type confirmed_state :: :up | :down

  @typedoc "A zero-arity health check returning `:ok` or `{:error, reason}`."
  @type check_func :: (-> :ok | {:error, term()})

  @typedoc "Callback invoked on a confirmed transition."
  @type on_transition :: (term(), confirmed_state(), confirmed_state() -> any())

  ## Public API

  @doc """
  Starts and links the monitor process.

  The process is registered under the name `StabilityMonitor` (overridable with the
  `:name` option, though the convenience functions always target `StabilityMonitor`).
  A freshly started server tracks zero services.
  """
  @spec start_link(keyword()) :: GenServer.on_start()
  def start_link(opts \\ []) do
    {name, opts} = Keyword.pop(opts, :name, __MODULE__)
    GenServer.start_link(__MODULE__, opts, name: name)
  end

  @doc """
  Registers (or re-registers) a service to be watched.

  `name` is any term used as the key. `check_func` is a zero-arity function returning
  `:ok` or `{:error, reason}`. `interval_ms` is a positive integer giving the check
  period in milliseconds; the first check runs one interval after registration.

  Options:

    * `:fail_confirm` — positive integer, consecutive failures to confirm `:down`
      (default `3`);
    * `:ok_confirm` — positive integer, consecutive successes to confirm `:up`
      (default `2`);
    * `:on_transition` — three-arity `fun.(name, from, to)` fired on each confirmed
      transition (default no-op).

  Re-watching an existing `name` replaces its configuration and resets its confirmed
  state to `:up` with both streaks at `0`; any previously scheduled checks for it are
  discarded. Returns `:ok`.
  """
  @spec watch(term(), check_func(), pos_integer(), keyword()) :: :ok
  def watch(name, check_func, interval_ms, opts \\ [])
      when is_function(check_func, 0) and is_integer(interval_ms) and interval_ms > 0 do
    GenServer.call(__MODULE__, {:watch, name, check_func, interval_ms, opts})
  end

  @doc """
  Synchronously performs exactly one check for `name`, identical to a scheduled tick.

  Returns `{:ok, state}` with the resulting confirmed state, or `{:error, :not_found}`
  if the service is not registered. Does not alter or reschedule the periodic timer.
  """
  @spec force_check(term()) :: {:ok, confirmed_state()} | {:error, :not_found}
  def force_check(name) do
    GenServer.call(__MODULE__, {:force_check, name})
  end

  @doc """
  Returns the confirmed state (`:up` or `:down`) for `name`, or `{:error, :not_found}`
  if the service is unknown.
  """
  @spec state(term()) :: confirmed_state() | {:error, :not_found}
  def state(name) do
    GenServer.call(__MODULE__, {:state, name})
  end

  @doc """
  Returns a map of `%{name => state}` for every currently registered service.

  Returns `%{}` when no services are registered.
  """
  @spec states() :: %{optional(term()) => confirmed_state()}
  def states do
    GenServer.call(__MODULE__, :states)
  end

  @doc """
  Removes the service `name`.

  Returns `:ok` if it existed (its scheduled checks will never run again), or
  `{:error, :not_found}` if no such service was registered.
  """
  @spec unwatch(term()) :: :ok | {:error, :not_found}
  def unwatch(name) do
    GenServer.call(__MODULE__, {:unwatch, name})
  end

  @doc false
  @spec __noop_transition__(term(), confirmed_state(), confirmed_state()) :: :ok
  def __noop_transition__(_name, _from, _to), do: :ok

  ## GenServer callbacks

  @impl true
  @spec init(keyword()) :: {:ok, %{services: map()}}
  def init(_opts) do
    {:ok, %{services: %{}}}
  end

  @impl true
  def handle_call({:watch, name, check_func, interval_ms, opts}, _from, state) do
    service = %{
      check_func: check_func,
      interval_ms: interval_ms,
      fail_confirm: get_pos_int(opts, :fail_confirm, @default_fail_confirm),
      ok_confirm: get_pos_int(opts, :ok_confirm, @default_ok_confirm),
      on_transition: get_transition(opts),
      state: :up,
      fail_streak: 0,
      ok_streak: 0,
      generation: make_ref()
    }

    schedule_check(name, service.interval_ms, service.generation)
    services = Map.put(state.services, name, service)
    {:reply, :ok, %{state | services: services}}
  end

  def handle_call({:force_check, name}, _from, state) do
    case Map.fetch(state.services, name) do
      {:ok, service} ->
        updated = run_check(name, service)
        services = Map.put(state.services, name, updated)
        {:reply, {:ok, updated.state}, %{state | services: services}}

      :error ->
        {:reply, {:error, :not_found}, state}
    end
  end

  def handle_call({:state, name}, _from, state) do
    case Map.fetch(state.services, name) do
      {:ok, service} -> {:reply, service.state, state}
      :error -> {:reply, {:error, :not_found}, state}
    end
  end

  def handle_call(:states, _from, state) do
    reply = Map.new(state.services, fn {name, service} -> {name, service.state} end)
    {:reply, reply, state}
  end

  def handle_call({:unwatch, name}, _from, state) do
    case Map.pop(state.services, name) do
      {nil, _services} ->
        {:reply, {:error, :not_found}, state}

      {_service, services} ->
        {:reply, :ok, %{state | services: services}}
    end
  end

  @impl true
  def handle_info({:check, name, generation}, state) do
    case Map.fetch(state.services, name) do
      {:ok, %{generation: ^generation} = service} ->
        updated = run_check(name, service)
        schedule_check(name, updated.interval_ms, updated.generation)
        services = Map.put(state.services, name, updated)
        {:noreply, %{state | services: services}}

      _superseded_or_removed ->
        {:noreply, state}
    end
  end

  def handle_info(_msg, state) do
    {:noreply, state}
  end

  ## Internal helpers

  @spec schedule_check(term(), pos_integer(), reference()) :: reference()
  defp schedule_check(name, interval_ms, generation) do
    Process.send_after(self(), {:check, name, generation}, interval_ms)
  end

  @spec run_check(term(), map()) :: map()
  defp run_check(name, service) do
    case service.check_func.() do
      :ok -> handle_ok(name, service)
      {:error, _reason} -> handle_error(name, service)
    end
  end

  @spec handle_ok(term(), map()) :: map()
  defp handle_ok(name, %{state: :down} = service) do
    ok_streak = service.ok_streak + 1

    if ok_streak >= service.ok_confirm do
      service.on_transition.(name, :down, :up)
      %{service | state: :up, ok_streak: 0, fail_streak: 0}
    else
      %{service | ok_streak: ok_streak, fail_streak: 0}
    end
  end

  defp handle_ok(_name, %{state: :up} = service) do
    %{service | ok_streak: 0, fail_streak: 0}
  end

  @spec handle_error(term(), map()) :: map()
  defp handle_error(name, %{state: :up} = service) do
    fail_streak = service.fail_streak + 1

    if fail_streak >= service.fail_confirm do
      service.on_transition.(name, :up, :down)
      %{service | state: :down, fail_streak: 0, ok_streak: 0}
    else
      %{service | fail_streak: fail_streak, ok_streak: 0}
    end
  end

  defp handle_error(_name, %{state: :down} = service) do
    %{service | fail_streak: 0, ok_streak: 0}
  end

  @spec get_pos_int(keyword(), atom(), pos_integer()) :: pos_integer()
  defp get_pos_int(opts, key, default) do
    case Keyword.get(opts, key, default) do
      value when is_integer(value) and value > 0 -> value
      _invalid -> default
    end
  end

  @spec get_transition(keyword()) :: on_transition()
  defp get_transition(opts) do
    case Keyword.get(opts, :on_transition) do
      fun when is_function(fun, 3) -> fun
      _other -> @noop_transition
    end
  end
end
```
